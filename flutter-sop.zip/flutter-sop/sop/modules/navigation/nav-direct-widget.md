---
module: nav-direct-widget
category: navigation
version: 1.0
replaces: [nav-gorouter, nav-autoroute]
requires_seams: [layout.feature_root]
provides_seams: [nav.direct_navigator]
status: active
---

# Navigation — Direct Widget Navigation

## Scope

Direct widget instantiation and stack management across all application screens.
Governs page pushes, replacements, pops, and constructor argument passing.

## When to select

Active project default across the Washy application and SOP-guided codebases.
Selected whenever destination transparency, instant IDE code navigation (jumping to screen files), and compile-time constructor type safety are prioritized over loose string route lookups.

## Principle

**Never use named navigation.** When a developer (new or experienced) inspects any screen or button transition, the destination widget class and its source file MUST be immediately identifiable, clickable via IDE (`Cmd+Click` / `Ctrl+Click`), and compiler-verified.

## Rules

1. **PROHIBITION of Named Routes:**
   - Named route string lookups (such as `context.pushNamed(...)`, `context.goNamed(...)`, or `RouteNames.xyz`) are **STRICTLY FORBIDDEN**.
   - Raw string URL path navigation (such as `context.go('/my-path')`) is **STRICTLY FORBIDDEN**.

2. **Direct Widget Push Rule:**
   - All navigation MUST define and instantiate the target `Widget` class directly:
     ```dart
     // Standard Flutter
     Navigator.push(
       context,
       MaterialPageRoute(builder: (_) => const ProviderDetailPage()),
     );

     // Or via AppNavigator convenience extensions
     context.pushScreen(const ProviderDetailPage());
     ```

3. **Strongly-Typed Constructor Parameters (No Query String Serialization):**
   - Parameters passed to destination screens MUST be strongly typed through constructor arguments (e.g. `UserRole` enums, entity models, primitive IDs).
   - Serializing structured domain data into string query parameters (e.g. `?role=provider`) is **STRICTLY PROHIBITED**.

4. **Stack Replacement & Cleared Stacks:**
   - Use replacement or clearing operations explicitly:
     ```dart
     // Direct replacement
     context.pushReplacementScreen(const WelcomePage());

     // Direct clear-stack (e.g. Logout, Successful Onboarding)
     context.pushAndRemoveAllScreen(const CustomerHomePage());
     ```

5. **Centralized Helper & Pop Operations (`AppNavigator`):**
   - Direct low-level `Navigator.pop()`, `Navigator.of(context).pop()`, `Navigator.of(context).push()`, or `Navigator.of(context, rootNavigator: true)` calls outside of `AppNavigator` implementation are **STRICTLY FORBIDDEN**.
   - All navigation and stack pops MUST use `AppNavigator` static methods (`AppNavigator.pop`, `AppNavigator.push`, `AppNavigator.canPop`, `AppNavigator.popDialogOrBottomSheet`) or `BuildContext` convenience extensions (`pushScreen`, `pushReplacementScreen`, `pushAndRemoveAllScreen`, `popScreen`, `popDialog`).
   - Root `MaterialApp` is configured with `navigatorKey: AppNavigator.navigatorKey` and `home: const SplashPage()`.

## Review Checklist

- [ ] Zero named navigation calls (`context.pushNamed`, `context.goNamed`, `RouteNames`) in the diff.
- [ ] Zero direct low-level `Navigator.pop()` or `Navigator.of(...)` calls outside `AppNavigator`.
- [ ] All pops and screen pushes use `AppNavigator` static methods or `BuildContext` extensions (`context.popScreen()`, `context.pushScreen()`).
- [ ] Destination widgets are directly instantiated with strongly typed constructor parameters.
- [ ] Any developer can `Cmd+Click` directly from the call site into the destination screen widget.
- [ ] No route strings or serialized query parameters used for navigation.
