---
module: nav-autoroute
category: navigation
version: 1.0
replaces: [nav-gorouter]
requires_seams: [layout.feature_root, state.async_states]
provides_seams: [nav.route_registry, nav.guard_hook, nav.deep_link_scheme]
status: active
---

# Navigation — auto_route

## Scope

Route declaration, generated navigation, guards, deep links, nested routers.

## When to select

- The team wants compile-time-checked route arguments
- Deeply nested navigation where generated nested routers pay for themselves
- The project already runs it

Otherwise `nav-gorouter` is the agency default — fewer moving parts, no codegen step.

## Rules

1. **MUST** declare routes in one `@AutoRouterConfig` class under `app/router/`.
2. **MUST** navigate with generated route classes — `context.router.push(OrderDetailRoute(id: id))`.
   String paths at call sites **MUST NOT** be used.
3. **MUST** commit generated router output, and **MUST** run codegen in the same commit
   as the route change. A stale `.gr.dart` compiles against yesterday's routes.
4. **MUST** implement auth via an `AutoRouteGuard`, not per-screen checks.
5. **MUST** make every screen loadable from its route arguments alone, so deep links and
   cold starts work. Required arguments **SHOULD** be identifiers, not model objects.
6. **MUST** declare an unknown-route handler.
7. **MUST** use nested routers (`AutoTabsRouter`) for bottom-nav apps so tabs retain
   their own stacks.
8. **MUST** register deep link scheme/host on both platforms and verify cold-start,
   background, and foreground entry.
9. **MUST NOT** mix raw `Navigator.push` with auto_route for app routes.

## Seams

**Provides**
- `nav.route_registry` = `app/router/app_router.dart` + generated `app_router.gr.dart`
- `nav.guard_hook` = `AutoRouteGuard` implementations
- `nav.deep_link_scheme` = declared in `PROJECT_PROFILE.md`

**Expects**
- `layout.feature_root`
- `state.async_states` — auth state feeding the guard

## Review checklist

- [ ] Routes declared in one config class
- [ ] Generated route classes used at call sites; no string paths
- [ ] Generated output regenerated and committed in the same change
- [ ] Auth via guard, not per-screen
- [ ] Screens loadable from arguments alone
- [ ] Unknown-route handler present
- [ ] Deep links verified cold-start, background, foreground
- [ ] No raw `Navigator.push` for app routes

## Agent notes

- The dominant failure is **stale generated code**: the agent edits the route config but
  doesn't run build_runner, so the diff looks right and the build breaks — or worse,
  compiles against old routes. Verify `.gr.dart` is in the diff.
- Agents pass model objects as route arguments. Require identifiers.
- Agents may hand-edit generated files. Any manual edit inside a `.gr.dart` is a defect.

## Parameters

None.
