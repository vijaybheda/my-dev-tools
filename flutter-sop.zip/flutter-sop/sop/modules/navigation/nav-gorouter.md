---
module: nav-gorouter
category: navigation
version: 1.0
replaces: [nav-autoroute]
requires_seams: [layout.feature_root, state.async_states]
provides_seams: [nav.route_registry, nav.guard_hook, nav.deep_link_scheme]
status: active
---

# Navigation — go_router

## Scope

Route declaration, naming, parameters, guards, deep links, and nested navigation.
Does not govern screen internals or state management.

## When to select

Agency default. Declarative, deep-link-native, first-party-adjacent. Choose
`nav-autoroute` when the project needs heavy code-generated type safety or the team
already runs it.

## Rules

1. **MUST** declare all routes in one registry under `app/router/`, not scattered across
   features. One file for the `GoRouter` instance, one for route path/name constants.
2. **MUST** navigate by **name**, never by raw path string:
   `context.goNamed(Routes.orderDetail, pathParameters: {'id': id})`.
   Hardcoded path literals at call sites **MUST NOT** appear.
3. **MUST** define route names and paths as constants in one place. A typo'd string
   literal is a runtime crash the compiler could have caught.
4. **MUST** use `go` for navigation that replaces the stack (tab switches, post-login)
   and `push` for stack-additive navigation (detail screens, modals). Choosing wrongly
   breaks Android back behaviour — verify back from every new screen.
5. **MUST** pass identifiers through path or query parameters. A screen **MUST** be
   able to load itself from its parameters alone — otherwise deep links and cold starts
   produce blank screens. `extra` **MAY** carry preloaded data as a cache hint, but
   the screen **MUST** fetch from its parameters if `extra` is null — and this path
   **MUST** be tested. **MUST NOT** pass entire model objects via `extra` as the only
   source of data.
6. **MUST** implement auth redirect in the router's `redirect`, driven by a listenable
   auth state — not by an ad-hoc check inside each screen.
7. **MUST** define an `errorBuilder` for unknown routes. A deep link to a dead route
   **MUST NOT** show a blank screen or crash.
8. **MUST** use `StatefulShellRoute` for bottom-nav apps so each tab keeps its own stack
   and scroll position.
9. **MUST** register deep link scheme/host in both `AndroidManifest.xml` and iOS
   associated domains, and **MUST** verify cold-start, background, and foreground entry.
10. **SHOULD** keep the router free of business logic. Guards read state; they do not
    compute it.
11. **MUST NOT** call `Navigator.push` directly for app routes. Mixing imperative
    Navigator calls with go_router corrupts deep links and back behaviour. (Dialogs,
    bottom sheets, and other non-route overlays are fine.)

## Seams

**Provides**
- `nav.route_registry` = `app/router/routes.dart` (constants) + `app/router/router.dart`
- `nav.guard_hook` = the `redirect` callback on the `GoRouter` instance
- `nav.deep_link_scheme` = declared in `PROJECT_PROFILE.md`

**Expects**
- `layout.feature_root` — screens are imported from their feature's presentation layer
- `state.async_states` — auth state drives `redirect`; the state module owns its shape

## Review checklist

- [ ] All routes registered in `app/router/`; no route declared inside a feature
- [ ] Navigation by name; no hardcoded path literals at call sites
- [ ] `go` vs `push` correct — back behaviour verified on Android for new screens
- [ ] Screen loads from its parameters alone; `extra` is not the only data source
- [ ] Auth handled in `redirect`, not per-screen
- [ ] `errorBuilder` present
- [ ] Deep links verified cold-start, background, and foreground
- [ ] No raw `Navigator.push` for app routes

## Agent notes

- Agents hardcode path strings at call sites even when constants exist. Grep the diff
  for `'/` inside navigation calls.
- Agents pass whole objects via `extra` because it's the shortest path to a working
  screen. This is the most common source of "deep link opens a blank screen" bugs —
  reject it.
- Agents mix `Navigator.push` with go_router when a screen is added quickly. Check.
- When adding a route, the agent **MUST** update the route constants file, the router,
  and any relevant guard in the same change — partial registration compiles and fails
  at runtime.

## Parameters

None. Deep link scheme is recorded in `PROJECT_PROFILE.md`.
