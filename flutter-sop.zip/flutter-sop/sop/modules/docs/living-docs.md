---
module: living-docs
category: docs
version: 1.0
replaces: [ ]
requires_seams: [ agent.verification_gate ]
provides_seams: [ docs.registry, docs.update_triggers ]
status: active
---

# Docs — living documents

## Scope

The set of documents that must stay current as the codebase changes, who updates each,
and **what event triggers the update**. Selected on every project.

## The principle

A document nobody is obliged to update is a document that lies within a month, and a
document that lies is worse than one that doesn't exist — people trust it and act on it.

So every living document here has: **one trigger, one owner, one format.** If a document
in this module has no trigger, it doesn't belong in this module.

## Rules

### 1. The registry

| Document             | Trigger                                         | Updated by                | Tier  | Frequency                                                     |
|----------------------|-------------------------------------------------|---------------------------|-------|---------------------------------------------------------------|
| `CHANGELOG.md`       | Every merge to the integration branch           | Author of the PR          | **1** | Every PR                                                      |
| `FEATURE_MAP.md`     | Feature added, renamed, moved, or retired       | Author of the PR          | **1** | Most feature PRs                                              |
| `README.md`          | Setup steps change                              | Author of the change      | **1** | Occasionally                                                  |
| `DECISIONS.md` (ADR) | Any decision that closes off alternatives       | Decision maker            | **1** | When applicable                                               |
| `TASKS.md`           | Task started, blocked, or finished              | Whoever changes the state | **2** | When applicable (skip if external tracker is source of truth) |
| `CONTRIBUTORS.md`    | A new person or agent commits to the repo       | Project owner             | **2** | Rarely                                                        |
| `KNOWN_ISSUES.md`    | Bug found but not fixed this cycle              | Finder                    | **2** | When applicable                                               |
| `REFACTORING.md`     | Debt identified, or item resolved               | Finder / resolver         | **2** | When applicable                                               |
| `STRUCTURE.md`       | Structure deviates from the architecture module | Tech lead                 | **2** | Rarely                                                        |
| `AGENTS.md`          | Manifest changes, or an agent rule changes      | Tech lead                 | **2** | Rarely                                                        |
| `docs/api/*.md`      | API contract changes                            | Backend liaison           | **2** | When applicable                                               |

**Tier 1** documents **MUST** be checked on every PR. **Tier 2** documents **MUST** be
updated when their trigger fires, but do not need to be checked on every PR.

2. **MUST** update the triggered documents **in the same PR** as the change that
   triggered them. A follow-up PR "to update docs" is a PR that never gets written.
3. **MUST NOT** treat these as optional. The Definition of Done includes them.
4. **MUST NOT** create living documents beyond this registry without adding them to it
   with a trigger and an owner.

### 2. `CHANGELOG.md`

Keep-a-Changelog format, Semantic Versioning, newest first.

- **MUST** write entries in **user-facing language**, not commit messages. "Fixed a crash
  when opening an order from a notification" — not "fix(orders): null check in deep link
  handler".
- **MUST** file each entry under `Added` / `Changed` / `Fixed` / `Removed` /
  `Deprecated` / `Security`.
- **MUST** keep an `## [Unreleased]` section at the top. Entries land there on merge and
  are promoted to a version heading at release. If possible, define the module name and add
  appropriate change at module level.
- **MUST** mark breaking changes explicitly with `**BREAKING:**`.
- **MUST NOT** invent entries. Every entry traces to a merged change.
- Internal-only work (refactors, CI changes) **SHOULD** be omitted or
  grouped under a single `Internal` line — a changelog padded with invisible work stops
  being read.

### 3. `TASKS.md`

The in-flight work board when the project has no external tracker, and a mirror of the
ticket IDs when it does.

- **MUST** carry: ID, title, status, owner, and a one-line "next action" for anything in
  progress.
- Status vocabulary is fixed: `Backlog` → `In Progress` → `Blocked` → `In Review` → `Done`.
- **MUST** state the blocker and who can unblock it for anything `Blocked`. A blocked
  task with no named blocker is invisible work.
- **MUST** move `Done` items to the archive section at the bottom, or delete them if the
  changelog already records them. `TASKS.md` describes the present; it is not a history.
- If an external tracker (Jira, Linear, ClickUp) is the source of truth, `TASKS.md`
  **MUST** say so at the top and carry only the IDs currently in flight — never a
  duplicated copy that drifts.

### 4. `FEATURE_MAP.md`

The highest-value document for both new developers and agents: it answers *"where does
this feature live?"* in one place.

Each feature **MUST** record: name, owner, status, entry route, the files and folders it
spans, the API endpoints it calls, its E2E flows, and its feature flag if any.

- **MUST** be updated when a feature is added, renamed, moved, or retired.
- **MUST** list retired features under a `Retired` section with the version that removed
  them — this is what stops someone resurrecting dead code.
- **SHOULD** be the first document an agent reads before planning a change.
- Under `arch-layered-classic` this document does more work than under any other
  architecture module, because a feature's files are otherwise scattered across five
  top-level folders with nothing linking them.

### 5. `CONTRIBUTORS.md`

- **MUST** list every person and every AI agent that has contributed, with role, active
  period, and area of ownership.
- **MUST** record **external** contributors (contractors, client developers, agencies)
  separately, with the contract or engagement reference. At handover, this is the
  document that answers "who wrote this and are we allowed to ship it?"
- **MUST** name the current owner explicitly at the top. Core requires exactly one owner
  at all times; this is where that is visible.
- **MUST** record departures — mark the period closed rather than deleting the person.
  Deleting them erases the provenance of their code.
- **MUST NOT** include personal contact details, home addresses, or anything beyond
  professional identity and role.
- Agents **MUST** be listed by tool and model family, not as a person.

### 6. `DECISIONS.md` — architecture decision records

One entry per decision that closes off alternatives. Short. Append-only.

- **MUST** record: date, decision, context, alternatives considered, consequences.
- **MUST NOT** edit a past decision. Supersede it with a new entry that links back —
  the reasoning that was true then is the point of the record.
- Triggers: module selection or change, adding a significant dependency, a schema or API
  contract choice, anything a future developer would otherwise reverse without knowing why.

### 7. `KNOWN_ISSUES.md` and `REFACTORING.md`

- `KNOWN_ISSUES.md` **MUST** carry: symptom, affected versions, workaround, ticket,
  severity. Anything shipped with a known defect goes here **before** release, not after.
- `REFACTORING.md` follows the Handbook §13.2 item template (ID, status, priority,
  effort, problem, current implementation, recommendation, benefit, acceptance criteria).
- **MUST** be reviewed in sprint planning; the Handbook's 20% capacity allocation is
  spent from this list, not from whatever feels annoying that week.
- **MUST** close items when resolved, noting the PR — an open list of already-fixed
  items trains people to ignore the list.

## Seams

**Provides**

- `docs.registry` = the §1 table
- `docs.update_triggers` = the trigger column, consumed by the agents modules

## Review checklist

**Tier 1 (every PR):**

- [ ] `CHANGELOG.md` entry in user-facing language, correct category, under `[Unreleased]`. If
  possible, define the module name and add appropriate change at module level.
- [ ] `FEATURE_MAP.md` reflects any added, moved, renamed, or retired feature
- [ ] `README.md` updated if setup steps changed
- [ ] `DECISIONS.md` entry added if the change closed off alternatives

**Tier 2 (check if triggered):**

- [ ] `TASKS.md` status current; blockers named
- [ ] `CONTRIBUTORS.md` updated if a new person or agent contributed
- [ ] `KNOWN_ISSUES.md`, `REFACTORING.md`, `STRUCTURE.md`, `AGENTS.md` updated if triggers fired
- [ ] `docs/api/*.md` updated for API contract changes

**Always:**

- [ ] Every triggered document updated **in this PR**
- [ ] No fabricated entries — each traces to a real change

## Agent notes

Documentation maintenance is **part of the implementation task**, not a follow-up.

- **MUST** read `FEATURE_MAP.md` before planning any change, and `DECISIONS.md` before
  proposing an approach that may already have been considered and rejected.
- **MUST** update the triggered documents in the same change as the code.
- **MUST NOT** fabricate. Every changelog line, feature-map file path, and contributor
  entry must correspond to something real in the diff or the repo. Plausible-sounding
  documentation is the most damaging output an agent can produce here, because it reads
  correct and is never re-verified.
- **MUST NOT** rewrite history: no editing past changelog versions, no editing past ADRs,
  no removing departed contributors.
- **MUST NOT** mass-reformat a living document while making an unrelated change. The
  diff must show what changed in substance.
- When unsure whether a change is user-facing, **MUST** ask rather than guess — an
  internal refactor announced to users, or a breaking change filed as `Internal`, both
  cost more than the question.
- The agent **MAY** draft entries and **SHOULD** propose them, but the human author owns
  correctness at merge.

## Parameters

`parameters.docs.external_tracker` — name of the ticket system, or `none` if `TASKS.md`
is the source of truth.
