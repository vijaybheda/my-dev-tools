---
module: agents-core
category: agents
version: 1.1
replaces: []
requires_seams: [docs.update_triggers]
provides_seams: [agent.context_file, agent.verification_gate]
status: active
---

# Agents — core

## Scope

How AI coding agents (Roo Code / RooFlow, Claude Code, Cursor, and equivalents) are used
safely on client work. Tool-specific modules build on this.

## When to select

Any project where an agent touches the codebase. There is no sibling.

## Principle

**Agents are fast junior developers with no accountability.** They accelerate work; they
never own quality. Every line an agent writes is the assigned developer's responsibility
on merge. "The agent wrote it" is never an explanation for a defect.

## Rules

### 1. Hard boundaries

- **MUST NOT** merge, release, tag, or touch store credentials, keystores, `.env`, or
  CI secrets
- **MUST NOT** be given production secrets. Agent-accessible env files carry dev values
- **MUST NOT** run destructive commands unsupervised — `rm -rf`, force push, database
  migrations, `git reset --hard` on shared branches
- **MUST NOT** modify: signing blocks, `ios/Runner.xcodeproj`, CI workflow files,
  `pubspec.lock`. Agents propose; humans apply
- **MUST NOT** write, scaffold, generate, or add test cases (unit tests, widget tests, integration tests, or regression tests). Test creation is strictly owned by human developers; agents never write test cases.
- **MUST NOT** copy raw CSS attributes (hex colors, raw numeric padding/margins, inline strings) from design snippets into widget code. All visual properties MUST map to `AppColors`, `AppSpacing`, and `AppStrings`.

### 2. Context file

Every project **MUST** carry an agent context file at the repo root (`.roo/` rules,
`CLAUDE.md`, `AGENTS.md` — whichever the tooling reads). It **MUST** state:

- Flutter/Dart versions and that `fvm` is in use
- **The module selection from `sop.manifest.yaml`, explicitly** — this is the highest-value
  line in the file. Without it agents apply whatever convention their training data
  favours, which is the single largest source of architectural drift on agency work
- A pointer to `SOP-CORE.md` and each selected module
- "Do not add dependencies without asking"
- The do-not-modify list from §1
- Where the API spec lives

The context file **MUST** be updated when the manifest changes. A stale context file
makes agents reinforce dead patterns.

### 3. Mode discipline

| Mode | For | Boundary |
|---|---|---|
| **Architect / Plan** | Breaking a ticket into a file-level plan | Produces a plan, writes no implementation |
| **Code** | Implementing an approved plan | Scoped to the files in the plan |
| **Debug** | Reproducing and fixing one defect | Fix only, no refactors |
| **Ask** | Codebase questions | Read-only |
| **Critic / Red Team** | Challenging ideas, plans, ADRs, or diffs | Read-only analysis; zero validation; uncovers failure modes & counterarguments |

- **MUST** run Plan before Code on anything touching more than ~3 files or adding a
  feature. The developer reviews the plan **before** Code runs — a wrong plan caught here
  costs a minute; caught in review it costs an afternoon
- The plan **MUST** be a Markdown document covering: feature overview, architecture
  decisions, file-by-file changes, **adversarial analysis & failure modes (mandatory devil's advocate audit)**, new dependencies, and rollback plan
- The plan is a **living document**. Review comments and corrections go into it, the agent
  revises it, and implementation starts only once the tech lead or senior developer
  approves. Implementation **MUST** stay strictly aligned to the approved plan; scope
  found mid-implementation goes back to the plan, not straight into the diff
- **SHOULD** use a strong reasoning model for planning, architecture, and final review,
  and a faster model for implementation of an approved plan
- **MUST** keep one ticket = one agent task = one branch
- Memory-bank / context files **MUST** be committed and reviewed like code

### 4. Verification gate

Before an agent-assisted PR opens, the developer **MUST**:

- [ ] Read every changed file end to end. Not skim
- [ ] Run the app and exercise the actual flow on a device or emulator
- [ ] Confirm no invented APIs, no hallucinated package names, no dead code left behind
- [ ] **Confirm the output matches the modules in `sop.manifest.yaml`** — agents drift
      toward generic patterns regardless of the brief
- [ ] Confirm nothing duplicates what already exists in `core/` or `shared/`
- [ ] `git diff pubspec.yaml` — check for silently added dependencies
- [ ] Confirm no secrets, keys, or client data in code or comments
- [ ] **Confirm no test cases were written or added** — agents must never write test cases
- [ ] **Confirm design system token compliance via automated grep audits:**
      - `git grep "Color(0x" lib/` (0 results outside `app_colors.dart`)
      - `git grep "fromLTRB(" lib/` (0 results outside `app_spacing.dart`)
      - No hardcoded user-facing strings or raw CSS literals leaked into UI widgets

### 5. Documentation duty

Agents maintain the living documents alongside the code. Per `docs.update_triggers`, the
agent **MUST** update every triggered document **in the same change** — never as a
follow-up. **MUST NOT** fabricate an entry: every changelog line, file path, and
contributor row traces to something real in the diff.

Before planning, the agent **MUST** read `FEATURE_MAP.md` (where the code lives) and
`DECISIONS.md` (what was already considered and rejected).

### 6. Disclosure

The PR **MUST** state which agent and mode were used, and what was verified manually.
Reviewers apply extra scrutiny to the §4 areas on agent-assisted PRs.

## Seams

**Provides**
- `agent.context_file` = the repo-root rules file
- `agent.verification_gate` = §4

## Review checklist

- [ ] Agent use disclosed in the PR
- [ ] Output conforms to the selected modules, not generic conventions
- [ ] No silently added dependencies
- [ ] No modifications to the §1 do-not-touch list
- [ ] No test cases written or added by the agent (agents never write test cases)
- [ ] Design tokens strictly observed: zero raw hex literals, zero raw `EdgeInsets` literals, zero hardcoded user strings
- [ ] Context file updated if the manifest changed
- [ ] Living documents updated in this change, with no fabricated entries
- [ ] Implementation matches the approved plan; no unplanned scope in the diff

## Agent notes

- **NEVER WRITE TEST CASES:** Agents reading this **MUST NEVER** write, scaffold, generate, or add test cases under any circumstances. Testing is strictly owned by human developers.
- **ZERO CSS / FIGMA LITERAL LEAKAGE:** Agents MUST NOT translate Figma CSS into raw Dart literals (`Color(0xFF...)`, `EdgeInsets.fromLTRB(...)`, or inline text strings). Every visual attribute must map to `AppColors`, `AppSpacing`, and `AppStrings`.
- When a rule here conflicts with a pattern you would otherwise produce, this document wins. If the selected module isn't clear from the context file, **ask** rather than inferring from the codebase — a codebase mid-migration will teach you the wrong convention.

## Parameters

None.
