---
module: state-bloc
category: state
version: 1.0
replaces: []                        # no sibling state modules yet; list them here when added (e.g. state-riverpod)
requires_seams: [layout.layers, boundary.repository]
provides_seams: [state.controller_location, state.async_states]
status: active
---

# State management — BLoC / Cubit

## Scope

Blocs, cubits, events, states, and dependency injection.

## When to select

- The client's in-house team already runs BLoC and inherits the codebase
- The contract mandates it
- The team is genuinely more productive in it

## Rules

1. **MUST** use `Cubit` for simple state and `Bloc` only where an explicit event stream
   earns its cost (audit trails, complex transitions, event transformers).
   A Bloc whose events map 1:1 to methods **SHOULD** be a Cubit.
2. **MUST** place blocs/cubits in the presentation layer of their feature per
   `layout.layers`.
3. **MUST** make states immutable and exhaustive — sealed classes or `freezed` unions
   covering initial / loading / success / failure. A single mutable state class with
   nullable fields **MUST NOT** be used.
4. **MUST** handle every state variant at the UI edge, with a retry path on failure.
5. **MUST** inject repositories (or usecases, under `arch-clean`) via constructor, and
   provide them with `RepositoryProvider`. A bloc **MUST NOT** construct its own
   dependencies.
6. **MUST** use `BlocProvider` scoped to the subtree that needs it; app-wide providers
   only for genuinely global state.
7. **MUST** use `BlocSelector` or `buildWhen` when a widget depends on one field.
8. **MUST** put side effects (navigation, snackbars, dialogs) in `BlocListener`, never
   in `builder`. A `builder` **MUST** be pure.
9. **MUST** close blocs correctly; rely on `BlocProvider` disposal rather than manual
   `close()` unless the bloc is manually constructed.
10. **MUST NOT** call `emit` after `close`, or emit from outside the bloc.

## Seams

**Provides**
- `state.controller_location` = `<feature>/presentation/bloc/`
- `state.async_states` = sealed state union: initial / loading / success / failure

**Expects**
- `layout.layers`
- `boundary.repository` — constructor-injected. Under `arch-clean`, inject the usecase.

## Review checklist

- [ ] Cubit used where events add nothing
- [ ] States immutable and exhaustive; no nullable-field mega-state
- [ ] Every state variant handled in UI, failure has retry
- [ ] Dependencies constructor-injected, provided via `RepositoryProvider`
- [ ] `BlocProvider` scoped no wider than needed
- [ ] `buildWhen`/`BlocSelector` used for single-field dependencies
- [ ] Side effects in `BlocListener`; `builder` is pure

## Agent notes

- Agents generate Blocs where Cubits suffice, producing large event enums with no value.
  Reject at the plan stage.
- Agents frequently put navigation inside `builder`. Check every `BlocBuilder`.
- Agents produce non-exhaustive state handling when states are added later — verify the
  switch/pattern match covers the new variant, since a fallback branch hides it.

## Parameters

None.
