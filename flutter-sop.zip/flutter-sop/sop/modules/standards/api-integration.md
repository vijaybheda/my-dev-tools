---
module: api-integration
category: standards
version: 1.0
replaces: []
requires_seams: [boundary.repository, logging.redaction_policy]
provides_seams: [api.result_type, api.retry_policy]
status: active
---

# Standards — API integration

## Scope

HTTP client configuration, request/response models, auth and token handling,
interceptors, error taxonomy, retries, pagination, connectivity, and API docs.
Ported from Employee Handbook v1.0 §9. Selected on every project with a backend.

**HTTP client assumption:** This module's examples and interceptor patterns assume
**Dio**. The client-agnostic rules (result types, error taxonomy, retry policy, model
boundaries) apply regardless of HTTP client. If the project uses a different client
(`http`, `chopper`, Dart's native `HttpClient`), record the deviation in
`sop.manifest.yaml` and adapt the patterns accordingly — the architectural rules
still hold.

## Rules

### 1. Client

**MUST** route all network calls through one configured client.

Reference implementation (Dio):

```dart
class ApiClient {
  final Dio _dio;

  ApiClient({required String baseUrl, required ApiInterceptor interceptor})
      : _dio = Dio(BaseOptions(
          baseUrl: baseUrl,
          connectTimeout: const Duration(seconds: 15),
          receiveTimeout: const Duration(seconds: 30),
          headers: {'Content-Type': 'application/json'},
        )) {
    _dio.interceptors.add(interceptor);
  }
}
```

Ad-hoc `http.get` calls in feature code **MUST NOT** be written.

### 2. Models

- **MUST** use typed request and response models with code generation
  (`json_serializable` or `freezed` — one per project)
- **MUST** map DTOs to domain models before the UI. Raw API responses **MUST NOT** reach
  presentation
- **MUST** handle null and unexpected fields without throwing. A backend adding a field
  must never crash the app

### 3. Auth and tokens

- **MUST** store tokens in secure storage (Keychain / Keystore)
- **MUST** refresh automatically via interceptor, with a single-flight guard so
  concurrent 401s trigger one refresh, not five
- **MUST** force logout when the refresh call itself returns 401. A second refresh path
  **MUST NOT** exist
- **MUST** clear all tokens on logout

### 4. Error taxonomy

**MUST** return a sealed result type across the repository boundary.

```dart
sealed class ApiResult<T> { const ApiResult(); }

class ApiSuccess<T> extends ApiResult<T> {
  final T data;
  const ApiSuccess(this.data);
}

class ApiError<T> extends ApiResult<T> {
  final String message;
  final int? statusCode;
  final ApiErrorType type;
  const ApiError(this.message, {this.statusCode, required this.type});
}

enum ApiErrorType { network, timeout, unauthorized, forbidden, notFound, server, unknown }
```

Raw client exceptions (`DioException` and equivalents) **MUST NOT** cross the repository
boundary.

### 5. Timeouts and retries

**MUST** set default timeouts. Endpoints with different profiles (file uploads,
real-time messaging) **SHOULD** override per-request and document non-default
timeouts in `docs/api/*.md`.

| Setting | Default | Notes |
|---|---|---|
| Connect timeout | 15s | **SHOULD** use this as baseline |
| Receive timeout | 30s | **SHOULD** use this as baseline |
| Retry attempts | 3 | |
| Backoff | Exponential — 1s, 2s, 4s | |
| Retry on | Network errors, timeouts, 5xx | |
| Never retry | Any 4xx | |

**MUST NOT** retry non-idempotent requests (`POST` that creates an order, a payment)
without an idempotency key. A retried payment is a duplicate charge.

### 6. Pagination, files, connectivity

- **MUST** paginate any list that can grow unbounded; cursor-based where the backend
  supports it. **MUST** handle empty pages and end-of-list
- Uploads and downloads **MUST** show progress, survive interruption, validate type and
  size before sending, and clean up temporary files
- **MUST** show a clear offline indicator, and sync or refresh when connectivity returns
- **MUST** verify airplane mode and poor-connectivity behaviour before release

### 7. Documentation

API docs live in `docs/api/*.md`, one file per domain area. Each **MUST** carry:
endpoint, method, parameters, headers, success example, error examples, auth
requirements, business rules, and known edge cases.

**MUST** be updated in the same PR as any contract change (see `living-docs`).

### 8. Pre-API Development & Simulated Latency Standard

When building a feature before its backend API endpoint is available:

1. **Zero Mock Classes or Test Cases:** Agents and developers **MUST NOT** create standalone mock classes, mock files, or unit/widget test cases.
2. **In-Place Simulated Latency & DTO Parsing:** Implement the call directly inside the actual feature remote data source / repository using:
   - `await Future.delayed(const Duration(seconds: 2));` to simulate real network latency.
   - A raw JSON string (`const rawJsonResponse = '''...''';`).
   - `jsonDecode(rawJsonResponse)` passed into the `@JsonSerializable` DTO: `ResponseDto.fromJson(...)` and mapped to domain: `.toDomain()`.
3. **Mandatory Standardized `TODO(api-integration)` Comment:**
   - Every simulated delay, fallback stub, or temporary JSON payload **MUST** be marked with:
     ```dart
     // =========================================================================
     // TODO(api-integration): Replace simulated 2-second delay and static JSON
     // with live API endpoint: [METHOD] [URL]
     // =========================================================================
     ```
4. **Instant Zero-Diff Live Integration:** When the backend endpoint is deployed, swapping to live Dio requires editing only the data source method lines (replacing the simulated delay/string with `await _dio.get(...)`). UI widgets, BLoCs, DTOs, and Domain models require **zero lines of diff**.

## Seams

**Provides**
- `api.result_type` = `ApiResult<T>` and `ApiErrorType`
- `api.retry_policy` = §5

**Expects**
- `boundary.repository` — where the result type surfaces
- `logging.redaction_policy` — what interceptors may log

## Review checklist

- [ ] Calls go through the shared client; no ad-hoc requests
- [ ] Typed request/response models; DTOs mapped before UI
- [ ] Raw client exceptions do not cross the repository boundary
- [ ] Token refresh single-flight; refresh-401 forces logout
- [ ] Retry policy correct; no retries on 4xx or unguarded non-idempotent calls
- [ ] Pagination for unbounded lists; offline path handled
- [ ] Pre-API endpoints follow §8 (2s delay + raw JSON string + DTO parsing + `TODO(api-integration)`)
- [ ] Zero mock classes or test cases created
- [ ] `docs/api/*.md` updated for contract changes

## Agent notes

- Agents retry everything, including `POST`. Check §5 on any new endpoint call.
- Agents build a second token-refresh path when they can't find the interceptor. Point
  them at the existing one; two refresh paths cause logout loops that are painful to debug.
- Agents let `DioException` leak to the UI when adding an endpoint quickly. Check the
  repository boundary.
- Agents MUST NOT create mock classes or write test cases. Use the §8 simulated 2s JSON pattern with mandatory `TODO(api-integration)` tags.
- **MUST** update `docs/api/*.md` in the same change as an endpoint change.

## Parameters

None.

