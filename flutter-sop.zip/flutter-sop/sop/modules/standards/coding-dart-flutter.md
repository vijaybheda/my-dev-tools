---
module: coding-dart-flutter
category: standards
version: 1.0
replaces: []
requires_seams: []
provides_seams: [standards.lint_baseline]
status: active
---

# Standards — Dart & Flutter coding

## Scope

Language and widget-level rules independent of architecture, state, and navigation.
Selected on every project.

## Rules

### 1. Baseline

- **MUST** pass `flutter analyze` with zero errors and zero warnings before PR
- **MUST** be formatted with `dart format .`
- **MUST** use `flutter_lints` at minimum
- Flutter and Dart versions **MUST** be pinned via `fvm`, matching `.fvmrc` and the manifest

### 2. Dart

- Prefer `final` everywhere; `const` for compile-time constants
- **MUST** justify every `!` (bang) with a comment explaining why it cannot be null, or
  rewrite it
- Models **SHOULD** be immutable with `copyWith`, `==`, `hashCode`. **SHOULD** use
  one approach per project for consistency (`freezed` or `equatable`). If mixing
  (e.g., `freezed` for sealed state unions, `equatable` for simple DTOs), document
  the criteria in `DECISIONS.md` so it doesn't drift into ad-hoc mixing
- **MUST NOT** use `dynamic` to escape a compile error
- Async: no unawaited futures without `unawaited()`; **MUST NOT** write bare
  `try {} catch (_) {}` that swallows

### 3. Widgets

- **MUST** extract a separate widget class when `build` exceeds ~80 lines or nests
  beyond ~5 levels
- **SHOULD** prefer separate widget classes over `Widget _buildX()` methods for
  reusable or independently-rebuilding sub-trees — const-ability and rebuild scope
  both depend on it. `_buildX()` **MAY** be used for tightly-coupled, non-reusable
  sections that would require >4 constructor parameters to extract
- **MUST** add `const` constructors wherever possible
- **MUST NOT** perform network calls, heavy computation, or state mutation in `build`
- Lists over ~20 items **MUST** use `ListView.builder` or slivers; supply `itemExtent` or `prototypeItem` where possible
- **ListView Parent Component & 4-State Handling:** Any parent screen or component wrapping a list view **MUST** handle loading state (with loading shimmer skeleton), error state (with localized error & retry), empty/no data state (with illustration & recovery guidance), and populated state. Empty and Error states **MUST** be wrapped in a scrollable `RefreshIndicator` container so pull-to-refresh works even when zero items exist.
- **Cross-Platform Pull-to-Refresh & TODO Protocol:** List screens **MUST** allow pull-to-refresh (`RefreshIndicator` configured with `edgeOffset: 50.0`, `color: AppColors.primaryBlue`, `backgroundColor: AppColors.bgSecondaryDark`, `clipBehavior: Clip.none`, and `physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics())`). If backend refresh logic is not yet implemented, an explicit `// TODO(api-integration): Implement pull-to-refresh handler for [Screen/Feature Name]` comment **MUST** be added.
- **Scroll Physics & Layout Integrity:** Any screen containing a list **MUST** allow smooth scrolling without height clipping, edge boundaries cut-off (`clipBehavior: Clip.none`), or physics lock. List views inside `RefreshIndicator` **MUST** set `physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics())` so pull-to-refresh functions cleanly on iOS and Android even on small or empty lists. Adequate bottom padding (`AppSpacing.bottomCtaPadding` or `90.0` FAB clearance) **MUST** be provided so the last item is never cut off.
- **MUST NOT** use components or inline UI layouts inside `ListView`, `ListView.builder`, or `ListView.separated` without a dedicated separate `Widget` class for each list item. Each list item MUST be a standalone `StatelessWidget` / `StatefulWidget`. `Widget _buildX()` helper methods in `itemBuilder` are strictly forbidden.
- Images **MUST** be cached, with explicit dimensions, a placeholder, and an error widget.
  Unbounded `Image.network` **MUST NOT** ship
- Default framework icons (`Icons.*`, `CupertinoIcons.*`) **MUST NOT** be used across any component or screen. All UI icons **MUST** use custom icons/vectors (SVG/custom vectors) accessed via generated asset getters (`Assets.icon.*`, `Assets.svg.*`) or SVG vector extensions (`.toSvg()`)
- **MUST** present UI implementations and UI modifications in Markdown format first (detailing layout structure, token usage, component reuse from `COMPONENTS.md`, and 4 visual states). Implementation code **MUST NOT** be written until the user reviews and provides explicit approval. If changes are requested, repeat markdown updates iteratively until approval is granted to ensure pixel-perfect UI execution.

### 4. Performance

- Heavy work (large JSON parsing, image processing) **MUST** go to `compute`/isolate
- Profile-mode check before release: no jank scrolling the main list screens
- Rebuild scope tight — the state module defines the mechanism

### 5. Errors and logging

- **MUST** map errors at the data boundary; raw client exceptions **MUST NOT** reach UI
- User-facing errors **MUST** be human-readable and localized. Stack traces and raw API
  messages **MUST NOT** be surfaced
- **MUST** wire a crash reporter before the first production release, including
  `FlutterError.onError` and `PlatformDispatcher.instance.onError`
- **MUST NOT** ship `print()`. **MUST NOT** log tokens, passwords, PII, or auth headers

### 6. Accessibility and localization

- Minimum tap target 48×48 dp
- Semantics labels on icon-only buttons
- **MUST** survive 1.3× text scale without overflow
- If the app is or may become multi-language, **MUST** use `flutter_localizations` + ARB
  from day one. Hardcoded user-facing strings **MUST NOT** ship

### 7. Anti-Static & Dynamic Domain Modeling

- **MUST NOT** code static or hardcoded dummy lists, mock strings, or fake click handlers inside UI widgets or presentation controllers.
- Domain concepts **MUST NOT** suffer from Primitive Obsession. Business concepts must be represented as strongly-typed, immutable models extending `Equatable` with `@JsonSerializable(explicitToJson: true)`.
- UI screens **MUST** support and verify all 4 visual states (Loading, Empty, Error with retry, Populated).
- Any temporary static payload or simulated delay in data sources **MUST** carry a standardized `// TODO(api-integration): ...` comment.

### 8. Design System Tokenization & Anti-Literal Rules

- **Strict Zero Hex Literal Rule (`AppColors`):**
  - **MUST NOT** write `Color(0x...)` or raw hex literals inside UI screens, widgets, cards, dialogs, or controllers.
  - All colors MUST be referenced from `AppColors.*` (`lib/core/theme/app_colors.dart`).
  - When referencing Figma CSS (e.g. `#0D1B2A`), agents MUST NEVER paste the raw hex value into widget code. Map it to an existing semantic `AppColors` token, or declare a new token in `app_colors.dart` first.
- **Strict Zero Raw EdgeInsets / Spacer Rule (`AppSpacing`):**
  - **MUST NOT** write raw numeric padding, margins, or arbitrary spacers (e.g. `EdgeInsets.fromLTRB(...)`, `EdgeInsets.symmetric(...)`, `EdgeInsets.all(...)`, `SizedBox(height: ...)`).
  - All layout offsets, margins, padding, and gaps MUST be referenced from `AppSpacing.*` scalar tokens or preset geometries (`lib/core/theme/app_spacing.dart`).
- **Strict Zero Inline String Rule (`AppStrings`):**
  - **MUST NOT** write inline user-facing strings, button labels, screen titles, input labels, hint placeholders, or error toasts directly in widgets.
  - All user-facing strings MUST be defined in `AppStrings` (`lib/core/constants/app_strings.dart`) or `l10n/*.arb`.

## Seams

**Provides** — `standards.lint_baseline` = `flutter_lints` plus any module-added rules.

## Review checklist

- [ ] analyze clean, formatted
- [ ] No unjustified `!`, no `dynamic` escapes, no swallowed exceptions
- [ ] `const` used; no `_buildX()` methods; builders for long lists
- [ ] Images bounded with placeholder and error states
- [ ] No `print()`; no sensitive logging
- [ ] Tap targets, semantics labels, 1.3× text scale, dark mode
- [ ] No hardcoded user-facing strings where localization applies
- [ ] Zero static dummy lists or mock strings in UI widgets
- [ ] Design token compliance: zero raw hex literals (`git grep "Color(0x" lib/`), zero raw `EdgeInsets` literals (`git grep "fromLTRB(" lib/`)
- [ ] All 4 UI states (Loading, Empty, Error with retry, Populated) handled
- [ ] Any simulated/fallback data carries standardized `// TODO(api-integration): ...`

## Agent notes

- Agents omit `const` at scale and leave `_buildX()` methods. Both are mechanical to
  catch — scan the diff.
- Agents add `!` freely to clear analyzer errors. Every one needs justification or a rewrite.
- Agents leave `print()` from their own debugging in the diff.
- Agents MUST NOT code static shortcuts or hardcoded mocks in UI. Every feature must use dynamic domain models, decoupled action intents, and the 4-state UI matrix.
- Agents frequently copy-paste raw CSS attributes from Figma snippets (e.g. `background: #0D1B2A`, `padding: 16px 8px 16px 16px`, `font-size: 16px`). This is STRICTLY FORBIDDEN. Every visual property MUST map to the project's token registry (`AppColors`, `AppSpacing`, `AppTypography`, `AppStrings`).
- Agents MUST run automated grep audits (`git grep "Color(0x" lib/` and `git grep "fromLTRB(" lib/`) before marking any task complete.

## Parameters

None.


