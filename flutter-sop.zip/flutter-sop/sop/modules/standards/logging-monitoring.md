---
module: logging-monitoring
category: standards
version: 1.0
replaces: []
requires_seams: [release.flavor_names]
provides_seams: [logging.service, logging.redaction_policy]
status: active
---

# Standards — logging & monitoring

## Scope

Log categories, levels, the logging service contract, screen lifecycle logging, and
redaction. Ported from Employee Handbook v1.0 §7. Selected on every project.

## Rules

### 1. Categories

Every app **MUST** support these log categories:

| Category | Captures |
|---|---|
| Debug | Variable states, method entry/exit |
| API | Endpoint, status code, duration |
| Auth | Login attempts, token refresh |
| Navigation | Screen opened/closed |
| Error | Exceptions with stack traces and context |
| Performance | Frame build times, API latency |
| Environment | Flavor, version, build number |

### 2. Service

**MUST** log through one centralized service with levels configurable per flavor.

```dart
enum LogLevel { verbose, debug, info, warning, error, fatal }

abstract class AppLogger {
  void v(String message, {dynamic error, StackTrace? stackTrace});
  void d(String message, {dynamic error, StackTrace? stackTrace});
  void i(String message, {dynamic error, StackTrace? stackTrace});
  void w(String message, {dynamic error, StackTrace? stackTrace});
  void e(String message, {dynamic error, StackTrace? stackTrace});
  void f(String message, {dynamic error, StackTrace? stackTrace});
}
```

- **MUST** include the flavor identifier in every log header
- **MUST NOT** call `print()` or `debugPrint()` directly in feature code
- Verbose and debug **MUST** be disabled in production builds

### 3. Screen lifecycle

**MUST** log screen open and close. **SHOULD** use a route-observer-based approach
rather than per-screen calls, so logging works regardless of widget type
(`StatelessWidget` or `StatefulWidget`).

Recommended approach — `NavigatorObserver` or GoRouter listener:

```dart
class ScreenLoggingObserver extends NavigatorObserver {
  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    if (route.settings.name != null) {
      logger.i('Screen opened: ${route.settings.name}');
    }
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    if (route.settings.name != null) {
      logger.i('Screen closed: ${route.settings.name}');
    }
  }
}
```

For GoRouter projects, this **SHOULD** be wired via `GoRouter(observers: [...])`.
For screens needing additional lifecycle logging beyond navigation events, a
`StatefulWidget` mixin **MAY** still be used, but **MUST NOT** be the primary
mechanism.

### 4. Redaction — never negotiable

**MUST NOT** log, under any circumstance, in any environment including local development:

- Passwords, OTPs, access tokens, refresh tokens, API secrets and keys
- PII: full names combined with other identifying data, government ID numbers,
  financial account numbers, precise location, health information

Rules:

- **MUST** mask tokens to a recognizable stub: `Authorization: Bearer eyJ...xYz`
- **MUST** redact sensitive fields in API request/response logging by field name, using
  an allow-list or a redaction list held in one place — not by remembering at each call site
- **MUST** audit logs for accidental exposure before every release
- "It's only the dev flavor" is not an exception. Dev logs get pasted into tickets,
  shared in chat, and attached to bug reports

### 5. Crash and performance monitoring

- **MUST** wire a crash reporter before the first production release, including
  `FlutterError.onError` and `PlatformDispatcher.instance.onError`
- **MUST** upload mapping files and dSYMs with each release — without them crash reports
  are unreadable
- Analytics and crash reporting **MUST** be enabled only in staging and production

## Seams

**Provides**
- `logging.service` = the `AppLogger` contract
- `logging.redaction_policy` = §4, consumed by the API integration module

**Expects** — `release.flavor_names`.

## Review checklist

- [ ] Logging goes through the service; no direct `print()`/`debugPrint()`
- [ ] New screens use the logging mixin
- [ ] No tokens, credentials, OTPs, or PII in any log statement
- [ ] New API logging respects the redaction list
- [ ] Log levels correct for the flavor

## Agent notes

- Agents leave their own debugging `print()` calls in the diff. Scan for them.
- Agents log whole request or response objects when debugging an API issue — the fastest
  route to a token in a log file. Log field names and status codes, never whole payloads.
- When adding a field to an API model, the agent **MUST** check whether it needs adding to
  the redaction list.

## Parameters

None.
