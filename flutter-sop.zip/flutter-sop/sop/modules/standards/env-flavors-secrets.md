---
module: env-flavors-secrets
category: standards
version: 1.0
replaces: []
requires_seams: [release.flavor_names]
provides_seams: [env.config_injection]
status: active
---

# Standards — environments, flavors, secrets

## Scope

Flavor setup, runtime configuration, and secret handling. Selected on every project.

## Rules

### 1. Flavors

- **MUST** define at least `dev` and `prod`. Add `staging` when the client has a staging
  backend. Names come from `release.flavor_names`
- **MUST** give each flavor a distinct `applicationId` / bundle ID suffix (`.dev`,
  `.staging`) so all install side by side
- **MUST** distinguish flavors visually — app name suffix and/or launcher icon badge.
  A dev build **MUST NOT** be mistakable for prod on a client's device

### 2. Configuration

- **MUST** inject runtime config via `--dart-define-from-file` or flavor config classes
- **MUST NOT** switch base URLs on `kDebugMode`. Debug/release is a build mode, not an
  environment — conflating them is how staging URLs reach production.
  This applies to **environment configuration** (base URLs, API keys, feature flags).
  Using `kDebugMode` or `kReleaseMode` for developer tools (debug banners, logging
  verbosity, performance overlays) is fine and expected.

### 3. Secrets

- **MUST NOT** commit: secrets, keystores, production `google-services.json`, `.p8`/`.p12`
  files, or `.env` files with real values. Commit `.env.example` only
- Secrets **MUST** live in the agency password manager
- Keystores **MUST** live in the agency vault with a per-project entry recording alias,
  passwords, SHA-1/SHA-256, and creation date
- **Losing a release keystore is unrecoverable and forces a new store listing.** Back it
  up at kickoff, **verify the backup restores**, and record it in `PROJECT_PROFILE.md`
- **MUST** store tokens in secure storage, never in plain preferences

### 4. Verification

Before the first release, confirm on a real device that the prod flavor shows prod
config, and the dev flavor cannot reach production data.

## Seams

**Provides** — `env.config_injection` = dart-define file or flavor config class.
**Expects** — `release.flavor_names`.

## Review checklist

- [ ] No secrets, keystores, or real `.env` values in the diff
- [ ] Config injected via dart-define/flavor config, not build-mode branching
- [ ] New config keys added to `.env.example`
- [ ] Tokens in secure storage

## Agent notes

- Agents **MUST NOT** read or write real `.env` files, keystores, or vault entries
- Agents commonly hardcode a base URL to get something running. Grep the diff for
  literal URLs
- When adding a config key, the agent **MUST** update `.env.example` in the same change

## Parameters

`parameters.release.flavors` (via `release.flavor_names`).
