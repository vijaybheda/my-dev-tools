---
module: release-fastlane
category: release
version: 1.0
replaces: [release-manual]
requires_seams: []
provides_seams: [release.flavor_names, release.artifact_path]
status: active
---

# Release — Fastlane + CI

## Scope

Automated build, sign, upload, and release. Target state for every project over ~4 months.

## When to select

- Projects lasting over ~4 months, or any project with more than one developer
- Any project already on CI
- Migrating from `release-manual` — pilot on one project first

## Rules

### 1. Phase 1 — local Fastlane

1. **MUST** create `fastlane/` in both `android/` and `ios/`
2. **MUST** define lanes: `beta` (internal track / TestFlight) and `release` (production)
3. **MUST** use `match` for iOS signing with a private certificates repo — this ends
   "works only on one Mac"
4. **MUST** source Android signing from `key.properties` populated by env vars.
   Keystores and `key.properties` **MUST NOT** be committed
5. **MUST** keep lanes idempotent and runnable from a clean checkout

### 2. Phase 2 — CI-triggered

1. **MUST** run `analyze` on every PR as a required check
2. **MUST** trigger the release lane from a tag push on `main` — not from a branch, not
   manually
3. **MUST** store secrets in the CI secret store; keystores base64-encoded as secrets
4. **MUST** auto-upload mapping files and dSYMs to the crash reporter

### 3. Phase 3 — full pipeline

1. **SHOULD** derive the build number from the CI run number — monotonic by construction
2. **SHOULD** draft the changelog from Conventional Commits
3. **SHOULD** notify Slack/email on successful upload

### 4. Definition of done for the migration

> A developer can ship a release by pushing a tag — **and cannot ship one any other way.**

Until the second half is true, the migration is incomplete: a manual escape hatch means
the pipeline's guarantees are optional, and the failure modes in `release-manual` return.

### 5. Guardrails

- **MUST NOT** let CI push directly to `main`
- **MUST NOT** print secrets in CI logs; mask all injected values
- **MUST** keep the keystore backed up in the agency vault independently of CI. Losing a
  release keystore is unrecoverable and forces a new store listing
- **MUST** verify the pipeline still produces an installable build after any signing,
  Xcode, or Gradle upgrade

## Seams

**Provides**
- `release.flavor_names` = `parameters.release.flavors`
- `release.artifact_path` = CI artifact store

**Expects** — nothing.

## Review checklist

- [ ] Lane changes verified from a clean checkout, not just locally
- [ ] No secrets, keystores, or `key.properties` in the diff
- [ ] Version/build derivation unchanged or deliberately migrated
- [ ] Required checks still enforced on `main` after any workflow edit

## Agent notes

- Agents **MUST NOT** modify CI workflow files, Fastlane lanes, signing configuration, or
  anything under `android/app/build.gradle` signing blocks. They **MAY** propose a diff
  for human review.
- Agents **MUST NOT** be given CI secrets or keystore access under any configuration.
- A CI failure is triage input for an agent, not a licence to edit the pipeline.

## Parameters

- `parameters.release.flavors`
- `parameters.release.store_accounts_owned_by`
