---
module: release-manual
category: release
version: 1.0
replaces: [release-fastlane]
requires_seams: []
provides_seams: [release.flavor_names, release.artifact_path]
status: active
---

# Release — manual

## Scope

Build, sign, upload, and store submission performed by hand. Interim state until
`release-fastlane` is adopted.

## When to select

- No CI yet, or a project too short-lived to justify pipeline setup
- A pilot project ahead of the Fastlane migration

**MUST** be treated as temporary on any project lasting over ~4 months. Manual releases
fail in predictable ways (§4) and every failure costs a store round-trip.

## Rules

### 1. Sequence — no shortcuts, no one-off local builds shipped to stores

1. QA sign-off complete
2. `git checkout main && git pull` — release only from `main`
3. Bump version + build number; commit `chore(release): v1.4.0+42`
4. `fvm flutter clean && fvm flutter pub get`
5. `fvm flutter analyze` → zero issues
6. Android: `fvm flutter build appbundle --release --flavor prod --dart-define-from-file=env/prod.json`
7. iOS: `fvm flutter build ipa --release --flavor prod --dart-define-from-file=env/prod.json`
8. Install the **release** artifact on a **physical device**; verify the core flow
9. Upload: Play Console → internal track; App Store Connect → TestFlight
10. `git tag v1.4.0+42 && git push --tags`
11. Archive artifacts + `mapping.txt` + dSYMs to the project's release folder
12. Promote to production only after internal/TestFlight verification

### 2. Rollout

- Android staged rollout: 10% → 50% → 100%, watching crash-free rate between steps
- iOS phased release on, except for hotfixes
- Release notes in user language, drafted from `CHANGELOG.md`

### 3. Store accounts

**SHOULD** be client-owned (`parameters.release.store_accounts_owned_by`). Agency-owned
accounts create ownership disputes at handover.

### 4. Known failure modes — check every single release

- [ ] Build number bumped and never reused
- [ ] Built the **prod** flavor, not dev
- [ ] Signed with the release keystore, not debug
- [ ] `pub get` run after the version bump
- [ ] `mapping.txt` / dSYMs uploaded to the crash reporter
- [ ] Correct `.env` / dart-define file
- [ ] Working tree clean and pushed

### 5. Rejections

Log the rejection reason in the release folder, fix, resubmit, and **MUST** add the
cause to the QA checklist so it cannot recur.

## Seams

**Provides**
- `release.flavor_names` = `parameters.release.flavors`, default `[dev, staging, prod]`
- `release.artifact_path` = the project's release archive folder

**Expects** — nothing.

## Review checklist

Applies to the release PR:

- [ ] Version and build number bumped correctly
- [ ] `CHANGELOG.md` updated in client-readable language
- [ ] Release artifact installed on physical hardware and verified
- [ ] Mapping/symbol files archived

## Agent notes

- Agents **MUST NOT** execute any step of this sequence. Releases touch signing material
  and store accounts; both are outside agent scope per `agents-core`.
- An agent **MAY** draft release notes from the changelog and **MAY** prepare the version
  bump commit for human review.

## Parameters

- `parameters.release.flavors`
- `parameters.release.store_accounts_owned_by`
