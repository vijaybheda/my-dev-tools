---
module: refactoring-tech-debt
category: process
version: 1.0
replaces: []
requires_seams: [docs.registry]
provides_seams: [process.debt_allocation]
status: active
---

# Process — refactoring & technical debt

## Scope

How debt is recorded, prioritized, and paid down. Ported from Employee Handbook v1.0 §13.

## Rules

1. **MUST** record debt in `REFACTORING.md` using the item template: ID, status,
   priority, effort, problem, current implementation, recommendation, benefit,
   acceptance criteria.
2. **MUST** record it **when found**, not later. Debt discovered mid-ticket and not
   written down becomes folklore — known to one person, invisible at planning.
3. **MUST** review `REFACTORING.md` in sprint planning.
4. **MUST** allocate 20% of sprint capacity to debt, spent **from this list**, ordered by
   impact over effort — not on whatever irritated someone that week.
5. **MUST** close items when resolved, noting the PR.
6. **MUST NOT** bundle **significant** refactoring (changing structure, moving files,
   redesigning interfaces) into a feature PR. A refactor riding along in a feature
   diff can't be reviewed properly and can't be reverted separately. Raise a `REF-`
   item and do it in its own PR.
   Incidental improvements (renaming, const-correctness, fixing comments, removing
   dead code within the touched file) **SHOULD** be included if they make the feature
   diff clearer. Rule of thumb: if the refactoring could meaningfully break something
   or obscure the feature review, it's a separate PR.
7. **MUST NOT** open a refactor that cannot be finished in one sprint without splitting
   it into landable steps, each leaving the codebase working.
8. Debt that blocks a release is a **defect**, not debt. It goes to the ticket board.

## What counts

Existing debt, code-quality issues, performance opportunities, architecture improvements,
duplication, deprecated implementations, security improvements, UX gaps.

## Seams

**Provides** — `process.debt_allocation` = 20% of sprint capacity.
**Expects** — `docs.registry` for `REFACTORING.md`.

## Review checklist

- [ ] No opportunistic refactoring bundled into a feature PR
- [ ] Debt found during this work recorded in `REFACTORING.md`
- [ ] Resolved items closed with the PR noted

## Agent notes

- Agents refactor adjacent code unprompted — renaming, reorganizing, "cleaning up" files
  the ticket never mentioned. This is the most common cause of unreviewably large agent
  diffs. **MUST** stay inside the approved plan's file list.
- An agent that notices debt **SHOULD** propose a `REF-` entry rather than fixing it inline.
- **MUST NOT** treat a `REF-` item as licence to refactor beyond its acceptance criteria.

## Parameters

`parameters.process.debt_capacity_percent` — defaults to 20.
