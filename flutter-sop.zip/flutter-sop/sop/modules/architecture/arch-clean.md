---
module: arch-clean
category: architecture
version: 1.0
replaces: [arch-lite, arch-standard]
requires_seams: []
provides_seams: [layout.feature_root, layout.layers, boundary.repository]
status: active
---

# Architecture — Full Clean

## Scope

Folder layout, layering, dependency rules, and the UI↔data boundary for long-lived and
domain-heavy products.

## When to select

- Lifespan 2+ years, or a product rather than a project
- Offline-first, sync, or genuinely complex business rules and state machines
- A client engineering team will inherit or co-develop it
- Three or more developers

This module costs real time up front. **MUST NOT** be selected because it feels rigorous
— select it because the project's lifespan and domain justify the cost.

## Rules

1. **MUST** use the full layer set per feature.

```
lib/
  main.dart
  bootstrap.dart
  app/            router/  theme/  di/
  core/           config/  network/  storage/  errors/  extensions/  utils/
  features/
    <feature>/
      presentation/     # screens, widgets, controllers, view state
      domain/
        entities/       # pure Dart, zero framework imports
        repositories/   # abstract interfaces
        usecases/       # one public method each
      data/
        models/         # DTOs + serialization
        datasources/    # remote/ and local/
        repositories/   # implementations
        mappers/        # DTO ↔ entity
  shared/         widgets/  models/
```

2. **MUST** keep `domain/` free of every framework import — no Flutter, no HTTP client,
   no database, no serialization package. Pure Dart only. This is the load-bearing rule
   of the module; enforce it in review.
3. **MUST** route presentation through **usecases**, not repositories directly.
4. Each usecase **MUST** expose exactly one public method (`call`/`execute`) and one
   responsibility.
5. **MUST** separate remote and local datasources. The repository implementation owns
   the caching, fallback, and conflict policy — not the UI, not the datasource.
6. **MUST** define an explicit offline/sync policy per feature in the repository, and
   document it in a header comment: source of truth, staleness window, conflict rule.
7. **MUST** map DTO ↔ entity in `data/mappers/`. Entities **MUST NOT** carry
   serialization concerns.
8. **MUST** express failures as typed domain failures crossing the `domain` boundary.
9. **MUST NOT** import another feature's internals. Shared entities are promoted to
   `shared/`; shared behaviour becomes a core service.

## Seams

**Provides**
- `layout.feature_root` = `lib/features/<feature>/`
- `layout.layers` = `[presentation, domain, data]` with the sub-structure above
- `boundary.repository` = abstract repository in `domain/repositories/`, reached from
  presentation **only through a usecase**

**Expects** — nothing.

## Review checklist

- [ ] `domain/` has zero framework imports (grep the diff for `package:flutter`,
      the HTTP client, and the serialization package under `domain/`)
- [ ] Presentation calls usecases, never repositories directly
- [ ] One public method per usecase
- [ ] Remote and local datasources separated; caching policy in the repository impl
- [ ] Mappers present; entities free of serialization
- [ ] Typed failures crossing the domain boundary
- [ ] Offline/sync policy documented for any feature with local persistence

## Agent notes

- This is the architecture agents produce most fluently, which makes shallow errors easy
  to miss. The two to check every time: a framework import leaking into `domain/`, and
  presentation reaching past a usecase to a repository.
- **MUST** generate the mapper and the failure type alongside any new datasource.
- **MUST NOT** let an agent "simplify" by skipping a usecase because it feels
  pass-through — on this module that is a rule, not a preference.

## Parameters

`parameters.architecture.layers` — informational.
