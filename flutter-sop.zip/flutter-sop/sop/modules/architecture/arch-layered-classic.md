---
module: arch-layered-classic
category: architecture
version: 1.0
replaces: [arch-lite, arch-standard, arch-clean]
requires_seams: []
provides_seams: [layout.feature_root, layout.layers, boundary.repository]
status: active
---

# Architecture — Layered Classic

## Scope

The layer-first structure defined in Employee Handbook v1.0 §6.1, preserved as a module.
Governs folder layout, layering, and the UI↔data boundary.

## When to select

- **Every project that predates SOP v2.0.** This module exists so existing codebases are
  compliant as written, not retroactively in violation
- New projects where the client or an inherited codebase already uses this layout
- Teams who genuinely prefer it and will apply it consistently

For **new greenfield** work, prefer `arch-standard` (or `arch-lite` / `arch-clean` by
profile). Feature-first scales better once a codebase passes roughly 8–10 features:
in layer-first, a single feature's code spreads across five top-level folders, so every
change touches distant directories and merge conflicts concentrate in shared folders.
That cost is real but it is not a reason to migrate a working codebase — see §Migration.

## Rules

1. **MUST** use the layer-first structure:

```
lib/
├── main.dart
├── app.dart
├── core/          constants/  theme/  utils/  extensions/  errors/  di/
├── data/          models/  repositories/  datasources/  mappers/
├── domain/        entities/  repositories/  usecases/
├── presentation/  pages/  widgets/  blocs/  viewmodels/
├── services/      api/  local_storage/  push_notifications/  analytics/  logging/
└── routing/       app_router.dart  route_names.dart
```

2. **MUST** keep the dependency direction inward: `presentation → domain ← data`.
   `domain/` **MUST NOT** import from `presentation/`, `data/`, or `services/`.
3. **MUST** declare repository interfaces in `domain/repositories/` and implementations
   in `data/repositories/`.
4. **MUST NOT** expose raw API responses to the UI. Map DTOs to domain entities in
   `data/mappers/` before presentation.
5. **MUST** group by feature **inside** each layer — `presentation/pages/checkout/`,
   `data/repositories/checkout_repository.dart`. Flat folders holding 40 unrelated files
   are the main failure mode of this layout; grouping inside the layer contains it.
6. `services/` holds app-wide, cross-feature infrastructure. Feature-specific logic
   **MUST NOT** live there.
7. **MUST** document any deviation in `STRUCTURE.md` with justification and tech-lead
   approval (Handbook §6.2), and mirror it in `sop.manifest.yaml` `deviations:`.

## Migration

Do **not** run a big-bang migration to feature-first. If a project outgrows this layout:

1. Add `lib/features/` alongside the existing layers
2. Build **new** features feature-first there
3. Move an existing feature only when you're already substantially rewriting it
4. Record the hybrid state in `STRUCTURE.md` so nobody "fixes" it halfway

A permanent, documented hybrid beats a migration that stalls at 60%.

## Seams

**Provides**
- `layout.feature_root` = grouped subfolders within each layer (no single feature root)
- `layout.layers` = `[core, data, domain, presentation, services, routing]`
- `boundary.repository` = interface in `domain/repositories/`

**Expects** — nothing.

## Review checklist

- [ ] Files placed in the correct layer; nothing feature-specific in `services/`
- [ ] `domain/` imports no framework, no `data/`, no `presentation/`
- [ ] Repository interface in `domain/`, implementation in `data/`
- [ ] DTOs mapped to entities before reaching UI
- [ ] Grouped by feature inside the layer, not dumped flat
- [ ] Any deviation recorded in `STRUCTURE.md` and the manifest

## Agent notes

- Because a feature spans five top-level folders, agents **MUST** be told every file a
  change touches. Run Plan mode first and confirm the file list is complete — a
  half-applied feature here compiles and fails at runtime.
- Agents default to creating `lib/features/` from habit. On this module that is wrong
  unless the hybrid migration above has been explicitly approved.
- **MUST** update `FEATURE_MAP.md` when adding or moving a feature. On a layer-first
  codebase the feature map is the only place a feature's files are listed together, so
  it does more work here than under any other architecture module.

## Parameters

None.
