---
module: arch-standard
category: architecture
version: 1.0
replaces: [arch-lite, arch-clean]
requires_seams: []
provides_seams: [layout.feature_root, layout.layers, boundary.repository]
status: active
---

# Architecture — Standard (feature-first, light Clean)

## Scope

Folder layout, layering, and the UI↔data boundary for the typical client app. The
agency default when nothing pushes toward a sibling.

## When to select

- Lifespan 3 months to ~2 years
- Two or more developers working concurrently
- Mixed complexity: real business rules, but not offline-first or heavy domain modelling
- Handover is possible but not certain

Pick `arch-lite` for demos and sub-3-month builds. Pick `arch-clean` when the domain is
genuinely complex, the app is offline-first, or a client engineering team inherits it.

## Rules

1. **MUST** use three layers per feature.

```
lib/
  main.dart
  bootstrap.dart
  app/            router/  theme/
  core/           config/  network/  storage/  errors/  extensions/  utils/
  features/
    <feature>/
      presentation/     # screens, widgets, controllers
      domain/           # entities, repository INTERFACE
      data/             # models (DTOs), datasources, repository IMPL
  shared/         widgets/  models/
```

2. **MUST** declare the repository **interface** in `domain/` and the implementation in
   `data/`. Presentation depends on the interface only.
3. **MUST** keep the dependency direction inward: `presentation → domain ← data`.
   `domain` **MUST NOT** import from `presentation` or `data`.
4. **MUST** keep DTOs in `data/` and entities in `domain/`, with mapping in `data/`.
   JSON annotations **MUST NOT** appear on entities that differ from their DTOs.
   When entity and DTO are **structurally identical**, a single model with JSON
   annotations in `data/` **MAY** serve both layers, with the commitment to split
   when they diverge. Record this decision in the feature's code comments.
5. **Usecases are optional** and **SHOULD** be added only where they earn it:
   orchestration across two or more repositories, or an isolated business rule.
   A usecase that forwards one call to one repository **MUST NOT** be written.
6. `core/` holds cross-cutting infrastructure. A thing used by one feature **MUST**
   live in that feature.
7. **MUST NOT** import another feature's `data/` or `domain/`. If two features need the
   same entity, promote it to `shared/`.

## Seams

**Provides**
- `layout.feature_root` = `lib/features/<feature>/`
- `layout.layers` = `[presentation, domain, data]`
- `boundary.repository` = the repository interface in `domain/`

**Expects** — nothing. The state module decides where controllers live within
`presentation/`; this module only guarantees the folder exists.

## Review checklist

- [ ] Three layers present; dependency direction inward
- [ ] Repository interface in `domain/`, implementation in `data/`
- [ ] No JSON/serialization annotations on entities
- [ ] Every usecase earns its existence (multi-repo or business rule)
- [ ] No cross-feature imports of `data/` or `domain/`
- [ ] Nothing feature-specific parked in `core/`

## Agent notes

- Agents over-generate usecases. **MUST NOT** create pass-through usecases; reviewers
  reject them and the agent's plan should be corrected before code is written.
- Agents frequently place the repository interface in `data/`. Verify the interface is
  in `domain/` — this is the single most common structural defect in agent output here.
- When adding a feature, the agent **MUST** scaffold all three layers even if `domain/`
  starts with only the interface.

## Parameters

`parameters.architecture.layers` — informational; must equal `[presentation, domain, data]`.
