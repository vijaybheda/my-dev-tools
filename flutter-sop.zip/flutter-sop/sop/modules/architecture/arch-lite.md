---
module: arch-lite
category: architecture
version: 1.0
replaces: [arch-standard, arch-clean]
requires_seams: []
provides_seams: [layout.feature_root, layout.layers, boundary.repository]
status: active
---

# Architecture — Lite (two layers)

## Scope

Folder layout, layering, and the UI↔data boundary for short-lived projects. Governs
structure only — not state management or navigation.

## When to select

- Lifespan under ~3 months, or a demo/pitch build
- Solo developer, or two who don't overlap
- CRUD over a stable API; no offline sync, no complex domain rules
- No handover to a client engineering team

Pick `arch-standard` the moment two or more devs work concurrently, or the domain grows
real rules. Pick `arch-clean` for multi-year or offline-first products.

**Deliberate trade-off:** this module accepts that a successful MVP will need migrating.
That is cheaper than layering a product that never ships.

## Rules

1. **MUST** use two layers per feature: `presentation/` and `data/`.

```
lib/
  main.dart
  bootstrap.dart
  app/            router/  theme/
  core/           config/  network/  storage/  errors/  extensions/
  features/
    <feature>/
      presentation/     # screens, widgets, controllers
      data/             # models, datasource, repository
  shared/         widgets/  models/
```

2. **MUST** put a repository class in `data/`. UI calls the repository; **MUST NOT**
   call the HTTP client or local store directly.
3. **MUST NOT** create a `domain/` layer, entity classes that mirror models 1:1, or
   usecase classes that wrap a single repository call. On this profile that is
   ceremony, and reviewers reject it.
4. Data models **MAY** double as UI models. No mapper layer required.
5. **MUST** keep repositories returning typed results or throwing mapped exceptions —
   raw client exceptions **MUST NOT** reach the UI.
6. **SHOULD** keep a feature under ~8 files. Beyond that, either split the feature or
   the project has outgrown this module — raise it with the Mobile Lead.

## Migration signal

Any two of these means the project has outgrown `arch-lite`; propose `arch-standard`:

- A repository exceeding ~200 lines
- The same business rule duplicated in two controllers
- A third developer joining
- Offline behaviour entering scope

Migration is incremental: introduce `domain/` in the feature being touched, leave the
rest. Do not stop feature work for a big-bang refactor.

## Seams

**Provides**
- `layout.feature_root` = `lib/features/<feature>/`
- `layout.layers` = `[presentation, data]`
- `boundary.repository` = the repository class in `data/`

**Expects** — nothing.

## Review checklist

- [ ] Exactly two layers; no `domain/` folder
- [ ] No usecase classes wrapping single repository calls
- [ ] UI touches only the repository, never the HTTP client or local store
- [ ] No cross-feature imports of another feature's `data/`

## Agent notes

Agents drift toward generic Clean Architecture regardless of the brief — it dominates
their training data. On this module that drift is a **defect**.

- **MUST NOT** generate `domain/`, entities, or usecases.
- **MUST NOT** add a mapper between data model and UI model.
- If a plan proposes those, reject the plan before letting the agent write code.

## Parameters

None.
