---
document: SOP-CORE
version: 1.0
applies: every Flutter project, always, without exception
---

# SOP — Core

**Audience:** Flutter developers, QA, project leads, AI coding agents
**Owner:** Mobile Lead

This document holds only what is true on **every** project regardless of client, stack,
or architecture. Everything technology-specific lives in a module selected in the
project's `sop.manifest.yaml`.

**Core never names a framework, package, or architecture.** If a rule mentions BLoC,
go_router, or Fastlane, it belongs in a module. That constraint is what keeps core stable.

---

## 1. Roles

| Role | Owns |
|---|---|
| **Mobile Lead** | Module selection sign-off, release approval, credentials, this SOP |
| **Flutter Developer** | Implementation, PR quality, self-review |
| **Reviewer** | PR review against §7 + the selected modules' checklists |
| **QA** | Pre-release verification, device matrix, regression |
| **AI Agent** | Scoped implementation under the `agents-*` modules. Never owns merge, release, or credentials. NEVER writes test cases |

Every project has exactly one named developer as **owner** at all times. Ownership
changes trigger the handover in §11.

---

## 2. Project intake

**No code before intake sign-off.**

- [ ] Scope document received and read
- [ ] Target platforms + **minimum OS versions in writing**
- [ ] Design source confirmed and accessible; final or evolving?
- [ ] Backend: who builds it, API spec available, staging URL exists
- [ ] Third-party dependencies listed — each is a risk item
- [ ] Store accounts: client-owned or agency-created?
- [ ] Timeline, milestones, and maintenance terms agreed

### Kickoff outputs (within 2 working days)

1. **`sop.manifest.yaml` filled in** — module selection is a kickoff decision, made
   deliberately, recorded in writing, and approved by the Mobile Lead
2. `PROJECT_PROFILE.md` completed (Appendix A)
3. Repo created; branch protection enabled (§6.4)
4. Ticket board created; epics split to tickets of ≤2 days
5. Risk list written

### Choosing modules

Score the project on five inputs, then consult each category's module files — every
module's **"When to select"** section answers directly from these.

| Input | Question |
|---|---|
| **Lifespan** | Throwaway MVP, or 2+ year product? |
| **Team size** | Solo, or 2+ devs concurrently? |
| **Domain complexity** | CRUD over an API, or real business rules, offline sync, state machines? |
| **Handover target** | Does the client's in-house team take it over? |
| **Backend stability** | API frozen, or churning? |

Module selection is **locked for the current phase**. Changing it mid-flight needs
Mobile Lead approval, a written migration plan, and an ADR entry in `DECISIONS.md`.
`arch-lite` has explicit migration signals; upgrading when those signals fire is
expected, not exceptional.

**Over-engineering is a defect.** A six-week MVP carrying a long-lived product's module
set has failed selection just as surely as a two-year product carrying an MVP's.

---

## 3. Universal structure rules

These hold under every architecture module. Modules add detail; they cannot revoke these.

- Top-level organization (feature-first vs layer-first) is set by the **architecture
  module**. Core does not mandate one. What core mandates is that a project picks one
  and holds it — a codebase half-migrated between the two is the worst of both.
- **MUST** have a boundary between UI and data access. The UI layer never talks to an
  HTTP client or a database directly. (The module names that boundary.)
- **MUST** keep business logic out of widgets.
- **MUST NOT** import another feature's internals. Promote to shared/core instead.
- **MUST NOT** create a catch-all `common/` or `helpers/` dumping ground. Cross-cutting
  utilities **MUST** live in named, scoped folders under `core/` (e.g., `core/extensions/`,
  `core/errors/`, `core/network/`). Each subfolder of `core/` **MUST** have a clear,
  bounded responsibility.
- **MUST** use one **primary** state-management solution per project. Widget-local
  ephemeral state (animations, toggle visibility, form field state) **MAY** use framework
  primitives (`ValueNotifier`, `AnimationController`) without this constituting "mixing."
- File naming `snake_case.dart`; classes `PascalCase`; one public class per file unless
  tightly coupled.
- **Anti-Static & Dynamic Development Mandate:**
  - UI widgets **MUST NOT** be coded with static stubs, hardcoded dummy lists, or ad-hoc `setState()` action callbacks.
  - User interactions **MUST** be modeled as asynchronous action contracts (Events/Intents).
  - Business domain concepts **MUST NOT** suffer from Primitive Obsession (never use raw `String`, `double`, or `Map` to represent complex domain data). Rich, immutable model classes **MUST** be defined.
  - All data-driven UI screens **MUST** support and verify all 4 states: Loading, Empty, Error (with retry), and Populated.
  - When backend APIs are not yet live, data sources **MUST** simulate latency using `await Future.delayed(const Duration(seconds: 2))` and parse raw JSON strings via `jsonDecode()` through real `@JsonSerializable` DTOs into domain models. Standalone mock classes/files are prohibited.
  - Any static string, simulated delay, or temporary fallback **MUST** carry an explicit `// TODO(api-integration): Replace simulated 2s delay and static JSON with live API endpoint: [METHOD] [URL]` comment.
- **Design System Tokenization & Anti-Literal Law:**
  - Writing raw color literals (e.g. `Color(0x...)`) inside UI screens, widgets, cards, dialogs, or controllers is **STRICTLY FORBIDDEN**. All colors MUST be referenced from the project's color token registry (`AppColors`).
  - Writing raw numeric padding, margins, or arbitrary spacers (e.g. `EdgeInsets.fromLTRB(...)`, `EdgeInsets.symmetric(...)`, `EdgeInsets.all(...)`, `SizedBox(height: ...)`) is **STRICTLY FORBIDDEN**. All layout spacing, margins, gaps, and padding MUST be referenced from the project's spacing token registry (`AppSpacing`).
  - Hardcoding user-facing strings inside UI widgets or presentation controllers is **STRICTLY FORBIDDEN**. All user-facing strings MUST be defined in centralized constants (`AppStrings`) or localized ARB.
  - Default framework icons (`Icons.*`, `CupertinoIcons.*`) are **STRICTLY FORBIDDEN**. All icons MUST use custom vector assets.
  - Automated grep audits (`git grep "Color(0x"`, `git grep "fromLTRB("`) MUST return 0 violations before declaring any work done.
- **Mandatory ListView Development & Layout Rules:**
  - **4-State Handling:** Parent component containing a list view MUST handle Loading (shimmer skeleton), Error (with localized error & retry), Empty (no data illustration & guidance), and Populated states.
  - **Pull-to-Refresh & TODO Protocol:** List screens MUST allow pull-to-refresh (`RefreshIndicator`). If backend refresh handler is not yet wired, an explicit `// TODO(api-integration): Implement pull-to-refresh handler for [Screen/Feature Name]` comment MUST be included.
  - **Scroll Physics & Layout Integrity:** Any screen containing a list MUST scroll smoothly without physics lock or height clipping. Use `physics: const AlwaysScrollableScrollPhysics()` inside `RefreshIndicator` and ensure adequate bottom padding so bottom list items are never obscured.
  - **Dedicated Separate Widget for ListView Items:** Never use components or inline UI layouts inside `ListView`, `ListView.builder`, or `ListView.separated` without a dedicated separate `Widget` class for each item. Inlining multi-line component trees or using `Widget _buildX()` helper methods inside `itemBuilder` is **STRICTLY FORBIDDEN**.

---

## 4. Dependency policy

- Every new package **MUST** be justified in the PR description: what it does, why not
  the stdlib or an existing dependency.
- Bar: active maintenance or demonstrated stability — recent commits, **or** a stable API
  with no open critical issues. A package that is feature-complete and has no outstanding
  bugs does not fail this bar merely by being unchanged. Sound pub.dev score, null-safe,
  supports all target platforms, permissive licence, not single-maintainer abandonware
  for anything critical.
- **MUST NOT** add a package to solve what 30 lines solve.
- `pubspec.lock` **MUST** be committed for app projects.
- Upgrade pass monthly or at the start of any maintenance block.
- Native/plugin upgrades are a **separate PR**, never bundled with feature work.

---

## 5. Documentation each project carries

| File | Holds |
|---|---|
| `sop.manifest.yaml` | Module selection, toolchain pins, parameters, deviations |
| `PROJECT_PROFILE.md` | Client facts, backend, credentials pointers, known debt |
| `README.md` | Fresh machine → running app in under 30 minutes |
| `CHANGELOG.md` | Client-readable release history |
| Agent context file | Per the `agents-*` module |

---

## 6. Git workflow

### 6.1 Branching

```
main        → always releasable, tagged per release, protected
develop     → integration branch (omit on small/solo projects)
feature/<ticket-id>-short-desc
bugfix/<ticket-id>-short-desc
hotfix/<ticket-id>-short-desc     → branched from main
release/<version>                 → cut from develop for release stabilization
```

- **MUST NOT** commit directly to `main`. On any project. Ever.
- Branch per ticket. A branch alive over 5 days means the ticket was too big.
- Rebase on the base branch before opening a PR.

### 6.2 Commits

Conventional Commits, **MUST**:

```
feat(auth): add biometric login
fix(cart): prevent duplicate item on rapid tap
refactor(profile): extract avatar picker widget
chore(deps): bump http client
```

Imperative mood, ≤72-char subject, body explains *why*, ticket ID in body or footer.
**MUST NOT** commit commented-out code or a `TODO` without a ticket ID.
Commented-out code **MAY** be committed only as part of a documented `TODO` with a
ticket ID explaining why it exists and when it will be resolved (e.g.,
`// TODO(PROJ-123): uncomment when backend supports feature X`). Stale commented-out
code (no ticket, or ticket closed) is a defect.

### 6.3 Pull requests

Description **MUST** contain: what changed and why; ticket link; screenshots or recording
for UI changes on every target platform; new dependencies with justification; verification
notes (what, which devices/OS); and agent disclosure per the `agents-*` module.

- **SHOULD** stay under ~400 changed lines of **human-written code**. Generated files
  (`.g.dart`, `.freezed.dart`, `.gr.dart`) are excluded from this count but **MUST**
  be included in the diff for review.
- **MUST** have one approving review from someone other than the author. Solo projects:
  Mobile Lead reviews.
- Squash-merge; delete the branch.

### 6.4 Branch protection (set at kickoff)

`main` and `develop`: no direct push, PR required, 1 approval required, status checks
required once CI exists.

---

## 7. Code review — core checklist

Reviewers work this list **plus** the checklist from every module in the manifest.

**Correctness**
- [ ] Does what the ticket asks; edge cases handled (empty, error, offline, slow network)
- [ ] No regression risk to adjacent features

**Conformance**
- [ ] Matches the modules selected in `sop.manifest.yaml` — not the reviewer's habits
      from another project
- [ ] Respects §3 universal structure rules
- [ ] No undeclared deviation; anything unusual is either justified in the PR or added
      to `deviations:` with approval

**Quality**
- [ ] `flutter analyze` clean, formatted
- [ ] Design tokens enforced: zero raw hex literals (`Color(0x...)`), zero raw numeric `EdgeInsets` literals, zero hardcoded strings. Automated grep audits clean
- [ ] Naming clear; no dead code, commented blocks, or stray prints
- [ ] Errors mapped and surfaced properly; nothing swallowed

**Security**
- [ ] No secrets committed; no sensitive logging; tokens in secure storage

---

## 8. Versioning

`MAJOR.MINOR.PATCH+BUILD`.

- **MAJOR** — breaking redesign or breaking backend contract
- **MINOR** — new features
- **PATCH** — bug fixes only
- **BUILD** — increments on **every** store upload. Never reused, never decremented,
  strictly monotonic across all flavors of one listing.

**MUST** tag `main` as `v<version>+<build>` on every production release.
**MUST** maintain `CHANGELOG.md` in client-readable language.

---

## 9. Release gates

The mechanics live in the selected `release-*` module. These gates hold regardless.

- **MUST** release only from `main`.
- **MUST** install the **release** artifact on a **physical device** and verify the
  core flow before upload. Release builds break in ways debug builds don't.
- **MUST** archive mapping/symbol files with the release — without them crash reports
  are unreadable.
- **MUST** tag and push after a successful upload.
- **MUST NOT** ship a build produced from an unclean or unpushed working tree.

---

## 10. Post-release and hotfix

For 72 hours after every production release the owner checks daily: crash-free rate
(target ≥99.5%), new crash clusters, store reviews, backend error rate.

**Rollback/hotfix trigger:** crash-free below 99%, any crash blocking a core flow, or a
data-loss or security defect.

**Hotfix:** branch from `main` → smallest possible fix, no bundled refactors →
expedited review (still one approval) → PATCH bump → release →
**merge back to `develop` immediately** → written post-mortem naming the checklist item
being added so it can't recur.

---

## 11. Handover

**Dev → dev:** profile and manifest current; README that works on a fresh machine;
access transferred; written tech-debt list; recorded walkthrough; **incoming owner
builds and runs the app before handover counts as complete.**

**Agency → client:** source per contract; credentials and keystores via secure channel
with written confirmation of receipt; build/release docs; a 1–2 page architecture
overview naming the selected modules; warranty window and bug-vs-change-request
definition in writing.

**Maintenance projects:** quarterly SDK upgrade evaluation, dependency refresh, store
target-SDK compliance check. Annual OS releases get a compatibility pass **before** the
OS ships — a scheduled work item, not a surprise.

---

## 12. Onboarding a developer

**Day 1** — read core + the modules for their first project; machine setup; access;
run the app on both platforms.

**Week 1** — ships 2–3 small tickets with reviewed PRs; reviews someone else's PR
against §7 with a senior double-reviewing.

**Month 1 competency bar** — can set up a project from the template; **can justify a
module selection for a given brief**; has produced a release build and installed it on
hardware; has fixed a bug end to end.

---

## Appendix A — `PROJECT_PROFILE.md` template

```markdown
# Project Profile — <Client / App Name>

## Basics
Client · Owner · Repo · Started · Status (active / maintenance / handed over)

## Modules
See sop.manifest.yaml. Summary and the reasoning behind the selection:
- Architecture: <module> — because ...
- State: <module>
- Navigation: <module>
- Release: <module>

## Backend
Base URLs (dev/staging/prod) · Spec location · Auth mechanism · Backend contact

## Third-party
Payments · Push · Analytics/Crash · Maps · Other

## Release
Store accounts owned by · Package name / bundle ID
Keystore location + backup verified ☐ · Signing owner · Current version

## Known issues / tech debt
```

## Appendix B — PR template

```markdown
### What & why

### Ticket

### Screenshots / recording
| Android | iOS |
|---|---|

### New dependencies
none / <package> — <why>

### Verification
Devices/OS verified · Cases covered

### AI assistance
Agent/mode used: none / <agent>
Verified: ☐ read all diffs ☐ ran the flow on device ☐ no invented APIs ☐ no silent deps ☐ no test cases written by agent

### Conformance
- [ ] Matches modules in sop.manifest.yaml
- [ ] analyze clean, formatted
- [ ] no secrets, no debug logging
```

## Appendix C — Definition of Done

1. Acceptance criteria met
2. Merged to the integration branch
3. `analyze` clean
4. Reviewed and approved by another person
5. Verified on every target platform on real hardware or emulator
6. Handles loading / empty / error / offline
7. No new lint warnings; no TODOs without ticket IDs
8. Docs updated if setup, env, or module selection changed
9. QA verified on a build, not on the developer's machine
10. No test cases written or generated by AI agent (agents never write test cases)

---

*Deviations require written justification and Mobile Lead approval, recorded in the
project manifest. Undocumented deviation is a defect.*
