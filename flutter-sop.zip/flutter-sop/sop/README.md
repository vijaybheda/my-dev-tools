# Flutter SOP — modular system

One core. Many swappable modules. Each project picks its modules in a manifest.

## Why

An agency runs different clients on different stacks. A single monolithic SOP either
forces one architecture on everyone (wrong) or hedges every rule into uselessness (worse).

So: **the core holds what never varies. Modules hold what does.**

## Layout

```
sop/
  README.md               ← you are here
  SOP-CORE.md             ← the base. Applies to every project, always.
  MODULE-CONTRACT.md      ← rules for writing or forking a module
  sop.manifest.yaml       ← TEMPLATE. Copy into each project repo and fill in.
  modules/
    architecture/   arch-lite.md · arch-standard.md · arch-clean.md
                    arch-layered-classic.md   ← Handbook v1.0 §6.1 layout
    state/          state-bloc.md
    navigation/     nav-gorouter.md · nav-autoroute.md
    release/        release-manual.md · release-fastlane.md
    agents/         agents-core.md
    standards/      coding-dart-flutter.md · env-flavors-secrets.md
                    logging-monitoring.md · api-integration.md
    docs/           living-docs.md
    process/        refactoring-tech-debt.md
  templates/        CHANGELOG · TASKS · FEATURE_MAP · CONTRIBUTORS · DECISIONS
                    KNOWN_ISSUES · REFACTORING · AGENTS · STRUCTURE
```

The `templates/` files are copied **into the project repo** on day one and maintained
there. They are living documents, not reference material — see `modules/docs/living-docs.md`
for the trigger and owner of each.

## How a project uses it

1. Copy `sop/` into the project repo (or submodule it — see below).
2. Copy `sop.manifest.yaml` to the repo root and select modules for this client.
3. `SOP-CORE.md` + every module named in the manifest = this project's complete SOP.
4. Anything not covered by core or a selected module is **not a rule** on this project.

A module that isn't in the manifest does not apply. Selecting `arch-clean` and
`state-bloc` means the BLoC module's rules are simply absent — not "optional".

## Distribution

**Recommended:** the `sop/` folder lives in one agency repo (`agency-flutter-sop`)
and is pulled into each project as a **git submodule** at `docs/sop/`. Projects pin a
tag. Upgrading the SOP on a project is then a visible, reviewable PR that bumps the
submodule pointer — not a silent drift.

    git submodule add git@github.com:<org>/agency-flutter-sop.git docs/sop
    cd docs/sop && git checkout v1.1.0

**Simpler alternative:** copy the folder in. Faster to start, but projects drift and
improvements don't flow back. Acceptable for short MVPs only.

## Precedence

When two documents disagree:

```
1. Law, client contract, store policy
2. SOP-CORE.md
3. The selected module
4. Documented deviations in PROJECT_PROFILE.md (needs Mobile Lead approval)
```

A module may **add** rules and **narrow** core rules. A module may never **contradict**
core. If it needs to, that's a core bug — fix core, don't fork around it.

## For AI agents

Read in this order, every session:

1. `sop.manifest.yaml` — learn which modules are active
2. `SOP-CORE.md`
3. Every module file the manifest names — and **only** those

Never apply a rule from an unselected module. If you can't find a rule covering the
situation, ask; do not import a convention from another project you have seen.
