# Module contract

Rules for writing, forking, or upgrading a module. Read this before creating one.

## 1. A module is self-contained

A module **MUST** be readable and applicable on its own, given only `SOP-CORE.md`.

- **MUST NOT** reference another module by name, except through the *seams* declared in §4.
- **MUST NOT** assume a sibling module is selected. `arch-clean` cannot assume BLoC.
- **MUST NOT** restate core rules. If you're tempted, core is the right home.
- **MUST NOT** contradict core. If it must, core is wrong — fix core.

Check for independence: swap any one module for a sibling. If another module breaks,
you have a hidden dependency. Move it to a seam or to core.

## 2. Required file shape

Every module file starts with this front matter, then these sections in this order.

```yaml
---
module: arch-standard
category: architecture
version: 1.0
replaces: [arch-lite, arch-clean]     # mutually exclusive siblings
requires_seams: [layout.feature_root] # seams this module consumes
provides_seams: [layout.feature_root, layout.layers]
status: active                        # active | deprecated | experimental
---
```

| Section | Content |
|---|---|
| **Scope** | One paragraph: what this module governs, what it does not |
| **When to select** | The project profile this fits, and when to pick a sibling instead |
| **Rules** | Numbered MUST / SHOULD / MUST NOT. The substance |
| **Seams** | What this module provides to, and expects from, others |
| **Review checklist** | Lines a reviewer adds to the core checklist |
| **Agent notes** | What an AI agent must know or must not do here |
| **Parameters** | Manifest keys this module reads |

## 3. Rule language

- **MUST** / **MUST NOT** — blocks merge. No judgement call.
- **SHOULD** — default yes; deviate with a reason in the PR description.
- **MAY** — genuinely optional.

Anything without one of these words is background, not a rule. Don't write background.

## 4. Seams

Seams are the only legal coupling between modules. A seam is a named contract:
one module **provides** it, others **consume** it, and neither knows the other's identity.

| Seam | Provided by | Meaning |
|---|---|---|
| `layout.feature_root` | architecture | Where a feature's code lives: `lib/features/<feature>/` |
| `layout.layers` | architecture | Which layer folders exist inside a feature |
| `boundary.repository` | architecture | The type UI is allowed to talk to |
| `state.controller_location` | state | Which layer holds controllers/notifiers/blocs |
| `state.async_states` | state | How loading/error/data are represented |
| `nav.route_registry` | navigation | Where routes are declared |
| `nav.guard_hook` | navigation | Where auth/redirect guards attach |
| `release.flavor_names` | release | Flavor names other modules can rely on |

If you need coupling that isn't a seam, propose a new seam in a PR against this file.
Do not hardcode a cross-module reference.

## 5. Versioning

Semver on each module.

- **Patch** — wording, examples, typos. No rule change.
- **Minor** — new rule that existing compliant code already satisfies.
- **Major** — a rule that makes existing compliant code non-compliant. Requires a
  migration note in the module and Mobile Lead sign-off before any project adopts it.

Projects pin the SOP repo ref in `sop.manifest.yaml`. Upgrading is an explicit PR.

## 6. Forking a module for one client

Do **not** edit a shared module for one client's needs. Instead:

1. Small difference → add a `deviations:` entry in that project's manifest.
2. Persistent, client-specific difference → create a new sibling module
   (`arch-standard-acme.md`), mark `replaces: [arch-standard]`, and select it in
   that project's manifest only.

Editing a shared module for one client silently changes every other project.

## 7. Retiring a module

Set `status: deprecated`, add a `migrate_to:` key and a short migration note. Keep the
file for at least two quarters — projects pinned to older refs still resolve it.
Delete only when no active project's manifest names it.
