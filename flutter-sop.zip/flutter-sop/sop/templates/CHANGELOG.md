# Changelog

All notable changes to this project. Format: [Keep a Changelog](https://keepachangelog.com).
Versioning: [Semantic Versioning](https://semver.org) as `MAJOR.MINOR.PATCH+BUILD`.

Entries are written for the people who use the app, not for the people who wrote it.

## [Unreleased]

### Added
- 

### Changed
- 

### Fixed
- 

### Internal
- 

---

## [1.2.0+58] — 2026-08-20

### Added
- Save a delivery address during checkout and reuse it on later orders
- Arabic language support

### Changed
- Order history now loads 20 at a time instead of all at once, so the screen opens faster

### Fixed
- Fixed a crash when opening an order from a push notification on a cold start
- Fixed the cart total not refreshing after removing the last item

### Security
- Session tokens now clear on logout across all devices

## [1.1.0+41] — 2026-07-14

### Changed
- **BREAKING:** Minimum supported Android version is now 8.0. Devices on 7.x will stay
  on 1.0.x and no longer receive updates.

### Fixed
- Fixed the profile photo failing to upload on slow connections
