# AGENTS.md — <App Name>

Instructions for AI coding agents working in this repository.
**Read this file, then `sop.manifest.yaml`, before doing anything else.**

Precedence: law/contract → `SOP-CORE.md` → the selected modules → approved deviations in
the manifest. When this file and a module disagree, the module wins and this file is
stale — say so rather than following it.

---

## 1. Active modules

Copy from `sop.manifest.yaml` and keep in sync. **This is the most important section in
the file** — without it you will apply whatever convention your training data favours,
which is the largest single source of architectural drift here.

| Category | Module |
|---|---|
| Architecture | `<e.g. arch-layered-classic>` |
| State | `<e.g. state-bloc>` |
| Navigation | `<e.g. nav-gorouter>` |
| Release | `<release-manual>` |
| Agents | `<agents-core>` |
| Standards | `<coding-dart-flutter, env-flavors-secrets, logging-monitoring, api-integration>` |
| Docs | `<living-docs>` |

Rules from modules **not** listed here do not apply. Do not import a convention from
another project you have seen.

## 2. Toolchain

- Flutter `<x.y.z>` via `fvm` — always `fvm flutter ...`, never bare `flutter`
- Dart `<x.y.z>` · Min Android SDK `<n>` · Min iOS `<n>`
- Codegen: `fvm dart run build_runner build --delete-conflicting-outputs`

## 3. Read before planning

1. `FEATURE_MAP.md` — where the feature you're touching lives
2. `DECISIONS.md` — whether your approach was already considered and rejected
3. `STRUCTURE.md` — any approved deviation from the architecture module
4. The relevant `docs/api/*.md` if the change touches an endpoint

## 4. Workflow

Plan → human review → implement. **Mandatory** for anything touching more than three
files or adding a feature.

1. **Plan mode.** Produce a Markdown plan: overview, architecture decisions, file-by-file
   changes, new dependencies, rollback. Write no implementation.
2. **Stop.** The developer reviews and revises the plan. A wrong plan caught here costs a
   minute; caught in review it costs an afternoon.
3. **Code mode**, scoped to the files in the approved plan.
4. **Debug mode** for a specific defect: fix only, no refactors.

One ticket = one task = one branch.

## 5. Never do these

- Merge, release, or tag
- Touch keystores, `.env` with real values, CI secrets, or store credentials
- Modify: signing blocks, `ios/Runner.xcodeproj`, CI workflow files, `pubspec.lock`,
  generated files by hand
- Run `rm -rf`, force push, `git reset --hard` on a shared branch, or a DB migration
- Add a dependency without asking
- Log tokens, passwords, OTPs, or PII — see the logging module

## 6. Documentation you must update

In the **same change** as the code. Never as a follow-up.

| Document | When |
|---|---|
| `CHANGELOG.md` | Any user-facing change → `## [Unreleased]`, user-facing language |
| `FEATURE_MAP.md` | Feature added, renamed, moved, retired |
| `TASKS.md` | Task state changed; name the blocker if blocked |
| `DECISIONS.md` | The change closed off alternatives |
| `CONTRIBUTORS.md` | A new person or agent contributed |
| `KNOWN_ISSUES.md` | A defect is being shipped unfixed |
| `REFACTORING.md` | Debt found, or an item resolved |
| `docs/api/*.md` | An API contract changed |
| `README.md` | Setup steps changed |

**Do not fabricate.** Every changelog line, file path, and contributor entry must
correspond to something real in the diff. Plausible-sounding documentation is the most
damaging thing you can produce here — it reads correct and nobody re-verifies it.

**Do not rewrite history:** no editing released changelog sections, no editing past ADRs,
no removing departed contributors. Do not mass-reformat a document while making an
unrelated change.

If you cannot tell whether a change is user-facing, **ask**.

## 7. Definition of done

1. Matches the modules in §1
2. `fvm flutter analyze` clean, `dart format` applied
3. Documentation in §6 updated in this change
4. No secrets, no debug logging, no `print()`
5. Handles loading / empty / error / offline
6. Ran on a device or emulator — state which

## 8. What to do when unsure

Ask. Do not infer a convention from surrounding code — this codebase may be mid-migration,
in which case the surrounding code will teach you the wrong thing. Do not silently pick
the more common industry pattern. A question costs a minute; a wrong convention spreads
through every file you touch afterwards.
