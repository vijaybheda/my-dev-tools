# Feature map

Answers one question: **where does this feature live?**

Read this before planning any change. Update it in the same PR whenever a feature is
added, renamed, moved, or retired.

Architecture module in use: `<from sop.manifest.yaml>` — file paths below follow it.

---

## Active features

### Authentication

| Field | Value |
|---|---|
| **Owner** | <dev> |
| **Status** | Stable |
| **Entry route** | `Routes.login` → `/login` |
| **Feature flag** | none |

**Code**
- `presentation/pages/auth/` — login, OTP, forgot password screens
- `presentation/blocs/auth/` — auth bloc, session controller
- `domain/usecases/auth/` — sign_in, sign_out, refresh_session
- `data/repositories/auth_repository_impl.dart`
- `services/api/interceptors/auth_interceptor.dart` — token attach + 401 refresh

**API** — `POST /auth/login` · `POST /auth/refresh` · `POST /auth/logout`
→ `docs/api/authentication.md`

**Notes** — Session refresh is interceptor-driven. A 401 on refresh itself forces logout;
don't add a second refresh path.

---

### Checkout

| Field | Value |
|---|---|
| **Owner** | <dev> |
| **Status** | In progress (PROJ-214) |
| **Entry route** | `Routes.checkout` → `/cart/checkout` |
| **Feature flag** | `saved_addresses` (staging on, prod off) |

**Code**
- `presentation/pages/checkout/`
- `presentation/blocs/checkout/`
- `domain/usecases/checkout/` — place_order, validate_cart
- `data/repositories/checkout_repository_impl.dart`
- `data/mappers/order_mapper.dart`

**API** — `GET /cart` · `POST /orders` · `GET /addresses` · `POST /addresses`
→ `docs/api/checkout.md`

**Notes** — Payment runs through the sandbox gateway in dev and staging. Never point a
non-prod flavor at the live gateway.

---

## Cross-cutting

| Concern | Lives in | Owner |
|---|---|---|
| Routing | `routing/app_router.dart`, `routing/route_names.dart` | <dev> |
| Theme | `core/theme/` | <dev> |
| Logging | `services/logging/` | <dev> |
| API client | `services/api/` | <dev> |
| DI registration | `core/di/` | <dev> |
| Localization | `l10n/*.arb` | <dev> |

---

## Retired

| Feature | Removed in | Reason | Notes |
|---|---|---|---|
| In-app chat | 1.1.0 | Replaced by third-party support widget | Do not resurrect `presentation/pages/chat/` — the backend endpoints are gone |

> Retired entries stay. They are what stops someone rebuilding something that was
> deliberately removed.
