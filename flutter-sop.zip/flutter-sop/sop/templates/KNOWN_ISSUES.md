# Known issues

Defects we have shipped or are shipping with, and what to tell someone who hits them.

**An issue is recorded here before the release goes out, not after a user reports it.**
If QA found it and we shipped anyway, it belongs here.

| ID | Symptom | Severity | Affected versions | Workaround | Ticket | Status |
|---|---|---|---|---|---|---|
| KI-004 | Profile photo upload fails on connections slower than ~50 kbps; no error shown | Medium | 1.2.0+ | Retry on a better connection | PROJ-233 | Open |
| KI-003 | Arabic layout clips the order-total row at 1.3× text scale | Low | 1.2.0 | None | PROJ-231 | Fix in 1.2.1 |
| KI-002 | Cold-start deep link to a retired route shows the error screen instead of home | Low | 1.1.0–1.2.0 | Open the app first, then the link | PROJ-228 | Open |
| KI-001 | Push tokens not refreshed after a 30+ day gap between sessions | High | 1.0.x | Reinstall | PROJ-210 | Fixed in 1.1.0 |

## Severity

| Level | Meaning |
|---|---|
| **Critical** | Data loss, security defect, or a core flow blocked. Do not ship — hotfix |
| **High** | A core flow degraded, or a common path broken with no workaround |
| **Medium** | A secondary flow broken, or a workaround exists |
| **Low** | Cosmetic, or affects a narrow configuration |

Fixed issues stay listed for two releases with the fixing version noted, then move out —
support needs them while older versions are still in the wild.
