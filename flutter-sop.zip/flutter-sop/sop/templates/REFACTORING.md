# Refactoring backlog

Technical debt, tracked as work rather than folklore. Reviewed in sprint planning; the
20% capacity allocation (Handbook §13.3) is spent from **this list**, not from whatever
felt annoying that week.

Close items when resolved and note the PR. An open list of already-fixed items trains
everyone to ignore the list.

---

## REF-004: Extract duplicate API error handling

**Status:** Open · **Priority:** High · **Effort:** 2 days · **Raised:** 2026-08-10

### Problem
API error parsing is duplicated across 12 repository files.

### Current implementation
Each repository implements its own error mapping, so a new error type must be added in
twelve places and has already been missed in three.

### Recommended improvement
Extract into an `ApiErrorHandler` used by the response interceptor.

### Expected benefit
- Removes roughly 200 duplicated lines
- One place to change error handling
- Consistent `ApiErrorType` mapping across all endpoints

### Acceptance criteria
- [ ] `ApiErrorHandler` created and verified
- [ ] All 12 repositories migrated
- [ ] `docs/api/` error tables updated

---

## REF-003: Backfill accessibility semantics on legacy screens

**Status:** In progress · **Priority:** High · **Effort:** 4 days · **Raised:** 2026-07-05

### Problem
Legacy screens lack accessibility semantic labels and tap target sizing.

### Recommended improvement
Add semantics labels to icon buttons and enforce minimum 48x48 tap targets.

### Acceptance criteria
- [ ] All interactive elements carry semantics labels
- [ ] Tap targets meet 48x48 standard

---

## REF-00X: <title>

**Status:** Open | In progress | Done (PR #) · **Priority:** · **Effort:** · **Raised:**

### Problem
### Current implementation
### Recommended improvement
### Expected benefit
### Acceptance criteria
- [ ] 
