# Contributors

Provenance record for this codebase: who wrote what, when, and under what engagement.
At handover this document answers *"who wrote this, and are we allowed to ship it?"*

**Current owner:** <name> — <since date>

> Core requires exactly one named owner at all times. When ownership changes, update this
> line and run the handover checklist in `SOP-CORE.md` §11.

---

## Internal contributors

| Name | Role | Active | Area of ownership |
|---|---|---|---|
| <name> | Flutter Developer / project owner | 2026-03 → present | Auth, checkout, routing |
| <name> | Flutter Developer | 2026-05 → present | Profile, notifications |
| <name> | QA | 2026-03 → present | Release verification, E2E suite |
| <name> | Mobile Lead | 2026-03 → present | Architecture sign-off, releases |

## External contributors

Contractors, client developers, and other agencies. Record the engagement reference —
this is the row that matters in an IP or handover dispute.

| Name / Org | Role | Active | Area | Engagement ref |
|---|---|---|---|---|
| <org> | Backend liaison | 2026-04 → 2026-06 | API contract, `docs/api/` | MSA-2026-014 |

## Departed

Keep the row. Close the period. Deleting a person erases the provenance of their code.

| Name | Role | Active | Area | Handover to |
|---|---|---|---|---|
| <name> | Flutter Developer | 2026-03 → 2026-07 | Original cart implementation | <name> |

## AI agents

Listed by tool and model family, not as people. Every line an agent wrote was merged
under a named human's responsibility — that human is the accountable contributor.

| Agent | Used for | Active | Accountable human |
|---|---|---|---|
| <agent / model family> | Feature scaffolding, E2E flow authoring | 2026-05 → present | <name> |

---

## Notes

- No personal contact details, home addresses, or anything beyond professional identity
  and role belongs in this file.
- Contributions from anyone not listed here should be treated as a provenance gap and
  raised with the Mobile Lead before release.
