# Tasks

> **Source of truth:** `<Jira / Linear / this file>`.
> If an external tracker is named above, this file mirrors only what is **in flight** —
> never a full copy. Set `parameters.docs.external_tracker` in `sop.manifest.yaml`.

Status vocabulary is fixed: `Backlog` → `In Progress` → `Blocked` → `In Review` → `Done`.

## In Progress

| ID | Task | Owner | Next action |
|---|---|---|---|
| PROJ-214 | Saved addresses at checkout | <dev> | Wire repository to the address endpoint |
| PROJ-219 | Arabic localization pass | <dev> | Extract remaining hardcoded strings on the profile screen |

## Blocked

| ID | Task | Owner | Blocked on | Who can unblock |
|---|---|---|---|---|
| PROJ-221 | Apple Pay in checkout | <dev> | Merchant ID not provisioned | <client contact> |

> A blocked task with no named unblocker is invisible work. Name someone.

## In Review

| ID | Task | Owner | PR |
|---|---|---|---|
| PROJ-208 | Order history pagination | <dev> | #142 |

## Backlog

| ID | Task | Priority | Notes |
|---|---|---|---|
| PROJ-230 | Offline cart persistence | Medium | Depends on PROJ-214 landing first |

---

## Archive

Completed work lives in `CHANGELOG.md`. Keep only the last two weeks here, then delete.

| ID | Task | Completed | PR |
|---|---|---|---|
| PROJ-201 | Push notification deep links | 2026-08-18 | #138 |
