# Structure — <App Name>

Architecture module: `<from sop.manifest.yaml>`

The module defines the layout. **This file records only deviations from it**, plus
project-specific placement rules the module does not cover.

If this file is empty apart from the header, that is the healthy state.

---

## Layout

As defined by `<module>`. See `sop/modules/architecture/<module>.md`.

## Approved deviations

Every deviation needs justification, an approver, and a mirror entry in
`sop.manifest.yaml` under `deviations:`. Undocumented deviation is a defect.

| # | Deviation | Reason | Approved by | Date | Expires |
|---|---|---|---|---|---|
| 1 | `lib/features/` exists alongside the layer folders | Hybrid migration per ADR-003 — new features are feature-first, existing ones stay | <mobile lead> | 2026-08-25 | n/a (permanent) |

> Deviation 1 is deliberate and permanent. Do not "fix" it by migrating existing
> features, and do not "fix" it by putting new features back into the layers.

## Project-specific placement rules

- <e.g. Payment gateway adapters live in `services/payments/`, not under a feature>
- <e.g. Generated localization output is committed>

## Things that look wrong but are not

Record traps here so nobody, human or agent, spends an afternoon rediscovering them.

- <e.g. `services/api/legacy_client.dart` is still used by two screens; removing it
  breaks the v1 endpoints the client has not yet retired. Tracked as REF-006.>
