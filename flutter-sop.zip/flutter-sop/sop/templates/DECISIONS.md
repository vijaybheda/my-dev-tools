# Architecture decision records

One entry per decision that closes off alternatives. Append-only.

**Never edit a past decision.** Supersede it with a new entry linking back. The reasoning
that was true then is the whole point of the record — a future developer reading a
rewritten ADR learns nothing about why the original call was made.

Trigger an entry for: module selection or change, a significant dependency, a schema or
API contract choice, or anything a future developer would otherwise quietly reverse.

---

## ADR-003 — Keep layer-first structure; build new features feature-first

**Date:** 2026-08-25 · **Status:** Accepted · **Decided by:** <mobile lead>

**Context**
The codebase follows Handbook v1.0 §6.1 (layer-first). SOP v2.0 offers feature-first
architecture modules. We now have 14 features; a change routinely touches five top-level
folders and merge conflicts concentrate in `presentation/blocs/`.

**Decision**
Select `arch-layered-classic`. Add `lib/features/` for new features only. Do not migrate
existing features except when substantially rewriting one.

**Alternatives considered**
- *Full migration to `arch-standard`* — rejected. Estimated three weeks with no user-visible
  benefit, and a stalled migration is worse than either endpoint.
- *Stay purely layer-first* — rejected. The per-change cost keeps growing.

**Consequences**
The codebase is deliberately hybrid. `STRUCTURE.md` must document this so nobody
"corrects" it halfway. `FEATURE_MAP.md` becomes load-bearing for locating feature code.

---

## ADR-002 — GoRouter for declarative routing

**Date:** 2026-07-02 · **Status:** Accepted · **Decided by:** <mobile lead>

**Context**
Imperative Navigator 1.0 routing caused deep-linking synchronization issues and back stack bugs.

**Decision**
Select `nav-gorouter`. All routes must be declared in a centralized route registry with named routes.

**Alternatives considered**
- *Navigator 1.0 / named routes* — rejected due to poor deep link and nested navigation support.
- *AutoRoute* — rejected due to heavy code generation requirements.

**Consequences**
All routes are registered centrally under `app/router/`. Navigation is performed by name rather than path string literals.

---

## ADR-001 — <title>

**Date:** YYYY-MM-DD · **Status:** Accepted | Superseded by ADR-XXX · **Decided by:** <name>

**Context**

**Decision**

**Alternatives considered**

**Consequences**
