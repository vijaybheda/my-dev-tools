# Feature map

Answers one question: **where does this feature live?**

Read this before planning any change. Update it in the same PR whenever a feature is
added, renamed, moved, or retired.

Architecture module in use: `<from sop.manifest.yaml>` — file paths below follow it.

---

## Active features

### Welcome & Onboarding

| Field | Value |
|---|---|
| **Owner** | <dev> |
| **Status** | Stable |
| **Entry route** | `WelcomePage`, `OnboardingPage(role: UserRole)` (Direct Widget Navigation via Native Splash bootstrap) |
| **Feature flag** | none |

**Code**
- `lib/features/welcome/presentation/pages/welcome_page.dart` (Figma dual role selection screen)
- `lib/features/welcome/presentation/pages/onboarding_page.dart` (Role-based slide router)
- `lib/main.dart` (Async session check & direct native splash release)
- `lib/core/components/onboarding/app_onboarding_view.dart` & `onboarding_slide_data.dart`
- `lib/core/storage/local_storage_service.dart` (GetStorage token & role persistence)

### Provider Profile Setup & Onboarding

| Field | Value |
|---|---|
| **Owner** | <dev> |
| **Status** | Active |
| **Entry route** | `ProviderSetupPage` |
| **Feature flag** | none |

**Code**
- `lib/features/provider/onboarding/presentation/pages/provider_setup_page.dart` (3-Step PageView Onboarding)
- `lib/features/provider/onboarding/presentation/cubit/provider_setup_cubit.dart` & `provider_setup_state.dart`
- `lib/features/provider/onboarding/presentation/widgets/setup_step_details.dart` (Business Details & Dynamic Chips)
- `lib/features/provider/onboarding/presentation/widgets/setup_step_documents.dart` (Configurable Documents Upload)
- `lib/features/provider/onboarding/presentation/widgets/setup_step_images.dart` (Logo & Multi-Image Portfolio)
- `lib/features/provider/onboarding/presentation/widgets/setup_upload_card.dart` (152px Dashed Squircle Upload Slot)
- `lib/features/provider/onboarding/presentation/widgets/places_autocomplete_field.dart` (Google Places Suggestions)
- `lib/features/provider/onboarding/domain/entities/place_prediction.dart`
- `lib/features/provider/onboarding/domain/entities/document_slot_config.dart`
- `lib/features/provider/onboarding/domain/entities/provider_profile_draft.dart`
- `lib/features/provider/onboarding/data/models/provider_profile_submission_dto.dart`
- `lib/features/provider/onboarding/domain/repositories/provider_onboarding_repository.dart`
- `lib/features/provider/onboarding/data/repositories/provider_onboarding_repository_impl.dart`
- `lib/features/provider/onboarding/presentation/pages/provider_approval_status_page.dart` (Status Gateway)

---

### Provider Dashboard & Management

| Field | Value |
|---|---|
| **Owner** | <dev> |
| **Status** | Active (WASH-030) |
| **Entry route** | `ProviderDashboardScreen` / `ProviderDashboardPage` (Direct Widget Navigation via `AppNavigator`) |
| **Feature flag** | none |

**Code**
- `lib/features/provider/dashboard/presentation/pages/provider_dashboard_screen.dart` (Master container with `IndexedStack` keep-alive lifecycle, `onTabChanged` callback, and top gradient)
- `lib/features/provider/dashboard/pages/provider_dashboard_page.dart` (Backward-compatible alias)
- `lib/features/provider/dashboard/presentation/tabs/provider_dashboard_tab_view.dart` (Tab 0: Metrics, rating, quick actions, sub-tab toggle)
- `lib/features/provider/dashboard/presentation/tabs/provider_bookings_tab_view.dart` (Tab 1: Status filter chips & 4-state booking list)
- `lib/features/provider/dashboard/presentation/tabs/provider_earnings_tab_view.dart` (Tab 2: 2x3 metrics grid & payout history)
- `lib/features/provider/dashboard/presentation/tabs/provider_more_tab_view.dart` (Tab 3: Avatar profile, operations menu, links, logout modal)
- `lib/features/provider/dashboard/presentation/widgets/provider_booking_card.dart` (Unified booking card handling 5 status variants)
- `lib/features/provider/dashboard/presentation/widgets/provider_metric_card.dart` (Gradient metric surface with Euro watermark)
- `lib/features/provider/dashboard/presentation/widgets/provider_payout_card.dart` (Payout item card)
- `lib/features/provider/dashboard/presentation/widgets/provider_segmented_toggle.dart` (Squircle sub-tab switcher)
- `lib/features/provider/dashboard/presentation/widgets/provider_notification_button.dart` (Squircle bell header button)
- `lib/features/provider/dashboard/domain/models/provider_dashboard_tab.dart` (Strongly-typed tab enum)
- `lib/features/provider/dashboard/domain/models/provider_booking_entity.dart` (Immutable domain booking model)
- `lib/features/provider/dashboard/domain/models/provider_payout_entity.dart` (Immutable domain payout model)
- `lib/features/provider/dashboard/dashboard.dart` (Barrel export)

**Notes** — Tabs preserve state using `IndexedStack` and `AutomaticKeepAliveClientMixin`. Tab transitions fire `onTabChanged(fromTab, toTab)` to enable API sync and analytics.

---

### Provider Service Management

| Field | Value |
|---|---|
| **Owner** | <dev> |
| **Status** | Active |
| **Entry route** | `MyServicesPage` / `CreateEditServicePage` / `ManageServicesPage` (Direct Widget Navigation) |
| **Feature flag** | none |

**Code**
- `lib/features/provider/services/presentation/pages/create_edit_service_page.dart` (Unified Create & Edit Service Form)
- `lib/features/provider/services/presentation/pages/my_services_page.dart` (Dashboard listing 4 UI visual states)
- `lib/features/provider/services/presentation/widgets/my_service_list_item_card.dart` (Dedicated squircle list item card)
- `lib/features/provider/services/presentation/widgets/service_steppers.dart` (`ServicePriceStepper` & `ServiceDurationStepper`)
- `lib/features/provider/services/presentation/widgets/my_services_shimmer_skeleton.dart` (Pulse loading skeleton)
- `lib/features/provider/services/presentation/widgets/delete_service_bottom_sheet.dart` (Delete confirmation modal)
- `lib/features/provider/services/presentation/widgets/delete_service_failed_bottom_sheet.dart` (Delete blocked modal when active bookings exist)
- `lib/features/provider/services/presentation/cubit/provider_services_cubit.dart` & `provider_services_state.dart`
- `lib/features/provider/services/domain/entities/provider_service_entity.dart`
- `lib/features/provider/services/data/models/provider_service_dto.dart`
- `lib/features/provider/services/domain/repositories/provider_services_repository.dart`
- `lib/features/provider/services/data/repositories/provider_services_repository_impl.dart`
- `lib/features/provider/services/pages/manage_services_page.dart` (Host entry point)

---

### Authentication

| Field | Value |
|---|---|
| **Owner** | <dev> |
| **Status** | Stable |
| **Entry route** | `Routes.login` → `/login` |
| **Feature flag** | none |

**Code**
- `lib/core/network/api_client.dart` (Dio HTTP verbs, cancellation, uploads/downloads)
- `lib/core/network/api_result.dart` (Sealed ApiResult with .fold(), .onSuccess(), .onError())
- `lib/core/network/api_endpoints.dart` (Centralized endpoint constants)
- `lib/core/network/base_api_response.dart` & `pagination_data.dart` (Immutable DTOs)
- `lib/core/network/error_mapper.dart` & `http_status_handler.dart` (HTML sanitization & friendly error mapping)
- `lib/core/network/interceptors/` (Auth, Logging, Retry interceptors)
- `presentation/pages/auth/` — login, OTP, forgot password screens
- `presentation/blocs/auth/` — auth bloc, session controller
- `domain/usecases/auth/` — sign_in, sign_out, refresh_session
- `data/repositories/auth_repository_impl.dart`

**API** — `POST /auth/login` · `POST /auth/refresh-token` · `POST /auth/logout`
→ `docs/api/NETWORK_API_STANDARD.md`

**Notes** — Session refresh is interceptor-driven. A 401 on refresh itself forces logout;
don't add a second refresh path.

---

### Checkout

| Field | Value |
|---|---|
| **Owner** | <dev> |
| **Status** | In progress (PROJ-214) |
| **Entry route** | `Routes.checkout` → `/cart/checkout` |
| **Feature flag** | `saved_addresses` (staging on, prod off) |

**Code**
- `presentation/pages/checkout/`
- `presentation/blocs/checkout/`
- `domain/usecases/checkout/` — place_order, validate_cart
- `data/repositories/checkout_repository_impl.dart`
- `data/mappers/order_mapper.dart`

**API** — `GET /cart` · `POST /orders` · `GET /addresses` · `POST /addresses`
→ `docs/api/checkout.md`

---

### System Status & Utility Screens

| Field | Value |
|---|---|
| **Owner** | <dev> |
| **Status** | Stable |
| **Entry route** | `RouteNames.forceUpdate` (`/force-update`), `RouteNames.noInternet` (`/no-internet`), `RouteNames.underMaintenance` (`/under-maintenance`) |
| **Feature flag** | none |

**Code**
- `lib/features/system_status/presentation/pages/force_update_page.dart` (`ForceUpdateScreen`)
- `lib/features/system_status/presentation/pages/no_internet_page.dart` (`NoInternetScreen`, `NoInternetView`)
- `lib/features/system_status/presentation/pages/under_maintenance_page.dart` (`UnderMaintenanceScreen`, `UnderMaintenanceView`)
- `lib/features/system_status/presentation/widgets/system_status_badge.dart`
- `lib/features/system_status/presentation/widgets/system_status_content.dart`
- `lib/features/system_status/domain/models/system_status_info.dart`
- `lib/features/system_status/system_status.dart` (Barrel export)

**Notes** — Mission-critical blocking & offline fallback screens using non-dismissible `PopScope(canPop: false)`, defensive store opening, interactive connection retry, and glowing squircle badge styling.

---

### Notifications

| Field | Value |
|---|---|
| **Owner** | <dev> |
| **Status** | Stable |
| **Entry route** | `RouteNames.notifications` → `/notifications` |
| **Feature flag** | none |

**Code**
- `lib/features/notifications/data/models/notification_item_model.dart`
- `lib/features/notifications/data/models/notification_result_model.dart`
- `lib/features/notifications/data/repository/notifications_repository.dart`
- `lib/features/notifications/presentation/cubit/notifications_cubit.dart`
- `lib/features/notifications/presentation/cubit/notifications_state.dart`
- `lib/features/notifications/presentation/pages/notifications_page.dart`
- `lib/features/notifications/presentation/widgets/coffee_mug_illustration.dart`
- `lib/features/notifications/presentation/widgets/notification_empty_view.dart`
- `lib/features/notifications/presentation/widgets/notification_item_card.dart`
- `lib/features/notifications/presentation/widgets/notifications_content_view.dart`
- `lib/features/notifications/presentation/widgets/notifications_header.dart`
- `lib/features/notifications/presentation/widgets/notifications_shimmer_view.dart`
- `lib/features/notifications/notifications.dart` (Barrel export)

**API** — `GET /notifications` · `POST /notifications/read` · `POST /notifications/read-all` · `POST /notifications/delete` · `POST /notifications/clear-all`

---

### Contact Us

| Field | Value |
|---|---|
| **Owner** | <dev> |
| **Status** | Stable |
| **Entry route** | `ContactUsPage` (Direct Widget Navigation) |
| **Feature flag** | none |

**Code**
- `lib/features/contact_us/presentation/pages/contact_us_page.dart` (`ContactUsPage`)
- `lib/features/contact_us/presentation/cubit/contact_us_cubit.dart` & `contact_us_state.dart`
- `lib/features/contact_us/presentation/widgets/contact_us_content_view.dart`
- `lib/features/contact_us/presentation/widgets/contact_us_shimmer_view.dart`
- `lib/features/contact_us/presentation/widgets/contact_item_card.dart`
- `lib/features/contact_us/contact_us.dart` (Barrel export)

**API** — `GET /api/v1/default-configuration` (Cached via `LocalStorageService`)

---

## Cross-cutting

| Concern | Lives in | Owner |
|---|---|---|
| Routing | `lib/core/router/app_navigator.dart` (Direct widget navigation via `AppNavigator` / `BuildContext` extensions. Named routes strictly prohibited) | <dev> |
| UI Component Library | `lib/core/components/` (29 modular components including `AppImageView`, `AppImageMetadata`, `AppUploadAvatar`) | <dev> |
| Component Showcase Gallery | `lib/core/components/showcase/component_showcase_view.dart` | <dev> |
| Environment & Flavors | `core/config/app_config.dart`, `config/*.json` | <dev> |
| Firebase Integration | `lib/firebase_options.dart`, `android/app/google-services.json`, `ios/Runner/GoogleService-Info.plist` (Project: `carcarewashy-f3863`) | <dev> |
| Native App Icon | `assets/image/W-AppIcon.png`, `pubspec.yaml` (`flutter_launcher_icons`) | <dev> |
| Native Splash Screen | `assets/image/washy_splash.png`, `pubspec.yaml` (`flutter_native_splash`) | <dev> |
| Theme & Typography | `core/theme/` (`app_theme.dart`, `app_typography.dart`, `app_colors.dart`) | <dev> |
| Logging | `services/logging/` | <dev> |
| API client | `services/api/` | <dev> |
| DI registration | `core/di/` | <dev> |
| Localization | `l10n/*.arb` | <dev> |
| Permission Subsystem | `lib/core/permissions/` (`app_permission_service.dart`, `app_permission_status.dart`, `app_permission_type.dart`, `widgets/app_permission_dialog.dart`) | <dev> |
| Push Notification Manager | `lib/core/firebase/` (`notification_manager.dart`, `push_notification_entity.dart`, background message handler, differential FCM sync) | <dev> |

---

## Retired

| Feature | Removed in | Reason | Notes |
|---|---|---|---|
| In-app chat | 1.1.0 | Replaced by third-party support widget | Do not resurrect `presentation/pages/chat/` — the backend endpoints are gone |
| Named Navigation & Route Names | Current | Replaced by Direct Widget Navigation (`AppNavigator`) for screen & file transparency | Do not resurrect `RouteNames` or `context.pushNamed` / `context.go` |
| Flutter SplashPage | Current | Replaced by native splash screen (`flutter_native_splash`) with direct target screen bootstrap in `main.dart` | Do not recreate `SplashPage` widget — initial session check runs natively during splash preservation |

> Retired entries stay. They are what stops someone rebuilding something that was
> deliberately removed.
