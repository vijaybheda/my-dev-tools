# AGENTS.md — Washy App SOP

Instructions for AI coding agents working in this repository based on the mandatory [`flutter-sop/`](file:///Users/vijaybheda/Documents/development/f/washy/flutter-sop) architecture.

**Mandatory Read Order:** Read `sop.manifest.yaml`, `AGENTS.md`, and `SOP-CORE.md` before performing any task.

---

## ⚡ Universal Directive: Plan First For Every User Query
> **Core Mandate:** `"We should first plan for user query"`
> 
> Whenever a user sends a prompt from **ANY AI Code Editor** (Antigravity, Cursor, Windsurf, Claude Code, Copilot, VS Code AI, etc.):
> 1. **Plan First:** The AI Agent MUST ALWAYS first analyze and formulate a plan for the user's query before modifying or creating code.
> 2. **Review Boundaries:** Inspect existing architecture, components (`COMPONENTS.md`), tokens (`AppColors`, `AppTypography`), and affected files.
> 3. **Present Approach:** Outline the planned changes clearly so the user has complete visibility into what will be done.

---

## 0. Autonomous Intent Detection & Silent Adaptability

The user will **NEVER** be required to specify intent tags or project archetypes—they will simply ask what they need directly in plain, natural language.

The AI Editor **MUST AUTOMATICALLY DEDUCE** the intent from the user's prompt, silently adapt to the project environment, and **ALWAYS output the following clean badge as the very first line of every response**:

```markdown
> **Intent Detected:** `[<Intent>]` — <Brief boundary & execution summary>
```

**The Core Intents:** `[Add New]`, `[UI Polish]`, `[Integration]`, `[Bug Fix]`, `[Refactor]`, `[Remove]`, `[Investigate]`, `[Performance]`, `[Critique]` (+ `[Release]`).
Project context (AI-Native vs. human-built) is adapted to silently in the background.

---

## 1. Active Modules

| Category | Module |
| --- | --- |
| Architecture | `arch-standard` |
| State | `state-bloc` |
| Navigation | `nav-direct-widget` |
| Release | `release-manual` |
| Agents | `agents-core` |
| Standards | `coding-dart-flutter`, `env-flavors-secrets`, `logging-monitoring`, `api-integration` |
| Docs | `living-docs` |

---

## 2. Toolchain & Code Generation

- **Toolchain:** Always `fvm flutter ...` and `fvm dart ...` (never bare commands).
- **Code Generation:** Execute whenever models, assets, or serializable classes are touched:
  ```bash
  fvm dart run build_runner build --delete-conflicting-outputs
  ```
- **Generated Files Protection:** Never manually edit `*.g.dart`, `*.freezed.dart`, or asset files.

---

## 2.1 Strict Rule: Never Write Test Cases

Agents **MUST NEVER** write, scaffold, generate, or add test cases (unit tests, widget tests, integration tests, or regression tests) under any circumstances. Test authoring is strictly prohibited for AI agents. Verification relies exclusively on static code analysis (`fvm flutter analyze`), formatting (`fvm dart format .`), and manual flow checks.

---

## 2.2 Universal Anti-Static & Dynamic Development Mandate

This is a **universal, feature-agnostic engineering law** across the entire project. AI agents and developers **MUST NEVER** code static or hardcoded shortcuts:

1. **Zero Hardcoded or Static Data in UI:**
   - Hardcoding static strings, static lists, dummy arrays, or mock click actions inside UI widgets or controllers is **STRICTLY PROHIBITED**.
   - Every feature MUST receive its state through strongly-typed domain models and reactive streams (`Bloc`, `Cubit`, `ValueNotifier`).
2. **Anti-Primitive Obsession (Universal):**
   - Never represent business domain concepts with raw primitives (`String`, `double`, `int`, `Map<String, dynamic>`).
   - Complex domain attributes (e.g. addresses, coordinates, configurations, pricing breakdowns, time ranges) MUST be encapsulated in rich, strongly-typed immutable classes.
3. **Decoupled Action Contracts:**
   - UI widgets MUST NOT perform business mutations or direct screen-to-screen navigation in `onPressed`/`onTap` handlers.
   - UI widgets MUST only emit semantic action intents (e.g. BLoC Events / Cubit Intents). The business layer decides routing, validation, and side-effects.
4. **Universal Pre-API Implementation Pattern (Zero Mocks, Zero Tests):**
   - When an API endpoint is not yet available, agents **MUST NOT** create separate mock classes, mock files, or test cases.
   - Instead, simulate the endpoint directly inside the actual feature repository / remote data source using:
     ```dart
     // =========================================================================
     // TODO(api-integration): Replace simulated 2-second delay and static JSON
     // with live API endpoint: [METHOD] [ENDPOINT_PATH]
     // =========================================================================
     await Future.delayed(const Duration(seconds: 2));
     const rawJsonResponse = '''
     {
       "status": "success",
       "data": { ... }
     }
     ''';
     final jsonMap = jsonDecode(rawJsonResponse) as Map<String, dynamic>;
     final dto = ResponseDto.fromJson(jsonMap['data'] as Map<String, dynamic>);
     return dto.toDomain();
     ```
   - **Why:** This forces real JSON decoding, validates `@JsonSerializable` DTO mapping, and tests the UI's loading spinner and disabled buttons under realistic 2-second latency.
5. **Mandatory Standardized `TODO(api-integration)` Protocol:**
   - Whenever ANY static string, temporary JSON payload, simulated delay, or fallback stub is written anywhere in the codebase, the agent **MUST** add an explicit standardized comment:
     `// TODO(api-integration): Replace simulated 2s delay and static JSON with live API endpoint: [METHOD] [ENDPOINT]`
   - Leaving untagged static or dummy data in code is strictly prohibited.
6. **Universal 4-State UI Law:**
   - Every data-driven screen or component MUST explicitly handle and visually verify all 4 states:
     - **Loading State:** Skeleton shimmer via `AppStateViews.loading()` or button progress indicator.
     - **Empty State:** Illustrated empty view with actionable recovery via `AppStateViews.empty()`.
     - **Error State:** Human-readable error message with working `[Retry]` callback via `AppStateViews.error(onRetry: ...)`.
     - **Populated State:** Standard happy-path view.

---

## 2.3 Universal Mandate: ListView Development, 4-State Handling, Pull-to-Refresh & Scroll Guidelines
This is a **strict architectural law** across all screens, tabs, dialogs, and components containing list views:
1. **Parent Component 4-State Handling (Loading Shimmer, Error, Empty, Populated):**
   - The parent screen or container component for any `ListView` MUST explicitly handle all 4 visual states:
     - **Loading State:** Display a skeleton loading shimmer (e.g. `AppStateViews.loading()` or a dedicated shimmer placeholder view like `_ShimmerSkeleton`).
     - **Empty State (No Data):** Display an illustrated empty view with clear messaging and actionable recovery (e.g. `AppStateViews.empty()`). Must be wrapped in a scrollable `RefreshIndicator` container so pull-to-refresh works even when zero items exist.
     - **Error State:** Display a human-readable error message with a working `[Retry]` callback (e.g. `AppStateViews.error(onRetry: ...)`). Must be wrapped in a scrollable `RefreshIndicator` container.
     - **Populated State:** Display the populated list view.
2. **Mandatory Cross-Platform Pull-to-Refresh & TODO Protocol:**
   - Every list screen / list component MUST allow pull-to-refresh using the cross-platform template:
     ```dart
     RefreshIndicator(
       backgroundColor: AppColors.bgSecondaryDark,
       color: AppColors.brandPrimaryBlueDark,
       edgeOffset: 50.0,
       onRefresh: _onRefresh,
       child: SingleChildScrollView( // or ListView
         controller: _scrollController,
         physics: const BouncingScrollPhysics(
           parent: AlwaysScrollableScrollPhysics(),
         ),
         clipBehavior: Clip.none,
         padding: AppSpacing.screenPadding,
         ...
       ),
     )
     ```
   - If pull-to-refresh capability is not yet wired to a live backend endpoint, an explicit standardized comment **MUST** be added:
     `// TODO(api-integration): Implement pull-to-refresh handler for [Screen/Feature Name]`
3. **Proper Scroll Physics & Boundary Layout Behavior:**
   - **Bouncing Physics with Always-Scrollable Parent:** List views and scroll views wrapped inside a `RefreshIndicator` MUST use `physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics())` so pull-to-refresh triggers reliably on both iOS and Android even when list items are few or empty.
   - **Unclipped Scrolling (`clipBehavior: Clip.none`):** Scroll views MUST specify `clipBehavior: Clip.none` to prevent boundary clipping of cards, shadows, and over-scroll effects.
   - **Header Offset (`edgeOffset: 50.0`):** `RefreshIndicator` MUST specify `edgeOffset: 50.0` (or appropriate header offset) so the spinner does not obscure top headers or app bars.
   - **Bottom Clearance Padding:** Provide adequate bottom spacing (`AppSpacing.bottomCtaPadding` or `90.0` FAB clearance) so the final list item is never cut off or obscured by floating action buttons or bottom navigation.
   - **Nested Scroll Handling:** For nested lists inside scrollable parents, use `CustomScrollView` with slivers (`SliverList`, `SliverPadding`), or set `shrinkWrap: true` + `physics: const NeverScrollableScrollPhysics()`.
4. **Dedicated Standalone Widget Class Required for ListView Items:**
   - Never use components or inline UI layouts inside `ListView`, `ListView.builder`, `ListView.separated`, or `SliverList` without a dedicated separate `Widget` class.
   - Every list item MUST be encapsulated in its own standalone `StatelessWidget` or `StatefulWidget` class (e.g. `ProviderBookingCard`, `_ServiceItemCard`, `_FilterChipItem`).
   - Placing raw multi-line components directly inside `itemBuilder` (e.g. `AppCard(child: Column(...))`) or delegating item construction to `Widget _buildX()` private helper methods inside `itemBuilder` is **STRICTLY FORBIDDEN**. Helper methods bypass Flutter element reconciliation, prevent `const` subtree caching, and cause unnecessary rebuild cascades during scrolling.

---

## 3. Data Models, Immutability & Serialization Standards

1. **JSON Serialization:** Annotate with `@JsonSerializable(explicitToJson: true)`. Include `part '<file>.g.dart';` and implement `fromJson`/`toJson`.
2. **Value Equality:** Extend `Equatable` and override `props`.
3. **Immutability:** All fields `final`; implement `copyWith`.
4. **Boundary Isolation:** Raw JSON maps MUST NOT cross repository boundaries into UI.

## 4. Design System: Mandatory Tokenization Triad (`AppColors`, `AppSpacing`, `AppStrings`, `AppTypography`)

1. **`AppColors` (Strict Zero Hex Literal Rule):**
   - Writing `Color(0x...)` or raw hex literals inside UI screens, widgets, cards, dialogs, or controllers is **STRICTLY FORBIDDEN**.
   - All colors MUST come from [`lib/core/theme/app_colors.dart`](file:///Users/vijaybheda/Documents/development/f/washy/lib/core/theme/app_colors.dart).
   - If a Figma CSS snippet introduces a new hex value (e.g. `background: #0D1B2A;`), NEVER paste `Color(0xFF0D1B2A)` into widget code. Map it to an existing `AppColors` token or add a semantic token to `app_colors.dart` first.
2. **`AppSpacing` (Strict Zero Raw EdgeInsets / Spacer Rule):**
   - Writing raw numeric padding, margins, or SizedBox offsets (e.g. `EdgeInsets.fromLTRB(16, 8, 16, 16)`, `EdgeInsets.symmetric(horizontal: 16, vertical: 12)`, `EdgeInsets.all(8)`, `SizedBox(height: 16)`) is **STRICTLY FORBIDDEN**.
   - All padding, margins, gaps, and dimensions MUST use `AppSpacing.*` scalar tokens (`AppSpacing.xxs`, `AppSpacing.xs`, `AppSpacing.sm`, `AppSpacing.md`, `AppSpacing.lg`, `AppSpacing.xlg`, `AppSpacing.xxlg`, etc.) or preset geometries (`AppSpacing.screenHorizontal`, `AppSpacing.screenPadding`, `AppSpacing.bottomCtaPadding`, `AppSpacing.cardPadding`, `AppSpacing.chipPadding`, `AppSpacing.modalPadding`, `AppSpacing.gapVerticalMd`, etc.) from [`lib/core/theme/app_spacing.dart`](file:///Users/vijaybheda/Documents/development/f/washy/lib/core/theme/app_spacing.dart).
3. **`AppStrings` (Strict Zero Inline String Rule):**
   - Hardcoding user-facing strings, button labels, screen titles, subtitles, input labels, hint placeholders, chip labels, dialog messages, or error toasts directly in widgets is **STRICTLY FORBIDDEN**.
   - All user-facing strings MUST be defined in [`lib/core/constants/app_strings.dart`](file:///Users/vijaybheda/Documents/development/f/washy/lib/core/constants/app_strings.dart) or `l10n/*.arb`.
4. **`AppTypography` & Context TextTheme:**
   - Inline `TextStyle(...)` instantiations are **STRICTLY FORBIDDEN**. All typography MUST use Google Fonts `DM Sans` via `context.textTheme.*` or `AppTypography.*`.
5. **No `setState`:**
   - Manage state reactively using `ValueNotifier` / `Bloc` / `Cubit`. `setState` is strictly prohibited.
6. **No Default Framework Icons:**
   - Default Flutter or Material/Cupertino icons (`Icons.*`, `CupertinoIcons.*`) are strictly prohibited across all components and screens. All icons MUST use custom SVGs / vector assets managed via generated asset getters (`Assets.icon.*`, `Assets.svg.*`) or `.toSvg()` extensions.
7. **Mandatory Pixel-Perfect UI Markdown Review & Approval:**
   - Whenever a user requests UI implementations or any UI changes, the AI agent MUST first share the complete UI structure, layout breakdown, component hierarchy, design tokens (`AppColors`, `AppSpacing`, `AppTypography`), and 4 visual states in Markdown format. Implementation code MUST NOT be written until the user reviews and explicitly approves the Markdown presentation. If the user requests changes, the AI agent must update the Markdown layout iteratively until full approval is granted, ensuring pixel-perfect UI execution.
8. **Automated Grep Verification Gate (Pre-Completion Mandatory Audit):**
   - Before marking any UI or feature task complete, the AI agent MUST execute:
     - `git grep "Color(0x" lib/` (Must return 0 results outside `app_colors.dart`)
     - `git grep "fromLTRB(" lib/` (Must return 0 results outside `app_spacing.dart`)
     - Any violation MUST be resolved before declaring completion.

---

## 5. Mandatory Component Reuse & Safe Extension Policy
1. **Component First:** Always check [`COMPONENTS.md`](file:///Users/vijaybheda/Documents/development/f/washy/COMPONENTS.md) and [`lib/core/components/`](file:///Users/vijaybheda/Documents/development/f/washy/lib/core/components) before implementing UI. Custom duplication of buttons, text fields, cards, chips, dialogs, progress bars, or state views is prohibited.
2. **Safe Alterations:** If a component needs new styling or options, safely extend it via backwards-compatible parameters or new named constructors (e.g. `AppButton.myVariant`). Never break existing defaults.
3. **Component Documentation:** Every component MUST maintain a dedicated `README.md` with parameter usage tables, named constructor breakdowns, and a "How We Can Use" guide. Update `COMPONENTS.md` on any component edit.

---

## 6. Workflow (5 Phases)

Plan → Human Review → Implement → Verify → Living Docs.
1. **Plan:** Check `COMPONENTS.md` & `FEATURE_MAP.md`. Markdown plan covering overview, architecture, file changes, dependencies (no test cases).
2. **Stop:** Wait for human approval (tasks >3 files or adding features).
3. **Code:** Scoped strictly to plan.
4. **Verify:** `fvm flutter analyze` (0 warnings), `fvm dart format .`, automated grep audits (`Color(0x`, `fromLTRB(`), existing tests if run. Agents MUST NEVER write test cases.
5. **Living Docs:** Update `CHANGELOG.md`, `TASKS.md`, `FEATURE_MAP.md` in same PR.

---

## 7. Forbidden Boundaries

- **Never write test cases:** Writing, scaffolding, generating, or adding test cases (unit, widget, integration, or regression tests) is strictly prohibited.
- **Never write raw `Color(0x...)` hex literals:** Hex literals outside `lib/core/theme/app_colors.dart` are strictly prohibited.
- **Never write raw numeric `EdgeInsets` or arbitrary `SizedBox` dimensions:** Ad-hoc numeric padding/spacers outside `lib/core/theme/app_spacing.dart` are strictly prohibited.
- **Never write inline user-facing strings:** Hardcoded UI strings outside `lib/core/constants/app_strings.dart` / `l10n/*.arb` are strictly prohibited.
- **Never code static / hardcoded shortcuts:** Hardcoding static strings, dummy lists, or fake click handlers inside UI widgets or controllers is strictly forbidden.
- **Never write untagged temporary data:** Writing simulated delays, static JSON payloads, or fallback stubs without a standardized `// TODO(api-integration): ...` comment is strictly forbidden.
- **Never write separate mock classes:** Creating standalone mock classes, mock repositories, or mock files is strictly forbidden. Always use in-place simulated 2-second JSON string decoding through real DTOs in the actual repository.
- **Never use default framework icons:** Using default `Icons.*` or `CupertinoIcons.*` across any component or screen is strictly prohibited. All icons MUST use custom SVG vector assets via `Assets.icon.*` / generated asset getters.
- **Never use named or low-level navigation:** Using named routes (`context.pushNamed`, `context.goNamed`, `RouteNames`), raw string paths (`context.go('/...')`), query strings, or low-level direct `Navigator.pop()` / `Navigator.of(context)` calls outside `AppNavigator` is strictly prohibited. Direct widget navigation and pops MUST use `AppNavigator` or context extensions (`AppNavigator.pop(...)`, `context.popScreen()`, `context.pushScreen()`, `context.popDialog()`).
- **Never use raw strings for user roles:** `UserRole` enum (`lib/core/enums/user_role.dart`) must be used across the app instead of raw string literals (`'customer'`, `'provider'`).
- **Never use components or inline trees without separate widget for ListView:** Using components directly or inlining multi-line widget trees / `Widget _buildX()` helper methods inside `ListView`, `ListView.builder`, or `ListView.separated` without a dedicated standalone `Widget` class is STRICTLY FORBIDDEN. Each item must be its own standalone widget class.
- Merge, release, tag, or touch keystores/store credentials.
- Modify `ios/Runner.xcodeproj`, CI workflows, or `pubspec.lock` manually.
- Add dependencies without explicit justification and written approval.
- Destructive commands (`rm -rf`, force push, `git reset --hard`).
- Swallow exceptions with bare `try {} catch (_) {}` or use `!` bang operators.
- Ship `print()` statements or log tokens, passwords, PII, or headers.
