# Flutter Mobile Development Employee Handbook

**Version:** 2.0
**Effective:** 2026-08-25 · Supersedes v1.0 (2026-08-13)
**Department:** Mobile Engineering (Flutter)
**Classification:** Internal Use

---

## What changed in v2.0, and why

v1.0 was a single document that mandated one architecture, one structure, and one process
for every project. That worked when every project looked the same. It stopped working the
moment clients arrived with their own stacks, inherited codebases, and contractual
constraints — the handbook then had to either be ignored or hedged into vagueness.

v2.0 splits the rules in two:

- **This handbook** — who we are, how we work, and what is true everywhere. Stable. Rarely
  edited.
- **The modular SOP** (`sop/`) — the enforceable technical rules, split into modules that
  each project selects from. Swappable per client.

**Nothing from v1.0 was discarded.** Every section was either kept here or moved into a
module. The map is in Section 15.

### One correction worth naming

Section 6.1 of v1.0 mandated a layer-first structure. The SOP's earlier draft mandated feature-first.
Rather than declare every existing project non-compliant overnight, the v1.0 layout is
preserved verbatim as the `arch-layered-classic` module, and the SOP core no longer
mandates either. **Every project that predates v2.0 selects `arch-layered-classic` and is
compliant as written, with no migration required.**

---

## Table of contents

1. Welcome & purpose
2. Development philosophy
3. How the handbook and the SOP fit together
4. AI-assisted development workflow
5. Living documentation
6. Project standards
7. Code review
8. Refactoring & technical debt
9. Release process
10. Onboarding
11. Adopting v2.0 on an existing project
12. Quick reference
13. Glossary
14. Approval & revision history
15. v1.0 → v2.0 content map

---

## 1. Welcome & purpose

Welcome to the Flutter Mobile Development team. This handbook is your guide to how we
work: our practices, our standards, and the reasoning behind them.

It exists to ensure consistent quality across projects and people, provide clear
guidelines for development and release, establish workflows that work with AI-assisted
tooling, minimize technical debt, enable smooth onboarding, and make the development
lifecycle predictable from requirement to release.

**Scope:** all Flutter applications built in this organization; all contributors —
developers, QA, tech leads, contractors, and AI coding agents.

---

## 2. Development philosophy

### 2.1 Core cycle

> **Understand → Plan → Review → Implement → Verify → Review → Document → Release**

Every feature, fix, and improvement follows this cycle. No exceptions.

### 2.2 Values

| Value | Meaning |
|---|---|
| **Consistency** | Code should look and feel the same across projects |
| **Clarity** | Code is read far more often than written. Optimize for the reader |
| **Quality** | Ship code you are proud of. Never trade quality for speed |
| **Accountability** | Every line of code is your responsibility. Own it |
| **Collaboration** | Code review is a learning exchange, not criticism |
| **Documentation** | If it isn't documented, it doesn't exist |

### 2.3 AI-first mindset

We treat AI-assisted development as a force multiplier. And:

- AI is a tool, not a substitute for engineering judgment
- AI-generated code gets the same review rigor as human-written code — no more, no less
- No AI-generated code is production-ready without human review and verification
- We use AI for planning, boilerplate, and first implementations. **Humans own the
  architecture and the final call.**

---

## 3. How the handbook and the SOP fit together

**This handbook is culture and process. The SOP is enforceable rules.**

```
Handbook (this file)          → values, workflow, who does what. Rarely changes.
sop/SOP-CORE.md               → rules true on every project, regardless of stack
sop/modules/**                → rules that vary. Each project selects a set.
<project>/sop.manifest.yaml   → which modules this project uses. The binding contract.
```

A rule is enforceable only if it appears in core or in a module this project selected.
Anything else is guidance.

### 3.1 Precedence

```
1. Law, client contract, app store policy
2. SOP-CORE.md
3. The selected module
4. Approved deviations recorded in sop.manifest.yaml
5. This handbook
```

The handbook sits last deliberately: if it ever contradicts a module, the module is the
current, specific, reviewed rule and the handbook is the general statement that has
drifted. Raise the contradiction so the handbook gets fixed.

### 3.2 Module categories

| Category | Choose | Options |
|---|---|---|
| Architecture | one | `arch-lite` · `arch-standard` · `arch-clean` · `arch-layered-classic` |
| State | one | `state-bloc` |
| Navigation | one | `nav-gorouter` · `nav-autoroute` |
| Release | one | `release-manual` · `release-fastlane` |
| Agents | many | `agents-core` |
| Standards | many | `coding-dart-flutter` · `env-flavors-secrets` · `logging-monitoring` · `api-integration` |
| Docs | many | `living-docs` |
| Process | many | `refactoring-tech-debt` |

Selection happens at kickoff, is approved by the Mobile Lead, and is **locked for the
current phase**. Changing it needs approval, a written migration plan, and an ADR entry.

**Over-engineering is a defect.** A six-week MVP carrying a two-year product's module set
has failed selection just as badly as the reverse.

---

## 4. AI-assisted development workflow

Full rules: `sop/modules/agents/agents-core.md`. The shape:

> **Requirement → AI analysis → Plan → Human review → Revision → Approval → Implementation → Review → Verification**

### 4.1 Plan first

Mandatory for anything touching more than three files or adding a feature.

The plan is a Markdown document covering: feature overview, architecture decisions,
file-by-file changes, new dependencies, and rollback plan.

It is a **living document** — review comments go into it, the agent revises, and
implementation begins only on approval by the tech lead or a senior developer.

**A wrong plan caught at review costs a minute. Caught in code review it costs an
afternoon. Caught in production it costs a release.**

### 4.2 Model selection

Strong reasoning models for architecture, planning, and final review. Faster, cheaper
models for implementing an approved plan.

### 4.3 Implementation

Strictly aligned to the approved plan. Scope discovered mid-implementation goes **back to
the plan**, not straight into the diff.

### 4.4 Guideline files every project carries

| File | Purpose |
|---|---|
| `AGENTS.md` | Instructions for AI agents. **Must state the active modules** |
| `STRUCTURE.md` | Deviations from the architecture module, and traps |
| `README.md` | Setup: fresh machine to running app in under 30 minutes |
| `sop.manifest.yaml` | Module selection, toolchain, parameters, deviations |

v1.0's `RULES.md` and `SKILLS.md` are superseded: their content now lives in the SOP
modules, which are versioned and shared rather than copy-pasted per project.

### 4.5 Non-negotiables

Agents never merge, release, tag, or touch credentials, keystores, `.env`, or CI secrets.
Every line an agent writes is the assigned developer's responsibility at merge. **"The
agent wrote it" is never an explanation for a defect.**

---

## 5. Living documentation

Full rules: `sop/modules/docs/living-docs.md`. Templates: `sop/templates/`.

> A document nobody is obliged to update lies within a month — and a document that lies is
> worse than none, because people trust it and act on it.

So every living document has **one trigger, one owner, one format.**

| Document | Trigger |
|---|---|
| `CHANGELOG.md` | Every merge to the integration branch |
| `TASKS.md` | Task started, blocked, or finished |
| `FEATURE_MAP.md` | Feature added, renamed, moved, retired |
| `CONTRIBUTORS.md` | A new person or agent commits |
| `DECISIONS.md` | Any decision that closes off alternatives |
| `KNOWN_ISSUES.md` | Bug found but not fixed this cycle |
| `REFACTORING.md` | Debt identified or resolved |
| `STRUCTURE.md` | Structure deviates from the module |
| `AGENTS.md` | Manifest or agent rules change |
| `docs/api/*.md` | API contract changes |
| `README.md` | Setup steps change |

**Updated in the same PR as the change that triggered them.** A follow-up "docs PR" is a
PR that never gets written.

### 5.1 The two that carry the most weight

**`FEATURE_MAP.md`** answers *"where does this feature live?"* — its files, routes, API
endpoints, owner, and feature flag, in one place. It is the first thing a new
developer or an agent should read. On `arch-layered-classic` it is essential, because a
feature's code is otherwise scattered across five top-level folders with nothing linking it.

**`CONTRIBUTORS.md`** is the provenance record: internal contributors, external
contractors with engagement references, departed contributors (period closed, never
deleted), and AI agents listed by tool with their accountable human. At handover this is
the document that answers *"who wrote this and are we allowed to ship it?"*

### 5.2 The rule agents break most

**Do not fabricate.** Every changelog line, file path, and contributor entry must
correspond to something real in the diff. Plausible-sounding documentation is the most
damaging output an agent can produce, because it reads correct and nobody re-verifies it.

And do not rewrite history: no editing released changelog sections, no editing past ADRs,
no removing departed contributors.

---

## 6. Project standards

All enforceable standards live in modules. Summary of where:

| Topic | Module |
|---|---|
| Dart/Flutter style, naming, widgets, null safety, async, performance, memory, comments | `standards/coding-dart-flutter` |
| Environments, flavors, secrets, keystores | `standards/env-flavors-secrets` |
| Logging categories, service, screen lifecycle, redaction | `standards/logging-monitoring` |
| API client, models, tokens, interceptors, errors, retries, pagination | `standards/api-integration` |
| Folder structure and layering | your `architecture/*` module |
| State management and DI | your `state/*` module |
| Routing, deep links, guards | your `navigation/*` module |

### 6.1 Naming conventions (universal)

| Element | Convention | Example |
|---|---|---|
| Files | `snake_case` | `user_profile.dart` |
| Classes | `PascalCase` | `UserProfilePage` |
| Variables / functions | `camelCase` | `getUserProfile()` |
| Constants | `camelCase` | `defaultTimeout` |
| Enums / values | `PascalCase` / `camelCase` | `UserStatus` / `active` |
| Private members | leading underscore | `_internalState` |
| Widgets | descriptive suffix | `SubmitButton`, `UserCard` |

### 6.2 The redaction rule

Never logged, in any environment including local development: passwords, OTPs, access and
refresh tokens, API secrets, and PII (identifying name combinations, government IDs,
financial account numbers, precise location, health data).

**"It's only the dev flavor" is not an exception.** Dev logs get pasted into tickets,
shared in chat, and attached to bug reports.

---

## 7. Code review

Reviewers work the core checklist in `SOP-CORE.md` Section 7 **plus** the checklist from every
module in the project's manifest. Each module ships its own — that's how a BLoC
project and a BLoC project get reviewed correctly without one generic list that fits
neither.

Universal dimensions: correctness · architecture conformance · readability ·
maintainability · performance · security · error handling · edge cases · API handling ·
logging · backward compatibility · platform-specific behaviour on both iOS and Android.

### 7.1 AI-generated code

Same standard, applied with extra attention to the known failure modes:

- Output matching the **selected modules**, not generic conventions from training data
- No silently added dependencies (`git diff pubspec.yaml`)
- No invented APIs or hallucinated package names
- No fabricated documentation entries
- Nothing duplicating what already exists in `core/` or `shared/`

### 7.2 Etiquette

Be specific and constructive. Explain the *why* behind a requested change. Approve
promptly when the bar is met. Prefer suggestions to commands. Reviews teach in both
directions.

---

## 8. Refactoring & technical debt

Full rules: `sop/modules/process/refactoring-tech-debt`.

Debt is recorded in `REFACTORING.md` **when found**, reviewed in sprint planning, and paid
down with **20% of sprint capacity spent from that list** — ordered by impact over effort,
not by what irritated someone that week.

Opportunistic refactoring **must not** ride along in a feature PR: it can't be reviewed
properly and can't be reverted separately. Debt that blocks a release isn't debt, it's a
defect — put it on the board.

---

## 9. Release process

Gates in `SOP-CORE.md` Section 9; mechanics in your `release/*` module.

Universal: release only from `main` · install the **release** artifact on **physical
hardware** and verify the core flow before upload · archive mapping and symbol files ·
tag after a successful upload.

Versioning is `MAJOR.MINOR.PATCH+BUILD` (e.g. `2.4.1+205`). Build numbers are strictly
monotonic across all flavors of one listing — never reused, never decremented.

Branches: `main` · `develop` · `feature/` · `bugfix/` · `hotfix/` · `release/`.

**Losing a release keystore is unrecoverable and forces a new store listing.** Back it up
at kickoff and verify the backup restores.

---

## 10. Onboarding

**Day 1** — read this handbook, then `SOP-CORE.md`, then the modules named in your first
project's manifest. Machine setup, access, run the app on both platforms.

**Week 1** — ship 2–3 small tickets with reviewed PRs. Review someone else's PR with a
senior double-reviewing.

**Month 1** — you can set up a project from the template, **justify a module selection for
a given brief**, produce a release build and install it on hardware, and take a bug from
reproduction through fix and release notes.

---

## 11. Adopting v2.0 on an existing project

No migration, no refactor. About an hour per project.

1. Add the SOP to the repo — submodule `docs/sop/` (recommended) or copy `sop/`
2. Copy `sop.manifest.yaml` to the repo root
3. **Select `arch-layered-classic`** unless the project is already feature-first
4. Select the state, navigation, release, agents, standards, docs, and process modules
   that describe **what the project already does** — this is a description exercise, not
   an aspiration exercise
5. Record anything that doesn't fit under `deviations:` with a reason and an approver
6. Copy the templates from `sop/templates/` for any living document not already present.
   Backfill `FEATURE_MAP.md` and `CONTRIBUTORS.md` from what exists — **do not** backfill
   `CHANGELOG.md` beyond what you can verify from tags
7. Write `AGENTS.md` from the template with the active modules filled in
8. Mobile Lead reviews and signs off the manifest

Step 4 is where teams go wrong. Selecting the modules you *wish* described the project
makes every subsequent PR non-compliant and trains everyone to ignore the manifest.
Describe reality, then improve it deliberately through ADRs.

---

## 12. Quick reference

| Topic | Location |
|---|---|
| Module selection for this project | `sop.manifest.yaml` |
| Universal rules | `sop/SOP-CORE.md` |
| Writing or forking a module | `sop/MODULE-CONTRACT.md` |
| Living document templates | `sop/templates/` |
| Coding standards | `sop/modules/standards/coding-dart-flutter.md` |
| Logging & redaction | `sop/modules/standards/logging-monitoring.md` |
| API standards | `sop/modules/standards/api-integration.md` |
| Environments & flavors | `sop/modules/standards/env-flavors-secrets.md` |
| Agent rules | `sop/modules/agents/` |
| Release process | `sop/modules/release/` |
| Code review checklist | `sop/SOP-CORE.md` Section 7 + each module's checklist |

---

## 13. Glossary

| Term | Definition |
|---|---|
| **ADR** | Architecture Decision Record — one entry per decision that closes off alternatives |
| **Bloc** | Business Logic Component — a state management pattern |
| **Core** | `SOP-CORE.md` — rules true on every project |
| **DI** | Dependency Injection |
| **DTO** | Data Transfer Object |
| **Flavor** | Build variant (dev, staging, prod) |
| **Manifest** | `sop.manifest.yaml` — which modules bind on a project |
| **Module** | A swappable, self-contained set of SOP rules |
| **PII** | Personally Identifiable Information |
| **Repository** | Abstraction between data sources and domain |
| **Seam** | A named contract — the only legal coupling between two modules |
| **Use case** | A single business operation |

---

## 14. Approval & revision history

| Version | Date | Author | Changes |
|---|---|---|---|
| 1.0 | 2026-08-13 | Mobile Engineering Team | Initial release |
| 2.0 | 2026-08-25 | Mobile Engineering Team | Split into handbook + modular SOP. v1.0 Section 6.1 structure preserved as `arch-layered-classic`; core no longer mandates a top-level layout. Added agent modules and the living-documentation system (`CHANGELOG`, `TASKS`, `FEATURE_MAP`, `CONTRIBUTORS`, `DECISIONS`, `KNOWN_ISSUES`, `REFACTORING`) |

---

## 15. v1.0 → v2.0 content map

Every v1.0 section, and where it now lives. Nothing was dropped.

| v1.0 section | v2.0 location |
|---|---|
| 1. Welcome & purpose | Handbook Section 1 |
| 2. Development philosophy | Handbook Section 2 |
| 3. AI-assisted workflow | Handbook Section 4 + `agents/agents-core` |
| 3.5 Guideline files | Handbook Section 4.4 + `sop/templates/AGENTS.md`, `STRUCTURE.md` |
| 4.1.1–4.1.3 Dart, naming, widgets | `standards/coding-dart-flutter` + Handbook Section 6.1 |
| 4.1.4 State management | `state/*` modules |
| 4.1.5 Dependency injection | `state/*` modules |
| 4.1.6 Repository & service patterns | `architecture/*` + `standards/api-integration` |
| 4.1.7–4.1.8 Null safety, async | `standards/coding-dart-flutter` |
| 4.1.9 Navigation | `navigation/*` modules |
| 4.1.10 Localization | `standards/coding-dart-flutter` |
| 4.1.11–4.1.12 Performance, memory | `standards/coding-dart-flutter` |
| 4.1.13 Comments & documentation | `standards/coding-dart-flutter` + `docs/living-docs` |
| 5. Extensions, mixins, reusable widgets | `standards/coding-dart-flutter` |
| 6. Project structure | `architecture/arch-layered-classic` (verbatim) + siblings |
| 6.2 Deviation policy | `SOP-CORE` Section 2 + manifest `deviations:` + `STRUCTURE.md` |
| 7. Logging & monitoring | `standards/logging-monitoring` |
| 8. Environment & flavours | `standards/env-flavors-secrets` |
| 9. API integration | `standards/api-integration` |
| 10. Code review | `SOP-CORE` Section 7 + per-module checklists + Handbook Section 7 |
| 11. QA & Verification | Handled outside this handbook |
| 12. Documentation requirements | `docs/living-docs` + `sop/templates/` |
| 13. Refactoring & tech debt | `process/refactoring-tech-debt` + `templates/REFACTORING.md` |
| 14. Release process | `SOP-CORE` Sections 8–9 + `release/*` modules |
| 15. Appendices | Handbook Sections 13–14 |

**New in v2.0, with no v1.0 equivalent:** module system, manifest, and seam contracts ·
`FEATURE_MAP.md` · `CONTRIBUTORS.md` · `DECISIONS.md` (ADRs) · `TASKS.md` · agent
verification gate.
