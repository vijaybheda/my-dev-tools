# DigiLocker channel integration

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Backend + Legal |

DigiLocker provides **user-consented pull** of **issued** digital documents — stronger trust than photo upload when available.

## Integration summary

| In scope | Out of scope |
| :--- | :--- |
| OAuth login to user DigiLocker | Impersonating DigiLocker app |
| Pull issued RC, DL, PAN (when issued to locker) | Storing user DigiLocker password |
| Map to unified verification outcomes | OCR of DigiLocker screenshot (weak — avoid) |

## Purpose gate

| Purpose | Fit |
| :--- | :--- |
| Document wallet | **Best fit** |
| Light KYC | **Good** for issued docs |
| Regulated lending Aadhaar eKYC | May still need **aggregator** Aadhaar path |
| Fleet RC verify | **Good** if driver links locker |

**HARD GATE:** Become **Authorized Requester** (or use partner who is) before production pull.

## Prerequisites

| Step | Lead time |
| :--- | :--- |
| Entity docs + application | Weeks |
| Security review by DigiLocker program | Weeks–months |
| OAuth client credentials | After approval |
| Legal: purpose alignment with DigiLocker terms | Days |

## vs KYC aggregator

| Channel | Pros | Cons |
| :--- | :--- | :--- |
| DigiLocker | User-controlled; T1 trust | Not all users have docs in locker |
| Aggregator API | Works without locker | Cost; vendor dependency |

Often **both**: offer DigiLocker first, fallback to upload/API.

## Flow (conceptual)

```mermaid
sequenceDiagram
  participant App
  participant Backend
  participant DL as DigiLocker
  App->>Backend: start digilocker session
  Backend->>DL: OAuth authorize URL
  App->>DL: user login + consent
  DL->>Backend: auth code
  Backend->>DL: token + fetch document URI
  Backend->>App: verification outcome T1
```

## Mobile

- Open OAuth in **Chrome Custom Tab / ASWebAuthenticationSession** — not embedded WebView with untrusted JS if policy requires.
- Clear messaging: “You will sign in to **DigiLocker** (Government of India).”
- Do not cache DigiLocker session token in client longer than needed.

## Backend

- Exchange code server-side only.
- Store: document type, issuer, URI ref, fetch timestamp — not full PDF unless required.
- Validate document signature / metadata per DigiLocker API spec when provided.

## Web

- Same OAuth; watch redirect URI allowlist.
- CSP allow DigiLocker domains only on auth route.

## Mapping to playbooks

| DigiLocker doc | Maps to |
| :--- | :--- |
| Driving Licence | DRIVING_LICENSE.md |
| Registration Certificate | RC_VEHICLE.md |
| PAN | PAN.md |
| Aadhaar (e-doc) | AADHAAR.md — still Legal review |

## UX mistakes (avoid)

- Asking user to **photograph** DigiLocker screen → T5 trust.
- Labeling “DigiLocker verified” without Requester contract.
- Pulling docs user did not consent to share.

## Go-live

- [ ] Requester status approved
- [ ] OAuth redirect URIs registered all platforms
- [ ] Consent text mentions DigiLocker subprocessors
- [ ] Fallback path when user has empty locker

See [VENDOR_EVALUATION_AND_CONTRACTS.md](./VENDOR_EVALUATION_AND_CONTRACTS.md) if DigiLocker access is via partner.

## Real system implementation

Shared patterns: [IMPLEMENTATION_REAL_SYSTEM.md](./IMPLEMENTATION_REAL_SYSTEM.md).

### Node.js

| Route | Purpose |
| :--- | :--- |
| `POST /v1/digilocker/session` | Returns `{ sessionId, redirectUrl }` |
| `GET /v1/digilocker/callback` | OAuth code exchange (browser redirect target) |
| `POST /v1/digilocker/pull` | `{ sessionId, docType: rc \| dl \| pan \| aadhaar }` → normalized `VerificationOutcome` |

Never expose `DIGILOCKER_CLIENT_SECRET` to Flutter/React.

### Flutter

```dart
// After session created, launch OAuth
final session = await api.createDigiLockerSession();
await FlutterWebAuth2.authenticate(
  url: session.redirectUrl,
  callbackUrlScheme: 'yourapp',
);
await api.pullDigiLocker(sessionId: session.sessionId, docType: 'dl');
```

Register deep link `yourapp://digilocker/callback` → app calls pull when session ready.

### React

```typescript
window.location.href = session.redirectUrl;
// User returns to /verify/digilocker/done?sessionId= — page calls POST pull with cookie auth
```

### Backend only

- Refresh tokens stored encrypted server-side only.
- Session TTL job cleans abandoned OAuth states.