# Aadhaar integration playbook

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Legal + Backend |

**Highest legal and store risk** in this pack. Read fully before any implementation.

## 1. Integration summary

Aadhaar is issued by **UIDAI**. Most IT companies **cannot** operate as AUA/KUA. Production use requires **eligible partner** paths and a **lawful purpose**.

| In scope (conditional) | Out of scope / prohibited |
| :--- | :--- |
| eKYC / OTP via licensed partner | Direct UIDAI integration without role |
| Masked Aadhaar / VID handling in UX | Displaying full 12-digit except where law allows |
| DigiLocker-linked Aadhaar e-doc pull | Storing biometric templates |
| Consent + audit | Marketing “Aadhaar verified” without eligible verify |

## 2. Purpose gate

| Purpose | Stance |
| :--- | :--- |
| RBI-regulated KYC with partner | Conditional — Legal sign-off |
| Fleet / casual app “collect Aadhaar” | **Forbidden** without narrow lawful basis |
| OCR Aadhaar card + face match only | **Forbidden** as sole KYC for regulated use |
| Document wallet (minimal) | DigiLocker-first preferred |

**HARD GATE:** Complete charter + Legal approval before prod.

## 3. Regulatory landscape

- Aadhaar Act & regulations  
- UIDAI circulars on authentication and eKYC  
- DPDP — sensitive personal data  
- IT Act — reasonable security  

## 4. API and provider landscape

| Path | Trust | IT company typical access |
| :--- | :--- | :--- |
| Partner eKYC / OTP | T3 | Via KYC aggregator contract |
| DigiLocker Aadhaar e-doc | T1 | Requester program |
| Offline XML (QR) verification | T2–T3 | Partner-dependent; strict rules |
| Photo OCR | T5 | **Not sufficient alone** |
| Biometric on device | Rare | Partner + hardware compliance |

## 5. What an IT company cannot do (HARD GATE)

- Host UIDAI encryption keys without agreement  
- Run authentication application as AUA without UIDAI authorization  
- Collect Aadhaar “because competitors do”  
- Retain full Aadhaar number when masked ID suffices  
- Use Aadhaar for unrelated profiling or ads  

## 6. Prerequisites

- [ ] Legal opinion on purpose and partner path  
- [ ] Vendor Aadhaar SKU in **production**  
- [ ] Consent text aligned with UIDAI / DPDP  
- [ ] DPIA recommended  

## 7. Data handling

| Data | Rule |
| :--- | :--- |
| Full Aadhaar | Do not store unless legally compelled |
| VID reference | Prefer |
| Last 4 digits | UI only if needed |
| XML/PDF | Short TTL encrypted blob if required |
| Biometric | **Do not** store |

## 8. Architecture

Never call UIDAI from mobile. All flows through backend + partner. See BACKEND doc.

## 9. Mobile

- Collect **VID** or partner-led OTP flow — avoid raw 12-digit keyboard on first screen if product allows  
- FLAG_SECURE on all Aadhaar screens  
- Disable screenshots where OS allows  
- Clipboard disabled  
- No Aadhaar in push notifications or deep link query params  
- Educate: never share OTP with agents  

## 10. Backend

- Store consent artifact + partner transaction ID  
- No Aadhaar in logs — redaction middleware mandatory  
- Short cache TTL or none per Legal  

## 11. Web

- Discourage full Aadhaar entry on shared PCs  
- Prefer “Continue on mobile” for OTP/eKYC  
- Session timeout aggressive on KYC routes  

## 12. Verification modes (ordered)

1. DigiLocker issued Aadhaar (T1)  
2. Partner OTP / eKYC (T3)  
3. Offline XML via partner (T2–T3)  
4. Upload image (T5) — manual review only, not auto-approve regulated gates  

## 13. Fraud and abuse

- Synthetic Aadhaar cards — rely on T2+ only for decisions  
- OTP phishing — in-app warnings  
- Velocity limits on OTP triggers  

## 14. Re-verification

Rare; event-driven (fraud, address change products) per Legal.

## 15. Human-in-the-loop

Mandatory for any T4/T5 path before high-impact decision.

## 16. Testing

- Partner sandbox only  
- Never use real citizens’ Aadhaar in dev/test  
- Test consent withdrawal mid-flow  

## 17. Store policy mapping

- Declare biometrics/gov ID if face liveness used  
- Accurate privacy labels — Aadhaar is highly sensitive  
- No government impersonation in creatives  

## 18. Go-live checklist

- [ ] Legal written approval  
- [ ] Partner prod credentials  
- [ ] Masking verified in API + support tools  
- [ ] Incident playbooks include UIDAI breach norms  

## 19. Real system implementation

Shared patterns: [IMPLEMENTATION_REAL_SYSTEM.md](./IMPLEMENTATION_REAL_SYSTEM.md).

### Node.js (two-step partner OTP — illustrative)

| Step | Route | Role |
| :--- | :--- | :--- |
| 1 | `POST /v1/verify/aadhaar/init` | Create `requestId`; call vendor init; return `partnerSessionId` (opaque) |
| 2 | `POST /v1/verify/aadhaar/complete` | Submit OTP; vendor completes; store masked outcome |

**Init request**

```json
{ "consentId": "uuid", "method": "otp", "vid": "16-digit-vid-or-empty-for-partner-ui" }
```

**Complete request**

```json
{ "requestId": "uuid", "otp": "123456", "partnerSessionId": "opaque" }
```

**Response (masked)**

```json
{
  "requestId": "uuid",
  "status": "verified",
  "trustTier": "T3",
  "display": { "last4": "1234", "name": "First Last" }
}
```

DigiLocker path: use [DIGILOCKER_CHANNEL.md](./DIGILOCKER_CHANNEL.md) `POST /v1/digilocker/pull` with `docType: aadhaar` after Legal approval.

### Flutter

- Multi-step `AadhaarVerifyFlow`; OTP on `FLAG_SECURE` screen.
- **Do not** log request/response in debug.
- Optional: `method: digilocker` opens `flutter_web_auth_2`.

### React

- Prefer **Continue on mobile** deep link for OTP; if web OTP allowed, short session TTL.

### Backend only

- Vendor webhook may complete step 2 async → update same `requestId`.
- No Aadhaar fields in job logs; redaction middleware required.

## 20. References

- uidai.gov.in — laws and circulars  
- Partner integration guide (post-contract)

See [DIGILOCKER_CHANNEL.md](./DIGILOCKER_CHANNEL.md), [CROSS_CUTTING_COMPLIANCE.md](./CROSS_CUTTING_COMPLIANCE.md).