# Glossary and document maintenance

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Compliance / Tech writing |

## Acronyms and terms

| Term | Meaning | Integration relevance |
| :--- | :--- | :--- |
| **Aadhaar** | 12-digit UID; regulated by UIDAI | Highest compliance surface |
| **AUA** | Authentication User Agency | Direct UIDAI auth; most IT cos are **not** AUAs |
| **KUA** | e-KYC User Agency | eKYC with UIDAI; requires eligibility |
| **VID** | Virtual ID | 16-digit revocable alternative to sharing Aadhaar |
| **PAN** | Permanent Account Number (Income Tax) | Verify via licensed channels |
| **ITD** | Income Tax Department | PAN authority |
| **NSDL / Protean** | PAN infrastructure players | Access via vendors, not direct for typical IT co |
| **Vahan** | National vehicle registry (NIC / MoRTH) | RC lookup |
| **Sarathi** | Driving licence systems (state-linked) | DL verification |
| **MoRTH** | Ministry of Road Transport and Highways | Policy parent for Vahan/Sarathi |
| **PUC** | Pollution Under Control certificate | State PCB issuers; fragmented APIs |
| **FASTag** | RFID toll tag (NPCI / bank issuers) | Status vs recharge are different products |
| **NPCI** | National Payments Corporation of India | FASTag / UPI ecosystem |
| **BBPS** | Bharat Bill Payment System | Bill pay / recharge rails (FASTag recharge) |
| **DigiLocker** | Government document wallet | Issued-doc pull with user OAuth |
| **Requester** | DigiLocker partner org | Onboarding for pull API |
| **CKYC** | Central KYC Registry | For RBI-regulated entities; not default IT co path |
| **KYC aggregator** | Private vendor with govt/API access | Typical path for PAN/RC/DL/Aadhaar eKYC |
| **Account Aggregator (AA)** | RBI framework for **financial** data consent | **Not** identity document verification |
| **DPDP Act 2023** | Digital Personal Data Protection (India) | Fiduciary duties, consent, erasure |
| **Data Fiduciary** | Decides purpose and means of processing | Your app if B2C owner |
| **Data Processor** | Processes on behalf of fiduciary | Typical IT services for clients |
| **DPIA** | Data Protection Impact Assessment | Recommended before Aadhaar / large-scale KYC |
| **IPV** | In-Person Verification | Regulated KYC contexts |
| **PMLA** | Prevention of Money Laundering Act | If financial flows |
| **RTO** | Regional Transport Office | DL/RC issuance |
| **VRN** | Vehicle Registration Number | RC / FASTag mapping |
| **OCR** | Optical character recognition | Weak trust alone |
| **eKYC** | Electronic KYC | Must use eligible channel |
| **OTP** | One-time password | Aadhaar OTP via partner only |

## Trust tiers (use consistently across playbooks)

| Tier | Method | Typical use |
| :--- | :--- | :--- |
| T1 | DigiLocker issued document pull | Strong; user proves control of wallet |
| T2 | Govt / issuer API via licensed vendor | Strong for PAN/RC/DL |
| T3 | Aadhaar OTP / eKYC via eligible partner | Strong; purpose-limited |
| T4 | Upload + manual analyst review | Medium; operations heavy |
| T5 | Upload + OCR only | **Weak** — never sole proof for credit/employment/regulated gates |

## Document version header standard

Every playbook starts with:

```markdown
| Doc metadata | Value |
| Version | semver |
| Last reviewed | YYYY-MM-DD |
| Owner | role or name |
| Next regulatory watch | date |
```

## Change log (this pack)

| Version | Date | Change |
| :--- | :--- | :--- |
| 1.0.0 | 2026-11-24 | Initial playbook pack |

## Regulatory watch calendar (quarterly review)

Review these sources each quarter; update playbooks if terms or APIs change:

| Watch item | Source type | Playbooks affected |
| :--- | :--- | :--- |
| UIDAI circulars & authentication regulations | uidai.gov.in | AADHAAR |
| DPDP rules / grievance norms | MeitY | CROSS_CUTTING, all |
| Google Play policy updates (Data safety, permissions) | play.google.com/console/about/guides | CROSS_CUTTING |
| Apple Review Guidelines 5.x privacy | developer.apple.com | CROSS_CUTTING |
| MoRTH / Vahan API notices | parivahan / NIC | RC, DL, PUC linkage |
| NPCI FASTag program updates | npci.org.in | FASTAG |
| DigiLocker partner program | digilocker.gov.in | DIGILOCKER_CHANNEL |
| CERT-In directions | cert-in.org.in | CROSS_CUTTING |
| RBI KYC Master Direction (if finance) | rbi.org.in | PAN, AADHAAR |

## Maintaining accuracy

- Prefer **official** government and vendor documentation over blog posts.  
- When an API is **not publicly available**, say so in the playbook — do not imply NHAI/NIC “open API.”  
- Mark checklist items: **HARD GATE**, **RECOMMENDED**, **OPTIONAL**.  
- After vendor selection, add an appendix per doc: “Our vendor: ___ endpoints used.”

## Cross-links

Master index: [00_MASTER_INDEX.md](./00_MASTER_INDEX.md)

Implementation (Flutter / React / Node.js): [IMPLEMENTATION_REAL_SYSTEM.md](./IMPLEMENTATION_REAL_SYSTEM.md)