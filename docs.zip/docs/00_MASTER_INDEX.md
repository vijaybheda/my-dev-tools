# India document and vehicle verification — master index

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Product + Legal (assign names) |
| Next regulatory watch | 2026-12-01 |
| Entity baseline | Registered Indian IT company; no aggregator / DigiLocker Requester / AUA-KUA yet |
| Product purpose | **Not finalized** — complete Purpose Charter below before production |

## Playbook map

| File | Use when |
| :--- | :--- |
| [IMPLEMENTATION_REAL_SYSTEM.md](./IMPLEMENTATION_REAL_SYSTEM.md) | **Flutter + React + Node.js** code structure, routes, client patterns |
| [GLOSSARY_AND_DOC_MAINTENANCE.md](./GLOSSARY_AND_DOC_MAINTENANCE.md) | Terms, doc hygiene, regulatory calendar |
| [CROSS_CUTTING_COMPLIANCE.md](./CROSS_CUTTING_COMPLIANCE.md) | Play, App Store, DPDP, security, enterprise pack |
| [privacy_docs/00_PRIVACY_DOCS_INDEX.md](./privacy_docs/00_PRIVACY_DOCS_INDEX.md) | Privacy policy sections, store forms, rejection risks, generation prompt |
| [VENDOR_EVALUATION_AND_CONTRACTS.md](./VENDOR_EVALUATION_AND_CONTRACTS.md) | Choosing and contracting verification partners |
| [BACKEND_UNIFIED_VERIFICATION_SERVICE.md](./BACKEND_UNIFIED_VERIFICATION_SERVICE.md) | API design, adapters, ops |
| [DIGILOCKER_CHANNEL.md](./DIGILOCKER_CHANNEL.md) | Wallet / issued-document pull flows |
| [PAN.md](./PAN.md) | Permanent Account Number verification |
| [AADHAAR.md](./AADHAAR.md) | Aadhaar / identity (highest legal risk) |
| [RC_VEHICLE.md](./RC_VEHICLE.md) | Registration Certificate (Vahan) |
| [DRIVING_LICENSE.md](./DRIVING_LICENSE.md) | Driving Licence (Sarathi) |
| [FASTAG.md](./FASTAG.md) | FASTag status (not recharge by default) |
| [PUC_CERTIFICATE.md](./PUC_CERTIFICATE.md) | Pollution Under Control certificate |

## Purpose and lawful basis charter (HARD GATE)

Do **not** enable production verification until this section is signed by Product + Legal.

```text
Product name:
Fiduciary role: [ ] We are Data Fiduciary  [ ] We are Data Processor for client: ___________

Primary user:
  [ ] End consumer (B2C)  [ ] Fleet operator  [ ] Driver/gig worker  [ ] Business (B2B)

Primary purpose (one sentence):

Decision taken after verification (what changes in the product?):

Regulated sector touch?
  [ ] None  [ ] Lending/NBFC  [ ] Insurance  [ ] Payments/PPI  [ ] Securities  [ ] Marketplace/gig  [ ] Other: ___

Documents required at onboarding:
  [ ] PAN  [ ] Aadhaar  [ ] RC  [ ] DL  [ ] PUC  [ ] FASTag

Lawful basis under DPDP:
  [ ] Consent  [ ] Legitimate use (specify permitted ground)  [ ] Legal obligation

Data retention (max days per doc type — see matrix):

Children (<18): [ ] Not allowed  [ ] Allowed with guardian consent (define)

Cross-border processing: [ ] No  [ ] Yes (list vendors + legal basis)

Sign-off: Product _____ Legal _____ Date _____
```

### Purpose gate (undetermined product)

Until the charter is complete, treat integrations as **documentation and sandbox only**. Default stance for an IT company without extra licenses:

- **PAN / RC / DL** — Conditional on purpose + licensed vendor path.
- **Aadhaar** — Conditional on eligible partner and purpose; **forbidden** for OCR-only “verification.”
- **PUC / FASTag** — Conditional; API availability often blocks MVP without contracts.

## Fiduciary vs processor

| Model | You are | Your obligations |
| :--- | :--- | :--- |
| Own B2C app | **Data Fiduciary** | Privacy notice, consent, grievance officer, erasure, DPDP compliance |
| White-label / build for client | **Data Processor** (usually) | DPA, act only on client instructions, subprocessors disclosed, no secondary use |
| Hybrid (your brand + client data controller) | Clarify in contract | Often you remain processor for verification flows; client owns customer relationship |

**HARD GATE:** Separate tenant credentials, encryption keys, and consent stores per client.

## Sector regulatory overlays

| Sector | Extra norms | See |
| :--- | :--- | :--- |
| Lending / wallets | RBI KYC Master Direction, PMLA, possible CKYC later | CROSS_CUTTING, PAN, AADHAAR |
| Insurance | IRDAI KYC, AML | CROSS_CUTTING |
| Securities | SEBI KYC, IPV | CROSS_CUTTING |
| Marketplace / fleet | Prove authorization to query third-party RC/DL | RC_VEHICLE, DRIVING_LICENSE |
| Document wallet | DigiLocker-first; minimal storage | DIGILOCKER_CHANNEL, AADHAAR |

## Global prerequisites

| ID | Prerequisite | Type | Typical lead time |
| :--- | :--- | :--- | :--- |
| G1 | Signed Purpose Charter | HARD GATE | Days |
| G2 | Grievance officer + public privacy policy URL | HARD GATE | Days |
| G3 | KYC verification vendor contract (sandbox + prod) | HARD GATE for real verification | 2–8 weeks |
| G4 | DigiLocker Authorized Requester (if wallet path) | Conditional HARD GATE | 8–16+ weeks |
| G5 | DPIA / data flow diagram | RECOMMENDED | 1–2 weeks |
| G6 | India-region hosting decision | HARD GATE for KYC data | 1 week |
| G7 | Play Data Safety + Apple Privacy Manifest inventory | HARD GATE before store submit | Ongoing |
| G8 | Cyber insurance / vendor security questionnaire | RECOMMENDED for B2B | 2–4 weeks |
| G9 | Pentest scope for verification APIs | RECOMMENDED pre go-live | 2–3 weeks |

## Phased rollout

| Phase | Exit criteria |
| :--- | :--- |
| 0 — Charter | G1 complete |
| 1 — Vendor | G3 sandbox; no prod secrets on clients |
| 2 — MVP verify | PAN + RC + DL; masked responses |
| 3 — Mobility extras | PUC + FASTag trust tier defined |
| 4 — DigiLocker | Requester live or deferral logged |
| 5 — Aadhaar | Legal + partner path signed |
| 6 — Go-live | Store + ops checklists |

## Recommended build order

1. BACKEND_UNIFIED_VERIFICATION_SERVICE.md  
2. PAN.md  
3. RC_VEHICLE.md + DRIVING_LICENSE.md  
4. PUC_CERTIFICATE.md + FASTAG.md  
5. DIGILOCKER_CHANNEL.md  
6. AADHAAR.md last  

## Data retention matrix (template)

| Document | Store full image? | Store full number? | Preferred | Default max retention |
| :--- | :--- | :--- | :--- | :--- |
| PAN | Avoid | Avoid | Outcome + masked | 90 days post decision |
| Aadhaar | No | No full number | Outcome + ref | 90 days or less |
| RC | Optional | VRN often needed | Status snapshot | Life of relationship |
| DL | Optional | Mask in UI | Status + expiry | Until expiry + 30d |
| PUC | Optional | Cert ref | Expiry + status | Until expiry + 30d |
| FASTag | No | Tag ref | Status snapshot | 30 days rolling |

## RACI (abbreviated)

| Activity | Product | Legal | Backend | Mobile | Web |
| :--- | :---: | :---: | :---: | :---: | :---: |
| Purpose Charter | A | A | C | C | C |
| Vendor selection | C | A | C | I | I |
| Store disclosures | C | A | I | A | A |
| Go-live | A | A | R | R | R |

## Go / no-go (production)

- [ ] Purpose Charter signed  
- [ ] Vendor prod entitlements match charter  
- [ ] No secrets in mobile/web  
- [ ] Retention + purge implemented  
- [ ] Store forms match collection  
- [ ] Consent artifacts stored  
- [ ] Aadhaar path legal sign-off (if in scope)  

Master detail and architecture: see plan and BACKEND_UNIFIED_VERIFICATION_SERVICE.md.