# Unified verification service (backend)

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Backend lead |
| Next regulatory watch | 2026-12-01 |

All clients (Android, iOS, Web) call **your** API only — never vendor URLs with secrets.

## Architecture

```mermaid
sequenceDiagram
  participant Client
  participant API as API_Gateway
  participant Svc as VerificationService
  participant Consent as ConsentStore
  participant Vendor as VendorAdapter
  participant Queue as ReviewQueue
  Client->>API: POST /v1/verify/{type}
  API->>Svc: validate + auth
  Svc->>Consent: attach policyVersion
  Svc->>Vendor: verify (idempotent)
  alt success
    Vendor-->>Svc: normalized result
    Svc-->>Client: masked outcome
  else uncertain
    Svc->>Queue: case for analyst
    Svc-->>Client: pending status
  end
```

## Core resources

| Resource | Purpose |
| :--- | :--- |
| `VerificationRequest` | One user action (type, inputs hash, status) |
| `ConsentArtifact` | policyVersion, timestamp, method, locale |
| `VerificationOutcome` | Normalized fields (see per-doc playbooks) |
| `ReviewCase` | Human-in-the-loop |

## Normalized outcome (example shape)

```json
{
  "requestId": "uuid",
  "type": "pan",
  "status": "verified|failed|pending|expired",
  "trustTier": "T2",
  "maskedPan": "XXXXX1234F",
  "nameMatchScore": 0.92,
  "vendorRef": "opaque",
  "expiresAt": "2026-12-01T00:00:00Z"
}
```

Clients never receive vendor raw XML/PDF unless product explicitly requires and Legal approves.

## API design principles

| Principle | Rule |
| :--- | :--- |
| Idempotency | `Idempotency-Key` header on POST; 24h dedupe window |
| Auth | User session + optional step-up for doc submit |
| Rate limit | Per user + per IP (web) |
| Versioning | `/v1/` prefix; breaking changes → v2 |
| Errors | Stable `code` + safe `message`; details in logs only |

## Error taxonomy (client-safe)

| code | HTTP | User message pattern |
| :--- | :--- | :--- |
| `INVALID_FORMAT` | 400 | Please check the number and try again |
| `NO_MATCH` | 422 | We could not verify this document |
| `VENDOR_UNAVAILABLE` | 503 | Try again later |
| `CONSENT_REQUIRED` | 428 | Accept terms to continue |
| `RATE_LIMITED` | 429 | Too many attempts |

## Consent artifact

Store on every verification:

- `userId`, `policyVersion`, `language`, `timestamp`  
- `purposes[]` from charter  
- `channel` (android/ios/web)  

**HARD GATE:** Reject verify if consent record missing or policy outdated.

## Vendor adapter layer

- Timeout: 15–30s with circuit breaker  
- Retries: idempotent GET only; POST no blind retry  
- Circuit open → queue or graceful degradation per product policy  
- Normalize vendor enums to internal `status`  

## Caching and re-verification

| Type | Cache policy |
| :--- | :--- |
| RC status | Short TTL (24–72h) or on user action |
| DL expiry | Re-verify at expiry - 7d |
| PAN | Re-verify on name change events only |
| Aadhaar | Short TTL; legal may mandate no cache |
| FASTag | 1–24h rolling |
| PUC | Until `expiryDate` |

## Dedupe and abuse

- Hash PAN/DL/VRN; block N accounts per hash (threshold product-defined)  
- Velocity limits on failed attempts  
- Play Integrity / App Attest signals as soft score (do not hard-block all)  

## Human review queue

Trigger when: `trustTier < T3` or vendor `uncertain`.

- Analyst UI masks full ID; role `kyc_reviewer`  
- Dual approval for override to `verified`  
- SLA target: business hours define  

## Webhooks (async vendors)

- HMAC signature header  
- Replay protection (timestamp window)  
- Update `VerificationRequest` idempotently by `vendorRef`  

## Security

| Item | Control |
| :--- | :--- |
| Secrets | KMS / vault; rotate quarterly |
| DB | Encrypt at rest; no images in primary DB if avoidable — object store with TTL |
| PII in logs | Redaction middleware |
| Admin | MFA + IP allowlist optional |

## SLOs (suggested)

| Metric | Target |
| :--- | :--- |
| Verification API p95 latency | < 5s (excl. user upload) |
| Availability | 99.5% |
| Vendor failure handling | 100% return safe error |

## DR

- RPO 1h / RTO 4h for verification DB (tune per business)  
- Backups in India region  
- Runbook: vendor total outage → maintenance flag via remote config  

## OpenAPI (outline)

Document when implementing:

- `POST /v1/verify/pan`  
- `POST /v1/verify/aadhaar`  
- `POST /v1/verify/rc`  
- `POST /v1/verify/dl`  
- `POST /v1/verify/puc`  
- `POST /v1/verify/fastag`  
- `GET /v1/verify/{requestId}`  

## Go-live backend checklist

- [ ] Adapters wired for contracted docs only  
- [ ] Idempotency tested  
- [ ] Consent gate enforced  
- [ ] Purge job for retention matrix  
- [ ] No vendor keys in mobile builds verified via CI scan  
- [ ] Load test at expected peak  

Per-doc inputs/outputs: see individual playbooks.

## Real system implementation (Node.js)

Full stack guide (Flutter, React, backend-only jobs): **[IMPLEMENTATION_REAL_SYSTEM.md](./IMPLEMENTATION_REAL_SYSTEM.md)**.

Implement routes under `apps/api/src/routes/v1/verify/` with one router per type; all orchestration goes through `VerificationService`. Use **Zod** schemas duplicated from OpenAPI for request bodies. Wire **BullMQ** for `pending` outcomes and vendor webhooks.