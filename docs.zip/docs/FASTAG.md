# FASTag integration playbook

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Backend + Product |

## 1. Integration summary

**FASTag** is an RFID toll tag under **NPCI / issuer banks**. This playbook defaults to **status verification**, not wallet recharge.

| In scope (verify MVP) | Out of scope unless separate product |
| :--- | :--- |
| Tag linked to VRN, active/blacklist, low balance flag | Toll **transaction history** |
| Tag ID validation | FASTag **recharge** (BBPS/UPI) |
| Issuer name if vendor returns | NHAI “public API” assumptions |

## 2. Purpose gate

| Purpose | Allowed |
| :--- | :--- |
| Fleet compliance dashboard | Yes with vendor path |
| Trip / logistics gating (tag inactive) | Conditional |
| Consumer recharge app | **Different** compliance + payments scope |

**HARD GATE:** Product boundary doc signed — verify vs recharge.

## 3. Regulatory landscape

- RBI/NPCI FASTag program rules  
- Payment aggregator norms if recharge added  
- DPDP for tag/VRN linkage  

## 4. API and provider landscape

| Path | Notes |
| :--- | :--- |
| Bank / NPCI partner via KYC or fintech vendor | Most realistic |
| Direct NHAI open API for consumers | **Do not assume** for IT co |
| User-uploaded FASTag sticker photo | T5 — weak |

Lead time often **longer** than Vahan — start vendor RFP early.

## 5. Prerequisites

- [ ] Contract explicitly lists FASTag **status** (not only recharge)  
- [ ] Mapping VRN ↔ tag clarified  
- [ ] UX when API unavailable (honest messaging)  

## 6. Data handling

- Store tag ID or VRN reference — minimal  
- Balance may be sensitive — mask in UI (`Low / OK`)  
- No toll location history without separate legal basis  

## 7. Architecture

`POST /v1/verify/fastag` with `vrn` or `tagId` per vendor.

## 8. Mobile

- Explain FASTag is bank-issued  
- Link to issuer app for recharge (external) if not in scope  
- No fake “government FASTag portal” branding  

## 9. Backend

- Short TTL cache (1–24h)  
- Circuit breaker when issuer down  

## 10. Web

Fleet table view; export audit for operators only.

## 11. Verification modes

Vendor status API (T2) → manual attestation (T4) if API missing.

## 12. Fraud

Tag registered to different VRN than user claims — surface mismatch clearly.

## 13. Re-verification

Rolling refresh on fleet dashboard; event on vehicle change.

## 14. Human-in-the-loop

When only photo available (T5).

## 15. Testing

Sandbox tags from vendor; blacklisted; inactive; VRN mismatch.

## 16. Store policy

If recharge added later: Play Billing / UPI disclosure, financial data safety sections.

## 17. Go-live

- [ ] Product boundary (verify-only) documented  
- [ ] Fallback UX when `VENDOR_UNAVAILABLE`  
- [ ] No toll history unless scoped  

## 18. Real system implementation

Shared patterns: [IMPLEMENTATION_REAL_SYSTEM.md](./IMPLEMENTATION_REAL_SYSTEM.md).

### Node.js

- Route: `POST /v1/verify/fastag`
- Adapter returns `503` + `VENDOR_UNAVAILABLE` when issuer API down (document in UI).

**Request**

```json
{
  "vrn": "MH12AB1234",
  "tagId": "34161xxxxxxxx",
  "consentId": "uuid"
}
```

**Response**

```json
{
  "requestId": "uuid",
  "status": "verified",
  "trustTier": "T2",
  "display": {
    "tagStatus": "ACTIVE",
    "balanceHint": "LOW",
    "vrnMatch": true
  }
}
```

### Flutter

- `FastagVerifyScreen`; external link to bank app for **recharge** (out of scope unless product adds BBPS).

### React

- Fleet dashboard widget; poll `GET /v1/verify/requests/:id` if slow vendor.

### Backend only

- Rolling refresh job every 24h for fleet `fastag` records (backend-only scheduler).

## 19. References

npci.org.in FASTag program; issuer partner docs.