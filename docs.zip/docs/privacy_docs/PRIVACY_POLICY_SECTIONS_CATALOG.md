# Privacy policy — sections and declarations catalog

Reference when building or reviewing a policy. Each section lists **purpose**, **typical content**, **when required**, and **store / law hooks**.

---

## 1. Introduction and scope

| Item | Detail |
| :--- | :--- |
| **Purpose** | Who we are, what product/service, who the policy covers |
| **Include** | Legal entity name, product name, effective date, “this policy applies to app + website + …” |
| **Required** | Always |
| **Hooks** | Play/App: policy URL must match entity on listing |

---

## 2. Definitions (optional but useful for B2B / KYC)

| Item | Detail |
| :--- | :--- |
| **Purpose** | Personal data, processing, controller/fiduciary, processor, user, child |
| **When** | Enterprise, regulated data, multi-product |

---

## 3. Information we collect

Split into subsections for clarity (stores and regulators expect categorization).

### 3a. Information you provide

- Account registration, profile, support tickets, forms, uploaded documents, payment details (often tokenized).

### 3b. Automatically collected

- Device type, OS, app version, IP, diagnostics, usage events, crash logs.

### 3c. From third parties

- Sign-in provider profile, payment processor, fraud vendors, identity verification partners.

| **Required** | Always — must match actual code |
| **Hooks** | Play Data safety categories; Apple “Data Linked to You” |

---

## 4. Sensitive and special-category data

| Item | Detail |
| :--- | :--- |
| **Examples** | Government ID, biometric (if any), financial, health, precise location, children’s data |
| **When** | Only if actually processed |
| **Hooks** | DPDP / GDPR sensitivity; Apple “Sensitive Info”; Play “Personal info” + photos |

**Verification apps:** PAN, Aadhaar, DL, RC, selfies for liveness — all belong here with **purpose** and **retention**.

---

## 5. Permissions and device access (mobile)

| Item | Detail |
| :--- | :--- |
| **Purpose** | Map OS permission to feature |
| **Required** | If app requests permissions |
| **Hooks** | Play permission declarations; Apple purpose strings in Info.plist must align |

---

## 6. How we use information

| Item | Detail |
| :--- | :--- |
| **Purpose** | Purpose limitation — list each use (provide service, verify identity, fraud, support, analytics, legal) |
| **Required** | Always |
| **Hooks** | DPDP purpose limitation; no “compatible purposes” without legal basis |

Use a table: **Data category → Purpose → Legal basis (consent / contract / legal obligation / legitimate interests)** where applicable.

---

## 7. Legal bases (GDPR / UK / some global apps)

| Item | Detail |
| :--- | :--- |
| **When** | Users in EEA/UK or you market there |
| **Skip** | India-only B2C may use DPDP framing instead |

---

## 8. India — DPDP Act framing (if India users or entity)

| Item | Detail |
| :--- | :--- |
| **Include** | Notice, consent, withdrawal, grievance officer name + contact, rights (access, correction, erasure), complaints to Data Protection Board |
| **Required** | Indian fiduciary processing digital personal data |
| **See** | [CROSS_CUTTING_COMPLIANCE.md](../CROSS_CUTTING_COMPLIANCE.md) |

---

## 9. Cookies and similar technologies (web)

| Item | Detail |
| :--- | :--- |
| **Include** | Types, purposes, duration, how to opt out |
| **When** | Website or webview with cookies / pixels |

---

## 10. Analytics, advertising, and attribution

| Item | Detail |
| :--- | :--- |
| **Include** | SDK names, data sent, opt-out, personalized ads yes/no |
| **When** | Any analytics or ads SDK |
| **Hooks** | Apple ATT; Play “Data collected” for advertising ID |

---

## 11. Third-party services and subprocessors

| Item | Detail |
| :--- | :--- |
| **Format** | Table: Service, role, data shared, link to their policy |
| **Required** | If any third party processes personal data on your behalf |
| **Hooks** | Apple Privacy Manifest required-reason APIs; Play SDK disclosure |

---

## 12. Data sharing and disclosure

| Item | Detail |
| :--- | :--- |
| **Distinguish** | Subprocessors vs legal disclosures vs business transfers |
| **Avoid** | “We never share” if vendors process data |

---

## 13. Storage, location, and retention

| Item | Detail |
| :--- | :--- |
| **Include** | Countries, cloud regions (e.g. India), retention periods per category, deletion triggers |
| **Required** | Always for identifiable data |
| **Hooks** | Charter retention matrix in [00_MASTER_INDEX.md](../00_MASTER_INDEX.md) |

---

## 14. Security measures

| Item | Detail |
| :--- | :--- |
| **Include** | High-level safeguards (encryption in transit, access controls); **no false claims** (e.g. E2E unless proven) |
| **Required** | Expected by stores and enterprise buyers |

---

## 15. Your rights and choices

| Item | Detail |
| :--- | :--- |
| **Include** | Access, correction, deletion, consent withdrawal, marketing opt-out, restrict processing (as applicable) |
| **Required** | Always |
| **Mobile** | Link to in-app settings if available |

---

## 16. Account and data deletion

| Item | Detail |
| :--- | :--- |
| **Include** | Steps, timeline, what is deleted vs retained by law, vendor cascade |
| **When** | Accounts or persistent identifiers |
| **Hooks** | Play account deletion requirement; Apple 5.1.1(v) |

---

## 17. Children’s privacy

| Item | Detail |
| :--- | :--- |
| **Include** | Age limit, no knowing collection, parental contact, or “not directed to children” |
| **When** | Always (short statement minimum) |
| **Hooks** | COPPA, Families, Play target audience |

---

## 18. International transfers

| Item | Detail |
| :--- | :--- |
| **When** | Data leaves user’s country (e.g. US analytics on India users) |
| **Include** | Safeguards, SCCs, or “stored in India only” if true |

---

## 19. Automated decision-making / profiling

| Item | Detail |
| :--- | :--- |
| **When** | Credit, fraud scores, hiring, or legal effect |
| **Skip** | Simple verification pass/fail may still need purpose disclosure without full profiling section |

---

## 20. Changes to this policy

| Item | Detail |
| :--- | :--- |
| **Include** | How users are notified, version date, material changes |
| **Required** | Always |

---

## 21. Contact and grievance

| Item | Detail |
| :--- | :--- |
| **Include** | Support email, entity address (if appropriate), **grievance officer** (India), DPO (EU if applicable) |
| **Required** | Always |

---

## Optional annexes (often separate pages)

| Annex | Use |
| :--- | :--- |
| **Subprocessor list** | B2B, frequent vendor changes |
| **Region-specific addendum** | US state laws (CCPA/CPRA), Brazil LGPD |
| **Cookie policy** | Large marketing sites |
| **Employee / job applicant privacy** | HR data |

---

## Declaration checklist (policy ↔ product)

Before publish, each line must be **verified in repo or config**:

- [ ] Every SDK in `package.json`, `Podfile`, `build.gradle`, `pubspec.yaml` appears in third-party table or is excluded with reason  
- [ ] Every permission in manifest/plist appears in Section 5  
- [ ] Data safety / App Privacy labels can be filled from Sections 3–11 without contradiction  
- [ ] Deletion flow in Section 16 matches implemented API  
- [ ] Items marked “requires confirmation” in project analysis are resolved or removed from policy  