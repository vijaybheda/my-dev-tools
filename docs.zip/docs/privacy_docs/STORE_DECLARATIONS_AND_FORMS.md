# Store and console privacy declarations

Use this when completing **Google Play Data safety**, **Apple App Privacy**, and related forms. Numbers and categories must match your **published privacy policy** and **code**.

---

## Google Play — Data safety

### Data types (map from inventory)

| Play category | Examples in verification / mobility apps |
| :--- | :--- |
| Personal info | Name, email, phone, user IDs |
| Financial info | If payment or wallet features |
| Health and fitness | Usually N/A unless health product |
| Messages | In-app chat only if implemented |
| Photos and videos | ID scan, selfie, RC/DL images |
| Audio files | Only if voice capture |
| Files and docs | Uploaded certificates |
| Calendar, Contacts | Only if permission used |
| App activity | In-app actions, search history |
| Web browsing | Rare unless in-app browser logs URLs |
| App info and performance | Crash logs, diagnostics |
| Device or other IDs | Advertising ID, instance ID if collected |

### Per data type, declare

| Field | Guidance |
| :--- | :--- |
| Collected / shared | **Collected** = leaves device to your or vendor server; shared = sent to third party |
| Ephemeral | Processing only in memory with no retention — rare for KYC |
| Required vs optional | Match UX (can user skip?) |
| Purpose | App functionality, analytics, fraud, advertising, developer comms, etc. |
| Encryption in transit | Yes if HTTPS/TLS (verify no cleartext endpoints) |

### Other Play questions

| Topic | Verification product note |
| :--- | :--- |
| Account deletion | Required if accounts exist |
| Prominent disclosure | Sensitive permissions before system dialog |
| Families | No gov ID from children unless policy + charter allow |
| Deceptive behavior | No impersonation of government apps |

---

## Apple — App Privacy (nutrition labels)

### Data types (simplified mapping)

| Apple bucket | Link to policy section |
| :--- | :--- |
| Contact Info | Email, phone |
| Identifiers | User ID, device ID |
| Financial Info | Payments |
| Location | Coarse / precise |
| Sensitive Info | Gov ID, racial/ethnic (if collected), etc. |
| Contacts, Photos, etc. | If used |
| Usage Data, Diagnostics | Analytics/crash |

For each: **Data Used to Track You** vs **Linked to You** vs **Not Linked** — must align with ATT and SDK behavior.

### Privacy Manifest (Xcode / SPM / CocoaPods)

| Task | Action |
| :--- | :--- |
| App target | Create/update `PrivacyInfo.xcprivacy` |
| Third-party SDKs | Merge vendor manifests; document **Required Reason API** usage |
| CI | Fail build if new sensitive API without reason string |

Purpose strings in **Info.plist** must match policy (Camera, Location, Photo Library, etc.).

### Other Apple rules (privacy-adjacent)

| Rule | Trigger |
| :--- | :--- |
| Sign in with Apple | Any other third-party login |
| Account deletion | Account creation in app |
| ATT (`AppTrackingTransparency`) | Tracking users across apps/sites |
| Guideline 5.1.1 | Collect only what you need; policy URL in App Store Connect |

---

## Web — cookies and consent

| Region | Typical requirement |
| :--- | :--- |
| EEA / UK | Consent for non-essential cookies; record CMP |
| India (DPDP) | Clear notice; consent where required for processing |
| US (state laws) | Opt-out of sale/share if applicable — rarely “sale” for B2B API |

Policy sections: cookie types, vendors (Google Analytics, etc.), retention, browser controls.

---

## Side-by-side: Play vs Apple (frequent deltas)

| Topic | Google Play | Apple |
| :--- | :--- | :--- |
| Granularity | Form-driven categories | Label buckets + manifest |
| Advertising ID | Explicit in Data safety | Tracking + ATT |
| Photo library | Photos and videos | Photos or Videos |
| Deletion | Data safety + policy | In-app deletion + policy |
| SDK list | Increasingly explicit | Privacy Manifest signatures |
| Encryption export | Less prominent | ERN in Connect |

Document any intentional difference (e.g. “diagnostics not linked on Apple” only if technically true).

---

## Web URL requirements

| Channel | Requirement |
| :--- | :--- |
| Play | Privacy policy URL on store listing |
| Apple | Privacy policy URL in App Store Connect |
| In-app | Link in settings / onboarding for regulated data |

URL must load without login, stay stable, show **effective date**.

---

## Filling forms from `DATA_INVENTORY_WORKSHEET`

1. Export worksheet rows → Play categories (one row per data element).  
2. Same rows → Apple buckets; split tracking vs linked.  
3. Diff worksheet vs policy §3 — fix before submit.  
4. Save PDF/screenshot of completed forms next to release tag.