# Master prompt — analyze project and generate privacy policy

Copy everything inside the **fenced block** below into your AI assistant (Cursor Agent, ChatGPT, etc.) with the repository open. Point the model at this repo’s reference docs:

- `docs/privacy_docs/STORE_REJECTION_RISK_PRIVACY.md`
- `docs/privacy_docs/PRIVACY_POLICY_SECTIONS_CATALOG.md`
- `docs/privacy_docs/APPLICATION_TYPES_MATRIX.md`
- `docs/privacy_docs/DATA_INVENTORY_WORKSHEET.md`
- `docs/CROSS_CUTTING_COMPLIANCE.md` (if present)

**Optional output path:** Save generated artifacts under `docs/privacy_docs/generated/<product-slug>/`.

---

## Prompt (copy from here)

```text
Act as an expert Privacy Policy writer, mobile store compliance specialist (Google Play + Apple App Store), and pragmatic privacy engineer who verifies claims against source code.

## Mission

Thoroughly analyze my entire project and produce a complete, accurate, legally structured privacy policy and compliance pack that matches **actual** data practices—not feature names or README marketing.

## Phase 0 — Classify the product (before deep scan)

Determine and record:

- Product type(s): mobile (iOS/Android/cross-platform), web, desktop, browser extension, API/backend-only, admin portal, hybrid.
- Industry pattern: consumer, B2B SaaS, marketplace, fintech/KYC, health, education, games, IoT, open source, other.
- Target regions and likely laws: India (DPDP), EEA/UK (GDPR), US state privacy, COPPA/children, sector rules (RBI, HIPAA, etc.)—only where supported by code, store targets, or docs.
- Distribution: Google Play, Apple App Store, web-only, enterprise sideload, other.

Use docs/privacy_docs/APPLICATION_TYPES_MATRIX.md to scope which disclosure themes apply. Do not paste the whole matrix—summarize applicability for this project.

## Phase 1 — Project analysis (mandatory; no generic policy yet)

Inspect the full repository with tools, including but not limited to:

### Structure and configs

- Repo layout (monorepo vs single app), environments, feature flags.
- Mobile: AndroidManifest.xml, Gradle dependencies, ProGuard/R8, network security config; iOS Info.plist, entitlements, Podfile/Package.resolved, PrivacyInfo.xcprivacy.
- Cross-platform: pubspec.yaml, expo config, capacitor/cordova, react-native configs.
- Web: package.json, build config, env examples, CSP, cookie usage.
- Backend: routes/controllers, middleware, auth, logging, queues, object storage, DB schemas/migrations, retention jobs, deletion endpoints.
- CI/CD, Terraform/cloud templates if they define data regions.

### Dependencies and SDKs

- Lockfiles and manifests for analytics, crash reporting, ads, attribution, auth (Google, Apple, Facebook), payments, push, maps, chat, fraud, KYC/identity vendors.
- For each SDK: what data it sends, whether it is first-party collection or vendor subprocessoring, link to vendor privacy policy when identifiable.

### Permissions and platform APIs

- Every Android permission and iOS usage description string.
- Runtime permission flows in UI code.
- Apple Required Reason APIs if manifest or code references them.

### Data flows

- What is collected from users vs generated automatically.
- What stays on device vs transmitted to your servers vs third parties.
- PII/sensitive categories: government ID, biometrics, financial, location, contacts, photos, audio, health, children.
- Logging, crash, and analytics: grep for log statements that may leak PII (document numbers, tokens).

### Security claims to verify

- TLS-only endpoints, encryption at rest, tokenization, “no storage” claims, E2E encryption—only assert what code/config supports.

### Rejection-risk cross-check

Read docs/privacy_docs/STORE_REJECTION_RISK_PRIVACY.md (and any project-specific compliance doc such as docs/CROSS_CUTTING_COMPLIANCE.md).

For each checklist item: mark Applicable (Yes/No) based on **this** implementation. Only address applicable items in the policy and fix list. Do not boilerplate irrelevant store rules.

## Phase 2 — Store-specific compliance framing

Prepare content so store forms can be completed consistently:

- Google Play Developer Program Policies, User Data policy, Data safety form categories.
- Apple App Store Review Guidelines 5.1.x, App Privacy labels, Privacy Manifest, ATT if tracking.
- Web: cookies/tracking if the project includes a web property.

Use docs/privacy_docs/STORE_DECLARATIONS_AND_FORMS.md as a mapping guide.

## Phase 3 — Privacy policy content

Generate a publish-ready privacy policy using docs/privacy_docs/PRIVACY_POLICY_SECTIONS_CATALOG.md. Include only sections that apply. Minimum set for most apps:

Introduction and scope · Information we collect (split user/auto/third party) · Sensitive data (if any) · Permissions (mobile) · How we use data · Legal bases (GDPR and/or DPDP as applicable) · Cookies (web) · Analytics/ads (if any) · Third parties/subprocessors · Sharing · Storage, location, retention · Security · User rights · Account/data deletion (if accounts) · Children · International transfers (if any) · Changes · Contact/grievance (India: grievance officer if DPDP applies).

Tone: clear, professional, suitable for a public URL—not legalese for its own sake.

## Phase 4 — Accuracy rules (strict)

- Never invent features, data types, security controls, or “we do not collect” statements without code evidence.
- Distinguish: collected by you, processed only on device, shared with subprocessors, ephemeral processing.
- Every app permission must match a real feature in code.
- Flag unverified items in a “Requires developer confirmation” list—do not state them as facts in the policy.
- No misleading claims (zero collection, full anonymity, E2E encryption) without proof.
- If the project is B2B/processor-only, state roles clearly; do not copy a B2C consumer template blindly.

## Phase 5 — Deliverables (use these exact headings in your response)

### A. Privacy Policy

Full markdown policy ready to publish (and note suggested filename, e.g. docs/privacy_docs/generated/<slug>/privacy-policy-v1.0.md).

### B. Store compliance review

- Google Play checklist (applicable items only) with status: addressed / gap / N/A.
- Apple App Store checklist (same).
- Platform differences worth documenting (Play vs Apple).

### C. Project findings

- Data inventory table (or filled DATA_INVENTORY_WORKSHEET format).
- Permissions table with evidence paths.
- Third-party SDK/service table.
- Network endpoints that handle personal data (high level).
- “Requires developer confirmation” list.

### D. Recommended fixes

- Mismatches between code and policy wording.
- Code/config changes to align behavior with disclosures.
- UX/consent flows needed before store submission.
- Store form fields that look wrong or incomplete based on findings.

### E. Rejection risk summary

From STORE_REJECTION_RISK_PRIVACY.md: list applicable risks still open (⚠️) after your review.

## Phase 6 — Final validation

Before finishing:

- Cross-check policy Section 3 against dependency scan and backend models.
- Cross-check permissions against manifests/plists.
- Verify Play Data safety and Apple App Privacy labels could be filled from findings without contradiction.
- Separate **verified facts** from **assumptions** and **open questions**.
- If analysis is blocked (missing modules, private packages), state what was not visible.

## Output constraints

- Do NOT start with a generic privacy policy before Phase 1 analysis summary.
- Prefer file-path evidence (e.g. android/app/src/main/AndroidManifest.xml:42) when citing findings.
- If the repo is documentation-only or non-runnable, analyze docs and configs but label gaps explicitly.

## Legal note

Add a one-line reminder that output is not legal advice and requires review by qualified counsel for the operating entity and jurisdictions.

Goal: a policy and compliance pack that accurately represents the application and reduces privacy-related Google Play and Apple rejection risk.
```

---

## Post-generation checklist (human)

1. Legal review of final policy text.  
2. Fill Play Data safety and Apple labels from **C. Project findings**.  
3. Publish policy at stable URL; set effective date.  
4. Update `POLICY_VERSION` / consent flows if the codebase references them.  
5. Archive generated files under `docs/privacy_docs/generated/`.

## Customization hints

| If your project is… | Add to the prompt |
| :--- | :--- |
| Flutter + Node (this repo pattern) | “Prioritize `IMPLEMENTATION_REAL_SYSTEM.md`, verification adapters, and no client-side vendor keys.” |
| Web-only | “Skip mobile permissions; emphasize cookies and server logs.” |
| API-only B2B | “Produce processor-focused policy + subprocessor annex; separate customer DPA.” |
| Kids app | “COPPA/Families and STORE_REJECTION_RISK section F mandatory.” |
| Multi-flavor builds | “Analyze each product flavor / bundle ID separately if data collection differs.” |