# Privacy documentation hub

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Product + Legal |
| Related | [CROSS_CUTTING_COMPLIANCE.md](../CROSS_CUTTING_COMPLIANCE.md), [00_MASTER_INDEX.md](../00_MASTER_INDEX.md) |

Use this folder when you need to **discover what to disclose**, **draft a privacy policy**, **fill store forms**, or **run an AI-assisted policy generation** against a real codebase.

## Files in this folder

| File | Purpose |
| :--- | :--- |
| [APPLICATION_TYPES_MATRIX.md](./APPLICATION_TYPES_MATRIX.md) | What to disclose by product shape (mobile, web, API, desktop, extensions, IoT, etc.) |
| [PRIVACY_POLICY_SECTIONS_CATALOG.md](./PRIVACY_POLICY_SECTIONS_CATALOG.md) | Standard sections, optional blocks, and jurisdiction add-ons |
| [STORE_DECLARATIONS_AND_FORMS.md](./STORE_DECLARATIONS_AND_FORMS.md) | Google Play Data safety, Apple App Privacy, web consent banners |
| [STORE_REJECTION_RISK_PRIVACY.md](./STORE_REJECTION_RISK_PRIVACY.md) | Privacy-related rejection patterns (map to **your** implementation only) |
| [DATA_INVENTORY_WORKSHEET.md](./DATA_INVENTORY_WORKSHEET.md) | Blank worksheet for project analysis output |
| [EXAMPLE_PRIVACY_POLICY_TEMPLATE.md](./EXAMPLE_PRIVACY_POLICY_TEMPLATE.md) | Fictional example policy (structure + tone; replace with project facts) |
| [PROMPT_GENERATE_PRIVACY_POLICY.md](./PROMPT_GENERATE_PRIVACY_POLICY.md) | **Refined master prompt** — analyze repo → policy + compliance pack |

## Workflow

```text
1. Classify app type        → APPLICATION_TYPES_MATRIX.md
2. Run project scan         → PROMPT_GENERATE_PRIVACY_POLICY.md (+ DATA_INVENTORY_WORKSHEET)
3. Pick policy sections     → PRIVACY_POLICY_SECTIONS_CATALOG.md
4. Fill store UIs             → STORE_DECLARATIONS_AND_FORMS.md
5. Pre-submit risk pass       → STORE_REJECTION_RISK_PRIVACY.md + CROSS_CUTTING_COMPLIANCE.md
6. Publish                    → EXAMPLE_* as format reference only until replaced by generated policy
```

## Outputs you should keep per product

| Artifact | Location (suggested) |
| :--- | :--- |
| Live privacy policy (HTML or hosted URL) | Production site + store listing |
| Versioned policy source | `docs/privacy_docs/generated/<product>-privacy-policy-vX.Y.md` (create when you generate) |
| Data inventory snapshot | Same folder or security repo |
| Play / Apple disclosure export | Release checklist attachment |

## Legal disclaimer

Docs here are **engineering and product playbooks**, not legal advice. A qualified lawyer should review the final policy for your entity, jurisdictions, and regulated activities (e.g. KYC, health, children).