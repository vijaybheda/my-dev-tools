# Store rejection risk — privacy and data (checklist)

**How to use:** For each item, answer **Applicable?** (Yes/No) based on **this project’s code and features**. Only items marked **Yes** must be addressed in the privacy policy, in-app UX, and store forms.

Status key when reviewing: ✅ Addressed | ⚠️ Gap | ➖ Not applicable | ❓ Needs developer confirmation

---

## A. Policy and disclosure hygiene

| ID | Risk | Applicable when | Mitigate in |
| :---: | :--- | :--- | :--- |
| A1 | Privacy policy URL missing, broken, or generic template | Always for store apps | Listing + in-app link |
| A2 | Policy entity does not match developer account | Always | Intro section |
| A3 | Policy contradicts app behavior (collects data but claims none) | Data collection exists | Full resync after code scan |
| A4 | No description of third-party SDK data collection | Any SDK phones home | Third-party table + forms |
| A5 | Sensitive data not called out (gov ID, location, contacts) | Those features exist | Sensitive data section |
| A6 | Policy not updated after major feature release | Version bump without policy update | Version date + change log |

---

## B. Google Play — data and permissions

| ID | Risk | Applicable when | Mitigate in |
| :---: | :--- | :--- | :--- |
| B1 | Data safety form incomplete or inaccurate | Android app | Data safety + policy |
| B2 | Permission requested without core use (SMS, contacts, background location) | Permission in manifest | Remove or justify |
| B3 | No prominent disclosure before runtime permission | Dangerous permissions | In-app screen + policy |
| B4 | Deceptive behavior (fake government UI) | Gov-themed flows | UX + policy clarity |
| B5 | Account deletion not offered when accounts exist | Login/signup | Deletion section + UI |
| B6 | Families / children: inappropriate data collection | Kids audience or ID from minors | Children section + age gate |
| B7 | Photo/Video access policy mismatch | Camera/gallery | Permission section |
| B8 | Data encrypted in transit claimed but HTTP cleartext found | Network layer | Code fix + policy truth |

---

## C. Apple App Store — privacy

| ID | Risk | Applicable when | Mitigate in |
| :---: | :--- | :--- | :--- |
| C1 | App Privacy labels do not match data collection | iOS app | Labels + policy |
| C2 | Missing or incomplete Privacy Manifest | iOS 17+ expectations | `PrivacyInfo.xcprivacy` |
| C3 | Required Reason APIs used without declared reasons | Apple APIs in audit list | Manifest reasons |
| C4 | Tracking without ATT prompt | IDFA / cross-app tracking | ATT + policy |
| C5 | Sign in with Apple missing alongside Google/Facebook login | Other social login present | Product change |
| C6 | Purpose strings vague (“We need camera”) | Camera/location/photos | Info.plist + policy |
| C7 | No in-app account deletion | Account creation | Deletion flow |
| C8 | Guideline 5.1.1 — data minimization | Over-collection | Product + policy |

---

## D. KYC / identity / document verification (this domain)

| ID | Risk | Applicable when | Mitigate in |
| :---: | :--- | :--- | :--- |
| D1 | Aadhaar handled without lawful partner path | Aadhaar in flows | Legal + product; policy subprocessors |
| D2 | Full ID stored in logs, Crashlytics, analytics | Any verify flow | Code hygiene + policy retention |
| D3 | Vendor API keys in client | Mobile/web calls vendor directly | Server-side only |
| D4 | Retention not disclosed or exceeds charter | DB stores documents | Retention section |
| D5 | User cannot request erasure | DPDP / store expectations | Rights + deletion |
| D6 | Implying government endorsement | Gov branding | Marketing + policy disclaimer |

---

## E. Web and backend

| ID | Risk | Applicable when | Mitigate in |
| :---: | :--- | :--- | :--- |
| E1 | Session cookies without cookie disclosure | Web app | Cookies section |
| E2 | PII in server logs without mention | Logging | Policy + retention |
| E3 | Open API without authentication collecting PII | Public endpoints | Security + notice at point of collection |
| E4 | Cross-border analytics on EU/India users without disclosure | Foreign SaaS analytics | International transfers |

---

## F. Children and regulated audiences

| ID | Risk | Applicable when | Mitigate in |
| :---: | :--- | :--- | :--- |
| F1 | Directed to children but adult privacy policy only | Kids app | COPPA / Families |
| F2 | Behavioral advertising to children | Ads in kids app | Remove ads or comply |
| F3 | Age gate missing for sensitive processing | General audience + sensitive data | UX + policy age statement |

---

## G. Consistency validation (run before submit)

| Check | Pass criteria |
| :--- | :--- |
| Policy §3 ↔ Data inventory worksheet | Same categories and purposes |
| Policy §5 ↔ AndroidManifest + Info.plist | Every permission explained |
| Policy §11 ↔ dependency lockfiles | Every analytics/auth SDK listed |
| Play Data safety ↔ Policy | No category only in one place |
| Apple labels ↔ Policy | Tracking flags consistent |
| Rejection list | Every **Applicable: Yes** row has ✅ or tracked ⚠️ |

Attach this completed table to release checklist (see [CROSS_CUTTING_COMPLIANCE.md](../CROSS_CUTTING_COMPLIANCE.md)).