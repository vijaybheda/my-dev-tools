# Application types — privacy and disclosure matrix

Use this when scoping **what must appear** in a privacy policy and in store/console disclosures. Rows are **product shapes**; columns are **data or control themes**. Mark each cell: **Yes** (in scope), **No**, **Conditional**, **N/A**.

## Legend

| Symbol | Meaning |
| :--- | :--- |
| **Y** | Typically collect or process — must disclose if implemented |
| **C** | Common for this app type — verify in code |
| **N** | Usually not applicable unless you added the feature |
| **R** | Regulated / high scrutiny if enabled (KYC, health, kids, finance) |

---

## Core matrix (all channels)

| Theme | Mobile app (iOS/Android) | Mobile cross-platform (Flutter/RN) | Web app (SPA) | Web + backend API | Desktop (Electron/native) | Browser extension | REST/GraphQL API only | Admin / internal tool |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| Account (email, phone, password) | C | C | C | C | C | C | C | C |
| Government / financial ID (PAN, Aadhaar, DL, RC) | R | R | R | R | R | R | R | R |
| Device identifiers (IDFA, GAID, Android ID) | C | C | N | N | C | C | N | N |
| Precise / coarse location | C | C | C | C | C | C | C | N |
| Camera / photos / files | C | C | C | C | C | C | N | N |
| Contacts / calendar | C | C | N | N | N | C | N | N |
| Push notification tokens | Y | Y | C | C | C | N | N | N |
| Crash / analytics (Firebase, Sentry, etc.) | C | C | C | C | C | C | C | C |
| Advertising / attribution | C | C | C | N | C | C | N | N |
| Payments (card, UPI, IAP) | C | C | C | C | C | N | C | N |
| Cookies / local storage | N | N | Y | Y | N | Y | N | C |
| Server logs (IP, user-agent) | Y | Y | Y | Y | Y | Y | Y | Y |
| Third-party auth (Google, Apple, etc.) | C | C | C | C | C | C | C | C |
| Children (<13 / <18) | R | R | R | R | R | R | R | R |
| Cross-border transfer | C | C | C | C | C | C | C | C |

---

## By industry pattern

| Industry pattern | Extra sections in policy | Store / legal notes |
| :--- | :--- | :--- |
| **Identity / KYC / document verification** | Sensitive ID, retention, purpose limitation, subprocessors, India localization | Play/Apple: accurate “Data safety”; no fake gov branding; account deletion if accounts exist; DPDP notice + grievance officer (India) |
| **Marketplace / gig** | Profiles, messages, location trips, background checks | Minimize collection; disclose background check vendor |
| **Health / wellness** | Health data, HIPAA/GDPR sensitive category if applicable | Often **not** allowed in general app stores without compliance program |
| **Education** | Student data, school contracts, COPPA/FERPA if US minors | Restrict behavioral ads; parental consent flows |
| **Games (ads + IAP)** | Children, ads personalization, virtual currency | Families program; age gates; ATT on iOS if tracking |
| **SaaS B2B** | Processor vs controller, DPA, subprocessor list, enterprise SSO | Policy often split: **website** vs **product** vs **DPA** |
| **IoT / connected device** | Device telemetry, firmware, pairing | Physical product + app dual disclosure |
| **Open source / self-hosted** | “We do not operate a hosted service” if true | Clarify what telemetry in binaries |

---

## Platform-specific artifacts

| Platform | You must align policy with |
| :--- | :--- |
| **Google Play** | Data safety form, permissions declarations, Photo/Video policy if media, Families if kids |
| **Apple App Store** | App Privacy labels, Privacy Manifest (`PrivacyInfo.xcprivacy`), ATT if tracking, Sign in with Apple rule |
| **Web (EU/UK)** | Cookie banner / CMP if non-essential cookies |
| **Web (India)** | DPDP notice, consent, grievance contact |
| **Windows/Mac stores** | Similar to mobile; less granular than Apple’s labels |

---

## Permission → disclosure mapping (mobile)

| Permission (examples) | Policy must explain |
| :--- | :--- |
| `CAMERA` | Why (scan ID, profile photo), optional vs required |
| `READ_MEDIA_*` / photo library | Upload flow, whether images leave device |
| `ACCESS_FINE_LOCATION` | Feature tied to location, background or not |
| `POST_NOTIFICATIONS` | Marketing vs transactional |
| `READ_CONTACTS` | Sync, invite, or fraud — if not core, remove permission |
| `RECORD_AUDIO` | Voice features only if used |

Always cross-check **AndroidManifest.xml**, **Info.plist**, and runtime permission requests in code—not README alone.

---

## Web-specific collection

| Mechanism | Disclose as |
| :--- | :--- |
| HTTP cookies (session, analytics) | Cookies and tracking |
| `localStorage` / IndexedDB | Similar to cookies; retention |
| Fingerprinting (canvas, fonts) | High risk — disclose and justify |
| Embedded third parties (maps, chat widgets) | Third-party services table |
| Service workers / push | Notifications + data cached |

---

## API-only and backend services

If there is **no consumer UI**, the privacy policy still applies if you process personal data on behalf of customers:

- State **B2B role** (processor) vs direct collection (fiduciary).
- Link **DPA** and **subprocessor** page.
- Describe **API fields** that constitute personal data (do not publish secrets).

---

## How to use with verification products (this repo’s domain)

For PAN, Aadhaar, RC, DL, PUC, FASTag flows, combine this matrix with:

- [AADHAAR.md](../AADHAAR.md) — highest sensitivity  
- [CROSS_CUTTING_COMPLIANCE.md](../CROSS_CUTTING_COMPLIANCE.md) — Play, Apple, DPDP  
- [00_MASTER_INDEX.md](../00_MASTER_INDEX.md) — retention and purpose charter  

Treat **server-side vendor calls** as subprocessors; **never** claim “we do not store ID data” if logs, caches, or DB rows hold them.