# Data inventory worksheet (project analysis output)

Fill during codebase analysis (human or AI). One row per **data element** or **collection event**. Link evidence (file path, config key).

**Product / repo:** _______________  
**Analysis date:** _______________  
**Analyst:** _______________  
**Policy version target:** _______________

---

## 1. Data elements

| ID | Data element | Category (PII/sensitive/device) | Source (user / auto / 3rd party) | Stored? Where | Encrypted at rest? | Retention | Purpose | Legal basis | Shared with (vendor) | Play category | Apple bucket | Evidence (path) | Verified? |
| :---: | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :---: |
| D-001 | | | | | | | | | | | | | |
| D-002 | | | | | | | | | | | | | |

---

## 2. Permissions (mobile)

| Permission | Platform | Required for feature | In-app disclosure? | Info.plist / manifest purpose | Policy § ref | Evidence |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| | | | | | | |

---

## 3. Third-party SDKs and services

| Name | Version | Type (analytics/auth/ads/crash/KYC) | Data sent | First-party vs vendor processing | Privacy policy URL | Play shared? | Apple linked/tracking? | Evidence |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| | | | | | | | | |

---

## 4. Network and endpoints

| Endpoint / host | Method | Auth | PII in request/response | TLS only? | Evidence |
| :--- | :--- | :--- | :--- | :--- | :--- |
| | | | | | |

---

## 5. Local processing only (not transmitted)

| Data | Processing | Retention on device | Evidence |
| :--- | :--- | :--- | :--- |
| | | | |

---

## 6. Items requiring developer confirmation

| ID | Question | Why unverified | Owner | Resolution |
| :---: | :--- | :--- | :--- | :--- |
| Q-001 | | | | |

---

## 7. Deletion and export

| Capability | Implemented? | Steps for user | Back-end tables / buckets | Vendor cascade | Evidence |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Account deletion | | | | | |
| Data export | | | | | |

---

## 8. Sign-off

| Role | Name | Date | Notes |
| :--- | :--- | :--- | :--- |
| Engineering | | | |
| Legal / DPO | | | |
| Product | | | |