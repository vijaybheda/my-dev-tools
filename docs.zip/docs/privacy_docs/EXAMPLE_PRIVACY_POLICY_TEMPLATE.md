# Example privacy policy (fictional template)

> **Not for publication.** Replace all bracketed placeholders with facts verified from your project. Delete this notice in the live version.  
> **Fictional product:** *VerifyGo* — document verification for fleet operators (illustrates structure for a KYC-style app).

**Effective date:** [YYYY-MM-DD]  
**Last updated:** [YYYY-MM-DD]

---

## 1. Introduction

[Legal Entity Name] (“**we**,” “**us**,” or “**our**”) operates the VerifyGo mobile application and website (collectively, the “**Service**”). This Privacy Policy explains how we collect, use, disclose, and protect personal information when you use the Service.

By using the Service, you agree to this Privacy Policy. If you do not agree, do not use the Service.

---

## 2. Scope

This policy applies to:

- VerifyGo for Android and iOS  
- [https://example.com](https://example.com)  
- Customer support channels listed in Section 15  

It does not apply to third-party websites or services linked from the Service.

---

## 3. Information we collect

### 3.1 Information you provide

We may collect:

| Data | When |
| :--- | :--- |
| Name, email, phone | Account registration |
| Business name, fleet ID | B2B onboarding |
| Government-issued identifiers (e.g. PAN, driving licence number, vehicle registration) | When you submit verification requests |
| Photographs of documents | When you use the camera or file upload flow |
| Support messages | When you contact us |

### 3.2 Information collected automatically

| Data | Purpose |
| :--- | :--- |
| Device model, OS version, app version | Compatibility and support |
| IP address, approximate location (from IP) | Security and fraud prevention |
| App interaction events | Product improvement |
| Crash and diagnostic logs | Stability (via [Firebase Crashlytics / Sentry — **use actual SDK**]) |

We do **not** use crash reports to collect document images unless you explicitly attach them in feedback (we discourage attaching ID images to support tickets).

### 3.3 Information from third parties

| Source | Data |
| :--- | :--- |
| Sign-in with Google / Apple | Name, email, provider user ID |
| Identity verification partner [**Vendor Name**] | Verification outcome, reference IDs |
| Payment processor [**Name**] | Transaction status (we do not store full card numbers) |

---

## 4. Sensitive information

Government identifiers and document images are **sensitive**. We collect them only to:

- Verify eligibility for fleet onboarding  
- Comply with contractual obligations to your employer or lessor  
- Prevent fraud  

We do not use sensitive information for advertising.

---

## 5. Permissions (mobile)

| Permission | Why we request it |
| :--- | :--- |
| Camera | Capture document photos for verification |
| Photos / storage | Upload existing images |
| Notifications | Verification status and security alerts |
| Internet | Required to use the Service |

You can deny optional permissions; some features may not work.

---

## 6. How we use information

We use personal information to:

- Provide and maintain the Service  
- Process verification requests through our subprocessors  
- Authenticate users and secure accounts  
- Respond to support requests  
- Analyze usage and fix bugs  
- Comply with law and enforce our terms  

**Legal bases (where applicable):** contract performance, consent (where required), legal obligation, legitimate interests in securing the Service.

---

## 7. India — Digital Personal Data Protection Act

We act as a **Data Fiduciary** for personal data processed through the VerifyGo consumer application. We provide notice through this policy and collect **consent** where required before processing.

**Your rights** may include access, correction, erasure, and grievance redressal. To exercise rights, contact us at Section 15.

**Grievance officer:**  
Name: [Full Name]  
Email: [grievance@example.com]  
Address: [Registered office, India]

---

## 8. Cookies (website)

We use essential cookies for session management and [analytics cookies — **if used**]. You can control cookies through your browser settings. See [Cookie Policy URL] if maintained separately.

---

## 9. Analytics and diagnostics

We use [list SDKs] to understand app performance. These providers may process device and usage data as described in their privacy policies:

- [SDK 1 — link]  
- [SDK 2 — link]  

We do **not** use analytics to sell your personal information.

---

## 10. Third-party service providers

| Provider | Role | Data shared |
| :--- | :--- | :--- |
| [Cloud host — e.g. AWS ap-south-1] | Hosting | All data stored in the Service |
| [KYC vendor] | Verification API | ID numbers, images for verification session |
| [Crash/analytics vendor] | Diagnostics | Device and crash metadata |

A current subprocessor list is available at [URL] or on request.

---

## 11. How we share information

We share personal information:

- With providers in Section 10 under contracts  
- With your fleet operator when you use a B2B account (as stated in your agreement)  
- When required by law or to protect rights and safety  
- In connection with a merger or acquisition (with notice where required)

We do not sell personal information.

---

## 12. Storage and retention

Data is stored in **[India / regions — verified]** where possible.

| Data type | Retention |
| :--- | :--- |
| Verification outcomes | [90 days / relationship life — match charter] |
| Document images | [deleted after verification / max N days] |
| Account data | Until account deletion + legal hold period |
| Logs | [30–90 days rolling — verified] |

---

## 13. Security

We use administrative, technical, and organizational measures including TLS in transit, access controls, and vendor security reviews. No method is 100% secure.

---

## 14. Your choices

- Update profile in app settings  
- Opt out of marketing emails via unsubscribe link  
- Withdraw consent where processing is consent-based (may limit features)  
- Request access or deletion (Section 16)

---

## 15. Account and data deletion

In the app: **Settings → Account → Delete account**.

After request, we delete or anonymize personal information within **[30] days**, except where retention is required by law. We instruct subprocessors to delete applicable data.

---

## 16. Children

The Service is not directed to children under **18**. We do not knowingly collect data from children.

---

## 17. International transfers

[If applicable: describe transfers and safeguards. If India-only hosting, state that.]

---

## 18. Changes

We may update this policy. We will post the new effective date and, for material changes, provide in-app or email notice where required.

---

## 19. Contact

**[Legal Entity Name]**  
Email: [privacy@example.com]  
Address: [Address]  
Support: [support@example.com]

---

## Document history

| Version | Date | Summary |
| :--- | :--- | :--- |
| 1.0 | [YYYY-MM-DD] | Initial publication |