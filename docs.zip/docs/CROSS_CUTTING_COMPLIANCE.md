# Cross-cutting compliance — Play, App Store, DPDP, security

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Legal + Mobile leads |

Applies to PAN, AADHAAR, RC, DL, PUC, FASTAG integrations.

## Google Play

- **Data safety** must match actual collection (gov ID, photos, name, DOB, vehicle data).
- **Permissions:** CAMERA / photo picker with in-app justification; avoid SMS read unless core.
- **Deceptive behavior:** No fake government branding.
- **Account deletion** when accounts store KYC.
- **Families:** Do not collect government ID from children unless charter + policy allow.

## Apple App Store

- Guidelines **5.1.1 / 5.1.2** — disclose collection; minimize data.
- **Sign in with Apple** if any other social login exists.
- **Privacy Manifest** and third-party SDK signatures.
- **Account deletion** in-app if signup exists.
- **Export compliance (ERN)** for encryption.

## DPDP Act 2023 checklist

| Item | Type |
| :--- | :--- |
| Notice before/at collection | HARD GATE |
| Consent + withdrawal | HARD GATE |
| Purpose limitation | HARD GATE |
| Grievance officer in notice | HARD GATE |
| Erasure workflow + vendor cascade | HARD GATE |
| Reasonable security | HARD GATE |
| DPIA for high-risk (Aadhaar scale) | RECOMMENDED |

## CERT-In / ops

- Named incident owner; Legal intake for breaches.
- No PAN/Aadhaar in application or crash logs.

## Data localization

Process and store KYC in **India** unless Legal approves cross-border with DPA.

## Mobile hardening

| Control | Notes |
| :--- | :--- |
| FLAG_SECURE (Android) | Sensitive verification screens |
| Clipboard off | ID fields |
| Play Integrity / App Attest | Optional soft signals on submit |

## Web

HTTPS, CSRF, CSP on uploads, rate limits, shared-device warnings for Aadhaar.

## SDK inventory

Track each SDK for Play Data safety and Apple privacy manifest.

**HARD GATE:** KYC vendor calls server-side only.

## Enterprise pack

Architecture diagram, subprocessors, DPA, retention SLAs, VAPT summary.

## Go-live

- [ ] Privacy policy + grievance officer live
- [ ] Play Data Safety + Apple labels
- [ ] Account deletion tested
- [ ] Pentest or security review on verify API

See [00_MASTER_INDEX.md](./00_MASTER_INDEX.md).

## Real system implementation (compliance in code)

Engineering checklist tied to [IMPLEMENTATION_REAL_SYSTEM.md](./IMPLEMENTATION_REAL_SYSTEM.md):

- [ ] `X-Client-Channel` logged without PII for store audit trails  
- [ ] Consent `policyVersion` matches `POLICY_VERSION` env before verify  
- [ ] CI fails if mobile/web `grep` finds `VENDOR_API_KEY`  
- [ ] Flutter: no document values in `debugPrint` / Crashlytics keys  
- [ ] React: CSP blocks inline scripts on upload pages  
- [ ] Account deletion API cascades verification rows + object storage  