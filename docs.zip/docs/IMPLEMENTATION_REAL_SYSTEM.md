# Real system implementation — Flutter, React, Node.js backend

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Engineering |
| Stacks | **Flutter** (Android/iOS), **React** (web), **Node.js** (API) |

This document is the **shared implementation reference** for all playbooks: PAN, AADHAAR, RC, DL, PUC, FASTAG, and DigiLocker. Each integration file links here and adds **type-specific** request/response examples.

## Deployment modes

| Mode | When to use | Clients |
| :--- | :--- | :--- |
| **Flutter + Node.js** | Consumer / driver mobile app | `lib/` → your API |
| **React + Node.js** | Web onboarding, fleet admin, B2B portal | `src/` → same API |
| **Node.js only** | Cron re-verification, vendor webhooks, bulk fleet jobs, partner API | No UI; internal or M2M auth |

**HARD GATE:** One **Node.js verification API** serves all clients. Vendor keys exist only on the server.

## Suggested repository layout

```text
repo/
  apps/
    api/                    # Node.js (Express or Fastify)
      src/
        routes/v1/verify/
        services/verification/
        adapters/vendor/    # pan, aadhaar, rc, dl, puc, fastag, digilocker
        middleware/
        jobs/               # backend-only cron
        webhooks/
    web/                    # React (Vite + TypeScript)
      src/
        api/verificationClient.ts
        features/verify/
    mobile/                 # Flutter
      lib/
        data/verification/
        features/verify/
  packages/
    shared-types/           # Optional: OpenAPI-generated or hand-written TS + dart via openapi
```

You can split repos later; keep **OpenAPI** or a shared `shared-types` package so Flutter/React do not drift.

## Node.js backend (canonical)

### Stack choices

| Layer | Recommendation |
| :--- | :--- |
| Runtime | Node 20 LTS |
| Framework | Fastify or Express + TypeScript |
| Validation | Zod on request bodies |
| DB | PostgreSQL (requests, consent, outcomes) |
| Object storage | S3-compatible (India region) for upload path only |
| Queue | BullMQ for async vendor / human review |
| Secrets | env + vault; `VENDOR_*` keys never in git |

### Request pipeline (every verify endpoint)

```text
authJwt → requireConsent → idempotencyKey → rateLimit → validateBody(Zod)
  → VerificationService.verify(type, payload)
  → persist Outcome (masked) → respond
```

### Core files to implement

| File | Responsibility |
| :--- | :--- |
| `routes/v1/verify/index.ts` | Mount sub-routers |
| `routes/v1/verify/pan.router.ts` | `POST /v1/verify/pan` |
| `services/verification/verification.service.ts` | Orchestration |
| `services/verification/consent.service.ts` | Policy version gate |
| `adapters/vendor/vendor.interface.ts` | Adapter contract |
| `adapters/vendor/acme.adapter.ts` | Your contracted vendor |
| `middleware/redact-logger.ts` | Strip PAN/Aadhaar from logs |
| `jobs/reverify.job.ts` | DL/PUC expiry (backend-only) |
| `webhooks/vendor.handler.ts` | HMAC verify + idempotent update |

### Express/Fastify route pattern (PAN example)

```typescript
// apps/api/src/routes/v1/verify/pan.router.ts
import { z } from 'zod';
import { verificationService } from '../../../services/verification/verification.service';

const bodySchema = z.object({
  pan: z.string().regex(/^[A-Z]{5}[0-9]{4}[A-Z]$/),
  name: z.string().min(1).max(120),
  dob: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  consentId: z.string().uuid(),
});

export async function postVerifyPan(req, reply) {
  const body = bodySchema.parse(req.body);
  const result = await verificationService.verifyPan({
    userId: req.user.id,
    channel: req.headers['x-client-channel'] as 'android' | 'ios' | 'web',
    idempotencyKey: req.headers['idempotency-key'] as string,
    ...body,
  });
  return reply.send(result);
}
```

### Consent endpoints (all stacks)

| Method | Path | Purpose |
| :--- | :--- | :--- |
| `POST` | `/v1/consent` | Record acceptance; returns `consentId` |
| `GET` | `/v1/consent/current-policy` | Policy version + text URL for UI |

### Verification endpoints (all integrations)

| Type | Method | Path |
| :--- | :--- | :--- |
| PAN | POST | `/v1/verify/pan` |
| Aadhaar | POST | `/v1/verify/aadhaar/init` and `POST /v1/verify/aadhaar/complete` (partner OTP flow) |
| RC | POST | `/v1/verify/rc` |
| DL | POST | `/v1/verify/dl` |
| PUC | POST | `/v1/verify/puc` |
| FASTag | POST | `/v1/verify/fastag` |
| Upload (OCR path) | POST | `/v1/verify/uploads/presign` then `POST /v1/verify/{type}/submit-upload` |
| Poll status | GET | `/v1/verify/requests/:requestId` |
| DigiLocker | POST | `/v1/digilocker/session` → redirect URL; `GET /v1/digilocker/callback` (backend); `POST /v1/digilocker/pull` |

### Auth headers (clients)

```http
Authorization: Bearer <access_token>
Idempotency-Key: <uuid>
X-Client-Channel: android|ios|web
X-Client-Version: 1.2.3
X-Integrity-Token: <optional Play Integrity / App Attest blob>
Content-Type: application/json
```

### Environment variables (API)

```bash
DATABASE_URL=
OBJECT_STORAGE_BUCKET=
VENDOR_BASE_URL=
VENDOR_API_KEY=          # server only
VENDOR_WEBHOOK_SECRET=
DIGILOCKER_CLIENT_ID=
DIGILOCKER_CLIENT_SECRET=
DIGILOCKER_REDIRECT_URI=
JWT_ISSUER=
POLICY_VERSION=2026-11-24
```

### Backend-only flows

| Job | Schedule | Action |
| :--- | :--- | :--- |
| `reverifyDl` | daily | Query outcomes expiring in 7 days → vendor |
| `reverifyPuc` | daily | Same for PUC |
| `purgeRetention` | daily | Delete blobs per [00_MASTER_INDEX.md](./00_MASTER_INDEX.md) matrix |
| `vendorWebhook` | event | Update `requestId` status async |

| Internal API | Auth | Use |
| :--- | :--- | :--- |
| `POST /internal/v1/fleet/verify/bulk` | mTLS or service JWT | CSV fleet RC/DL |
| `GET /internal/v1/metrics/verify` | ops role | Dashboard |

Flutter/React **do not** call `/internal/*`.

---

## Flutter implementation

### Packages (suggested)

| Package | Use |
| :--- | :--- |
| `dio` or `http` | API client |
| `flutter_secure_storage` | Tokens only — not PAN/Aadhaar |
| `uuid` | Idempotency-Key |
| `image_picker` | Document capture |
| `url_launcher` / `flutter_web_auth_2` | DigiLocker OAuth |

### Layering

```text
features/verify/pan/
  pan_verify_screen.dart
  pan_verify_controller.dart   # Riverpod / Bloc
data/verification/
  verification_api.dart
  verification_repository.dart
  models/verify_pan_request.dart
```

### API client snippet

```dart
// data/verification/verification_api.dart
class VerificationApi {
  VerificationApi(this._dio);
  final Dio _dio;

  Future<VerifyPanResponse> verifyPan(VerifyPanRequest body) async {
    final idempotencyKey = const Uuid().v4();
    final res = await _dio.post(
      '/v1/verify/pan',
      data: body.toJson(),
      options: Options(headers: {
        'Idempotency-Key': idempotencyKey,
        'X-Client-Channel': Platform.isIOS ? 'ios' : 'android',
      }),
    );
    return VerifyPanResponse.fromJson(res.data);
  }
}
```

### UX hardening (all doc screens)

- `SecureWidget` wrapper: disable text selection on ID fields; optional screenshot block on Android via platform channel + `FLAG_SECURE`.
- Never `debugPrint` request bodies.
- Poll `GET /v1/verify/requests/:requestId` when `status == pending`.

### Feature mapping

| Playbook | Flutter screen(s) |
| :--- | :--- |
| PAN | `PanVerifyScreen` |
| Aadhaar | `AadhaarVerifyFlow` (multi-step init/complete) |
| RC | `RcVerifyScreen` + optional QR scan |
| DL | `DlVerifyScreen` |
| PUC | `PucCaptureScreen` + upload |
| FASTag | `FastagVerifyScreen` |
| DigiLocker | `DigiLockerLinkButton` → external auth → deep link return |

---

## React implementation

### Stack

| Layer | Recommendation |
| :--- | :--- |
| Build | Vite + TypeScript |
| Data | TanStack Query |
| Forms | React Hook Form + Zod (mirror server schemas) |
| Auth | Same JWT as mobile (httpOnly cookie for web optional) |

### API client

```typescript
// apps/web/src/api/verificationClient.ts
export async function verifyPan(input: VerifyPanInput, token: string) {
  const res = await fetch(`${API_BASE}/v1/verify/pan`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Idempotency-Key': crypto.randomUUID(),
      'X-Client-Channel': 'web',
    },
    body: JSON.stringify(input),
  });
  if (!res.ok) throw await res.json();
  return res.json() as VerifyPanResponse;
}
```

### Hook pattern

```typescript
// features/verify/useVerifyPan.ts
export function useVerifyPan() {
  return useMutation({
    mutationFn: (input: VerifyPanInput) => verifyPan(input, getAccessToken()),
  });
}
```

### Web-specific

- `autocomplete="off"` on PAN/Aadhaar/DL fields.
- File upload: call `POST /v1/verify/uploads/presign`, `PUT` to storage, then `submit-upload`.
- DigiLocker: full-page redirect to `session.redirectUrl`; callback handled by **backend** route that then redirects to `https://app.example.com/verify/digilocker/done?requestId=`.

### Feature mapping

| Playbook | React route / component |
| :--- | :--- |
| PAN | `/onboarding/pan` → `PanVerifyForm` |
| Aadhaar | `/onboarding/aadhaar` |
| RC / DL | `/vehicle/rc`, `/driver/dl` |
| PUC / FASTag | `/vehicle/puc`, `/vehicle/fastag` |
| Fleet bulk | `/admin/fleet/verify` (backend-only bulk via internal API from admin BFF) |

---

## Unified types (TypeScript — share with OpenAPI)

```typescript
export type VerifyStatus = 'verified' | 'failed' | 'pending' | 'expired';
export type TrustTier = 'T1' | 'T2' | 'T3' | 'T4' | 'T5';

export interface VerificationOutcome {
  requestId: string;
  type: 'pan' | 'aadhaar' | 'rc' | 'dl' | 'puc' | 'fastag';
  status: VerifyStatus;
  trustTier: TrustTier;
  verifiedAt?: string;
  expiresAt?: string;
  display: Record<string, string>; // masked fields only for UI
}
```

Generate Dart models from the same OpenAPI spec (`openapi-generator-cli -g dart`).

---

## Integration-specific payloads

Details and edge cases live in each playbook’s **Real system implementation** section. Summary:

| Type | POST body (minimal) |
| :--- | :--- |
| PAN | `pan`, `name`, `dob?`, `consentId` |
| Aadhaar init | `consentId`, `method: 'otp' \| 'digilocker'` |
| Aadhaar complete | `requestId`, `otp?`, `partnerSessionId?` |
| RC | `vrn`, `consentId`, `authorizationAttestation: true` |
| DL | `dlNumber`, `dob`, `stateCode?`, `consentId` |
| PUC | `vrn`, `certNumber?`, `validUpto?`, `uploadId?`, `consentId` |
| FASTag | `vrn` or `tagId`, `consentId` |
| DigiLocker pull | `sessionId`, `docType` |

---

## Implementation order (engineering)

1. Node: consent + `GET /v1/verify/requests/:id` + PAN route with **mock adapter**.
2. Flutter + React: PAN screen wired to mock.
3. Swap mock adapter for vendor adapter per doc ([VENDOR_EVALUATION_AND_CONTRACTS.md](./VENDOR_EVALUATION_AND_CONTRACTS.md)).
4. Add upload presign path for PUC/RC OCR fallback.
5. Aadhaar + DigiLocker last ([00_MASTER_INDEX.md](./00_MASTER_INDEX.md)).

## Per-playbook links

| Doc | Section |
| :--- | :--- |
| [PAN.md](./PAN.md) | Real system implementation |
| [AADHAAR.md](./AADHAAR.md) | Real system implementation |
| [RC_VEHICLE.md](./RC_VEHICLE.md) | Real system implementation |
| [DRIVING_LICENSE.md](./DRIVING_LICENSE.md) | Real system implementation |
| [PUC_CERTIFICATE.md](./PUC_CERTIFICATE.md) | Real system implementation |
| [FASTAG.md](./FASTAG.md) | Real system implementation |
| [DIGILOCKER_CHANNEL.md](./DIGILOCKER_CHANNEL.md) | Real system implementation |

## Go-live (engineering)

- [ ] OpenAPI published; Flutter/React regen types
- [ ] CI secret scan (no `VENDOR_API_KEY` in mobile/web)
- [ ] E2E: consent → verify → masked outcome on all three channels
- [ ] Backend-only cron tested in staging