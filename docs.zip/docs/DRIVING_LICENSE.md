# Driving licence integration playbook

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Backend + Product |

## 1. Integration summary

Verify **Driving Licence** via **Sarathi**-linked vendor APIs or DigiLocker issued DL.

| In scope | Out of scope |
| :--- | :--- |
| DL number + DOB verify | International licence (unless vendor supports) |
| Categories / COV, expiry, status | RTO exam booking |
| Transport vs non-transport classification | Medical certificate storage |

## 2. Purpose gate

| Purpose | Allowed |
| :--- | :--- |
| Driver onboarding (fleet/gig) | Yes with authorization |
| User proves eligibility to drive | Yes |
| Verify another person’s DL without role | Legal review required |

## 3. Regulatory landscape

- Motor Vehicles Act  
- State RTO / Sarathi policies via vendor  
- DPDP  

## 4. API landscape

| Path | Trust |
| :--- | :--- |
| Vendor Sarathi/DL API | T2 |
| DigiLocker DL | T1 |
| OCR DL card | T5 |

DL number formats vary by state — backend validates per vendor ruleset.

## 5. Prerequisites

- [ ] Vendor DL prod SKU  
- [ ] DOB collection lawful basis in notice  
- [ ] Gig: COV requirements defined (e.g. LMV, HMV)

## 6. Data handling

- Mask DL in UI (`XX12345678901234`)  
- Store expiry date for re-verify jobs  
- Do not expose DL photo publicly in marketplace profiles  

## 7. Architecture

`POST /v1/verify/dl` with `dlNumber`, `dob`, optional `stateCode`.

## 8. Mobile

- State picker if required  
- Expiry warning banners  
- DigiLocker shortcut when available  

## 9. Backend

- Re-verify job 7 days before `expiryDate`  
- Block features if `status != active` per product rules  

## 10. Web

Same API; fleet bulk verify with audit trail.

## 11. Verification modes

DigiLocker → Vendor API → OCR/manual.

## 12. Fraud

Fake DL images; expired DL with altered dates — trust T2+ only.

## 13. Re-verification

On expiry, renewal event, or periodic fleet audit.

## 14. Human-in-the-loop

COV mismatch (need HMV, user shows LMV only).

## 15. Testing

Sandbox DLs; expired; suspended; wrong DOB.

## 16. Store policy

Gov ID + DOB declarations.

## 17. Go-live

- [ ] COV rules configured  
- [ ] Expiry notifications tested  

## 18. Real system implementation

Shared patterns: [IMPLEMENTATION_REAL_SYSTEM.md](./IMPLEMENTATION_REAL_SYSTEM.md).

### Node.js

- Route: `POST /v1/verify/dl`

**Request**

```json
{
  "dlNumber": "MH01201234567890",
  "dob": "1990-05-15",
  "stateCode": "MH",
  "consentId": "uuid"
}
```

**Response**

```json
{
  "requestId": "uuid",
  "status": "verified",
  "trustTier": "T2",
  "display": {
    "maskedDl": "XX4567890123456",
    "cov": ["LMV"],
    "validUpto": "2030-05-14",
    "transport": false
  }
}
```

### Flutter

- `DlVerifyScreen` with state picker when vendor requires.

### React

- `/driver/dl` for gig onboarding; show COV requirements from remote config.

### Backend only

- Job `reverifyDl`: query `validUpto` within 7 days → vendor → notify via push/email service.

## 19. References

Vendor DL API docs; DigiLocker doc types.