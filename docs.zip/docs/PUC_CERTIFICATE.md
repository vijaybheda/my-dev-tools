# PUC certificate integration playbook

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Backend + Product |

## 1. Integration summary

**Pollution Under Control (PUC)** certificates are issued by **authorised testing stations** under **state pollution control boards**. National API uniformity is **weak** — plan for tiered trust.

| In scope | Out of scope |
| :--- | :--- |
| Validity date + cert number verify when vendor/state API exists | Single guaranteed pan-India API |
| Linkage to Vahan PUC field when vendor exposes | Emission readings analytics |
| Upload photo for manual/OCR path | Implying govt certification from OCR alone |

## 2. Purpose gate

| Purpose | Allowed |
| :--- | :--- |
| Fleet compliance (expiry tracking) | Yes |
| Gate access / dispatch if PUC valid | Conditional on trust tier |
| Auto-approve from photo OCR only | **No** for high-risk gates |

## 3. Regulatory landscape

- Central Motor Vehicles Rules (PUC norms)  
- State PCB enforcement variance  
- DPDP  

## 4. API and provider landscape

| Path | Trust |
| :--- | :--- |
| Vendor with state/MoRTH linkage | T2 when available |
| Vahan “PUC upto” field via RC API | Partial — expiry hint |
| DigiLocker if user has PUC e-doc | T1 |
| Photo + OCR | T5 |
| Analyst review | T4 |

**HARD GATE:** Define product behavior when only T5 available — warn vs block.

## 5. Trust tiers (product policy)

| Tier | User experience |
| :--- | :--- |
| T1/T2 | “PUC verified” |
| T4 | “Under review” |
| T5 | “Submitted — not issuer-verified” |

## 6. Prerequisites

- [ ] Vendor documents which states/APIs covered  
- [ ] Re-verify cadence (often annual; commercial vehicles differ)  
- [ ] Fraud copy reviewed by Legal  

## 7. Data handling

- Store `certNumber`, `validUpto`, `vrn`  
- Images: TTL storage  
- Emission values: optional minimize  

## 8. Architecture

`POST /v1/verify/puc` — may return `partial` if only Vahan expiry available.

## 9. Mobile

- Camera capture with quality hints  
- Show expiry countdown  
- Renew CTA (external station finder — not in scope unless built)  

## 10. Backend

- Job: mark expired daily  
- Fleet report: % verified T2 vs T5  

## 11. Web

Bulk fleet PUC status for operators.

## 12. Fraud

Forged PUC stickers common — **never T5-only** for compliance fines avoidance claims.

## 13. Re-verification

Before `validUpto`; notify D-30, D-7.

## 14. Human-in-the-loop

All T5 uploads before fleet dispatch if policy requires.

## 15. Testing

Expired cert; wrong VRN; state not in vendor coverage.

## 16. Store policy

Photos + vehicle data disclosure.

## 17. Go-live

- [ ] Trust tier messaging in UI  
- [ ] State coverage matrix published internally  
- [ ] Align with RC insurance/fitness fields where applicable  

## 18. Real system implementation

Shared patterns: [IMPLEMENTATION_REAL_SYSTEM.md](./IMPLEMENTATION_REAL_SYSTEM.md).

### Node.js

- Route: `POST /v1/verify/puc`
- If only image: trust `T5` until analyst or vendor confirms.

**Request (API path)**

```json
{
  "vrn": "MH12AB1234",
  "certNumber": "PUC123456",
  "validUpto": "2026-06-30",
  "consentId": "uuid"
}
```

**Request (upload path)**

```json
{
  "vrn": "MH12AB1234",
  "uploadId": "uuid-from-presign",
  "consentId": "uuid"
}
```

**Response**

```json
{
  "requestId": "uuid",
  "status": "pending",
  "trustTier": "T5",
  "display": { "message": "Submitted — issuer verification in progress" }
}
```

### Flutter

- `PucCaptureScreen` → presign → multipart upload → `submit-upload`.

### React

- Same upload flow; compress images client-side before PUT.

### Backend only

- Daily `markPucExpired` on `validUpto < today`.
- Analyst queue consumer updates `status` to `verified` with `trustTier` T2/T4.

## 19. References

State PCB sites; vendor coverage matrix; [RC_VEHICLE.md](./RC_VEHICLE.md) for Vahan fields.