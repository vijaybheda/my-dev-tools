# PAN integration playbook

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Backend + Legal |

## 1. Integration summary

Verify **Permanent Account Number** with **Income Tax / NSDL–Protean** pipes through a **licensed vendor** (typical IT company path). Format validation alone is not verification.

| In scope | Out of scope |
| :--- | :--- |
| PAN existence + name/DOB match (vendor-dependent) | Direct ITD integration without entitlement |
| Business PAN for fleet B2B (if charter says) | Using PAN as authentication secret |
| Form 60 path documentation (no PAN cases) | Storing PAN in client logs |

## 2. Purpose gate

| Purpose | Allowed |
| :--- | :--- |
| KYC / onboarding | Yes via T2+ vendor |
| Fleet operator tax identity | Conditional |
| Casual profile field | Discouraged — minimization |
| OCR-only onboarding | **No** for regulated decisions |

**Pending charter:** Update when product journey is defined ([00_MASTER_INDEX.md](./00_MASTER_INDEX.md)).

## 3. Regulatory landscape

- Income Tax Act — PAN issuance and use  
- DPDP — sensitive personal data handling  
- RBI KYC Master Direction — if lending/wallets (see CROSS_CUTTING)  
- PMLA — if financial transactions  

## 4. API and provider landscape

| Path | Trust |
| :--- | :--- |
| Vendor PAN verification API | T2 |
| DigiLocker issued PAN | T1 |
| OCR from card image | T5 — supplemental only |
| Regex `^[A-Z]{5}[0-9]{4}[A-Z]$` | Format only — not verify |

## 5. Prerequisites

- [ ] Vendor contract includes PAN prod SKU (**HARD GATE**)
- [ ] Purpose charter signed
- [ ] Name match rules documented (transliteration tolerance)

## 6. Data handling

| Field | Store |
| :--- | :--- |
| Full PAN | Avoid; hash for dedupe |
| Masked `XXXXX1234F` | Yes |
| Name from ITD | If needed for match outcome |
| Card image | TTL per retention matrix |

## 7. Architecture

Mobile/Web → `POST /v1/verify/pan` → adapter → vendor. See [BACKEND_UNIFIED_VERIFICATION_SERVICE.md](./BACKEND_UNIFIED_VERIFICATION_SERVICE.md).

## 8. Mobile

- Input: uppercase normalize; validate format client-side only for UX
- No clipboard copy on PAN field
- FLAG_SECURE on PAN entry screen (with Aadhaar flows)
- Play Integrity optional on submit

## 9. Backend

- Idempotency on same PAN+user within window
- Dedupe: block excessive accounts per PAN hash
- Name match score threshold product-defined

## 10. Web

- Same API; rate limit stricter
- Autocomplete off on PAN field

## 11. Verification modes

1. DigiLocker PAN (T1)  
2. Vendor PAN verify with name + DOB (T2)  
3. Upload image + OCR (T5) + manual review (T4) if allowed  

## 12. Fraud and abuse

- Same PAN on many accounts  
- Sequential PAN guessing — rate limit  

## 13. Re-verification

On legal name change or dispute only; else rely on initial T2 outcome TTL.

## 14. Human-in-the-loop

When OCR name disagrees with user profile by > threshold.

## 15. Testing

- Sandbox PANs from vendor docs only — **never production PANs in dev**
- Cases: invalid format, no match, name fuzzy match, inactive PAN (if vendor returns)

## 16. Store policy mapping

- Declare gov ID in Play Data Safety / Apple labels
- Explain PAN use in listing description

## 17. Go-live checklist

- [ ] Vendor PAN prod enabled  
- [ ] Masking in all API responses  
- [ ] Dedupe rules live  

## 18. Real system implementation

Shared patterns: [IMPLEMENTATION_REAL_SYSTEM.md](./IMPLEMENTATION_REAL_SYSTEM.md).

### Node.js

- Route: `POST /v1/verify/pan`
- Adapter: `adapters/vendor/verifyPan({ pan, name, dob })`
- Persist hashed PAN for dedupe; return masked only.

**Request**

```json
{
  "pan": "ABCDE1234F",
  "name": "Raj Kumar",
  "dob": "1990-05-15",
  "consentId": "uuid"
}
```

**Response**

```json
{
  "requestId": "uuid",
  "status": "verified",
  "trustTier": "T2",
  "display": { "maskedPan": "XXXXX1234F", "nameMatch": "high" }
}
```

### Flutter

- Screen: `PanVerifyScreen` → `verificationRepository.verifyPan()`
- Validate format locally; server is source of truth.

### React

- Route `/onboarding/pan` → `useVerifyPan()` mutation (TanStack Query).

### Backend only

- Cron not required for PAN unless periodic re-check policy; optional `POST /internal/v1/reverify/pan` for disputes.

## 19. References

- incometax.gov.in (policy)
- Vendor API documentation (post-contract)