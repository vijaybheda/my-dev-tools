# RC (vehicle registration) integration playbook

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Backend + Product |

## 1. Integration summary

Verify **Registration Certificate** data against **Vahan** / MoRTH-linked sources via licensed vendor.

| In scope | Out of scope (v1 unless added) |
| :--- | :--- |
| VRN lookup, owner name match, status, insurance validity field | Full insurance policy document |
| Fitness / permit indicators if vendor returns | eChallan history |
| Hypothecation flag awareness | GSTIN for operator |

## 2. Purpose gate

| Purpose | Allowed |
| :--- | :--- |
| Owner verifies own vehicle | Yes with declaration |
| Fleet verifies assigned vehicle | Yes with operator agreement |
| Third-party lookup without authorization | **Forbidden** or Legal review |
| Marketplace buyer verifies seller RC | Conditional — user consent + ToS |

## 3. Regulatory landscape

- Motor Vehicles Act  
- MoRTH / NIC Vahan terms of use (via vendor)  
- DPDP  

## 4. API and provider landscape

| Path | Trust |
| :--- | :--- |
| Vendor Vahan API | T2 |
| DigiLocker issued RC | T1 |
| OCR RC card photo | T5 |
| mParivahan screenshot | T5 — not issuer proof |

## 5. Prerequisites

- [ ] Vendor includes RC/Vahan prod scope (**HARD GATE**)
- [ ] UX captures **authorization attestation** (owner/driver/fleet)
- [ ] Charter defines fleet vs consumer

## 6. Data handling

| Field | Notes |
| :--- | :--- |
| VRN | Often required for ops |
| Chassis/engine last digits | Vendor-dependent; minimize display |
| Owner name | Match score; may not expose to unrelated users |
| Insurance valid upto | From Vahan — not full policy |

## 7. Architecture

`POST /v1/verify/rc` with `vrn` + optional `chassisLast5` per vendor spec.

## 8. Mobile

- VRN input masks (e.g. `MH12AB1234`)
- Scan RC QR if vendor supports structured verify
- Photo upload fallback → T4/T5 path

## 9. Backend

- Authorization record linked to verification request
- Cache RC status 24–72h with remote-config override

## 10. Web

- Fleet bulk upload CSV — separate rate limits + audit

## 11. Verification modes

1. DigiLocker RC (T1)  
2. Vendor Vahan (T2)  
3. OCR + analyst (T4)  

## 12. Fraud

- Forged RC images — do not trust OCR alone  
- VRN typos vs stolen vehicle reports — vendor may return stolen flag if available  

## 13. Re-verification

- On ownership transfer event  
- Periodic fleet compliance (monthly/quarterly)  
- Insurance expiry approaching — notify from Vahan field  

## 14. Human-in-the-loop

OCR owner name mismatch with fleet roster.

## 15. Testing

Sandbox VRNs from vendor; test inactive/scrapped vehicle responses.

## 16. Store policy

Declare vehicle information collection; not required to declare as “financial” unless payments added.

## 17. Go-live

- [ ] Authorization UX live  
- [ ] Masking for marketplace views  
- [ ] Adjacent docs scope documented to product  

## 18. Real system implementation

Shared patterns: [IMPLEMENTATION_REAL_SYSTEM.md](./IMPLEMENTATION_REAL_SYSTEM.md).

### Node.js

- Route: `POST /v1/verify/rc`
- Require `authorizationAttestation: true` (user confirmed right to query VRN).

**Request**

```json
{
  "vrn": "MH12AB1234",
  "consentId": "uuid",
  "authorizationAttestation": true,
  "chassisLast5": "12345"
}
```

**Response**

```json
{
  "requestId": "uuid",
  "status": "verified",
  "trustTier": "T2",
  "display": {
    "vrn": "MH12AB1234",
    "rcStatus": "ACTIVE",
    "insuranceValidUpto": "2026-08-01"
  }
}
```

OCR fallback: `POST /v1/verify/uploads/presign` → upload → `POST /v1/verify/rc/submit-upload` with `uploadId`.

### Flutter

- `RcVerifyScreen` with VRN input + attestation checkbox.
- Optional mobile scanner for QR if vendor supports.

### React

- Fleet operator: `/vehicle/rc` form; bulk via admin BFF → `POST /internal/v1/fleet/verify/bulk` (not from browser with user JWT).

### Backend only

- Nightly `reverifyRc` for fleet table where `cacheExpiresAt < now()`.

## 19. References

- parivahan.gov.in (public info)
- Vendor Vahan field dictionary