# Vendor evaluation and contracts

| Doc metadata | Value |
| :--- | :--- |
| Version | 1.0.0 |
| Last reviewed | 2026-11-24 |
| Owner | Legal + Engineering |
| Next regulatory watch | 2026-12-01 |

For a registered **IT company without direct govt API access**, licensed vendors are the default production path.

## Vendor categories (do not confuse)

| Category | What they do | Use for |
| :--- | :--- | :--- |
| **KYC / identity verification aggregator** | PAN, Aadhaar eKYC, RC/DL via licensed pipes | This playbook set |
| **DigiLocker Requester** | OAuth pull of **issued** docs | Wallet / low-fraud path |
| **Account Aggregator (RBI)** | Financial data consent | **Not** PAN photo verify |
| **OCR-only vendors** | Extract text from images | T5 trust only — supplemental |

## RFP scorecard (weight as needed)

| Criterion | Weight | Questions |
| :--- | :--- | :--- |
| Legal entitlement | 25% | Which govt sources in **prod**? Written attestation? |
| Doc coverage | 20% | PAN, Aadhaar, RC, DL, PUC, FASTag — which in scope? |
| Sandbox quality | 10% | Parity with prod? Test IDs documented? |
| Uptime / SLA | 10% | 99.9%? Credits? |
| Data residency | 15% | Processing in India? Subprocessors list? |
| Security | 10% | ISO 27001/SOC2? Pentest? |
| Pricing | 10% | Per-check tiers; minimum commit |

## Contract clauses (HARD GATE)

- [ ] **Purpose limitation** — data used only for your stated purpose  
- [ ] **Subprocessor** notice and approval  
- [ ] **DPA** with erasure on request (SLA days)  
- [ ] **Breach** notification (hours/days)  
- [ ] **Sandbox vs prod** keys and rate limits  
- [ ] **Audit logs** availability for disputes  
- [ ] **No secondary use** of biometric/ID by vendor  
- [ ] **Termination** data return/destruction  
- [ ] **Multi-tenant** isolation if white-label  

## Sandbox vs production surprises

| Check | Why |
| :--- | :--- |
| Prod enablement separate from sandbox contract | Common sales trap |
| Per-doc-type SKUs (Aadhaar often extra) | Budget shock |
| MoRTH/Vahan field set in prod matches POC | Partial RC fields |
| Aadhaar OTP enabled only in prod with extra UIDAI compliance | Timeline risk |

## Cost model (template)

| Integration | Typical billing unit | Notes |
| :--- | :--- | :--- |
| PAN verify | per successful match | Failed match may still bill |
| Aadhaar eKYC | per auth | Higher; legal review required |
| RC / DL | per lookup | Invalid VRN may bill |
| PUC | per check or unavailable | May need manual tier |
| FASTag | per tag status | Recharge is different product |

Estimate monthly: `checks_per_user × users × success_rate × unit_price`.

## Multi-tenant / white-label

| Control | Implementation |
| :--- | :--- |
| Separate API keys per client | Backend vault |
| Client ID in every verification record | DB schema |
| Client cannot see other client’s hashes | Query isolation |
| DPA per client | Legal |

## Vendor adapter interface (technical)

Backend implements adapters per vendor; swap without mobile changes:

```text
verifyPan(request) -> VerificationResult
verifyAadhaar(request) -> VerificationResult
verifyRc(request) -> VerificationResult
verifyDl(request) -> VerificationResult
verifyPuc(request) -> VerificationResult
verifyFastag(request) -> VerificationResult
```

See [BACKEND_UNIFIED_VERIFICATION_SERVICE.md](./BACKEND_UNIFIED_VERIFICATION_SERVICE.md).

## Due diligence documents to collect

- [ ] Certificate of incorporation match with contracting entity  
- [ ] Information security policy  
- [ ] Subprocessor list  
- [ ] India data processing addendum  
- [ ] API documentation version locked in contract  
- [ ] Sample audit report (redacted)  

## Exit strategy

- [ ] Secondary vendor identified for PAN/RC/DL (minimum)  
- [ ] Export format for verification history  
- [ ] Contractual portability window  

## Pre-sign checklist

- [ ] Charter doc types ⊆ vendor prod SKUs  
- [ ] Legal reviewed Aadhaar clauses if applicable  
- [ ] Engineering reviewed webhook + idempotency spec  
- [ ] Finance approved minimum commit  

## Real system implementation

After vendor selection, implement one **adapter class** per vendor in Node (`adapters/vendor/<name>.adapter.ts`) matching routes in [IMPLEMENTATION_REAL_SYSTEM.md](./IMPLEMENTATION_REAL_SYSTEM.md). Flutter and React stay unchanged when you swap adapters.

## References

Vendor-specific docs after selection — attach as appendix in repo `docs/vendors/<name>.md` (create when contracted).